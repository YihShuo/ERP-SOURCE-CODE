package test

import (
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"testing"
	"time"

	// "time"

	"web-api/internal/pkg/models/types"
)

type DeckerResponse struct {
	RetID   string `json:"retId"`
	RetCode int    `json:"retCode"`
	RetMsg  string `json:"retMsg"`
}

func TestPostDailyPoStatus_SimulateFailure(t *testing.T) {
	fakePayload := []types.DailyPoStatus{
		{PoNumber: "PO123", Date: "2026-06-11"},
		{PoNumber: "PO456", Date: "2026-06-11"},
	}

	mockPostRequest := func(requestBody []byte) (string, error) {
		return "", fmt.Errorf("API_REJECTED|retCode:8|msg:event size exceeds the limit")
	}

	mailBody := ""
	_, err := processChunk(
		fakePayload,
		80000,
		func(item types.DailyPoStatus) ([]byte, error) { return json.Marshal(item) },
		mockPostRequest,
		&mailBody,
	)

	fmt.Println("Result Error:", err)
	fmt.Println("MailBody Content:\n", mailBody)
}
func processChunk[T any](
	chunk []T,
	safeBodySize int,
	marshalFunc func(item T) ([]byte, error),
	postRequestFunc func(requestBody []byte) (string, error),
	mailBody *string,
) (map[string]string, error) {

	poReturnIdMap := make(map[string]string)
	var requestBody []byte
	var currentBatchKeys []string
	var currentBatchItems []T
	var errBody, sucBody string
	var hasError bool

	// 內部輔助：自動辨識型別並提取關鍵識別碼 (如 PO, StageCode)
	autoExtractKey := func(item any) string {
		switch obj := item.(type) {
		case types.DailyPoStatus:
			return obj.PoNumber
		default:
			return ""
		}
	}

	// 內部輔助：格式化錯誤列表
	formatFailedItems := func(items []T) string {
		var keys []string
		for _, item := range items {
			if key := autoExtractKey(item); key != "" {
				keys = append(keys, key)
			}
		}
		return strings.Join(keys, ", ")
	}

	for _, item := range chunk {
		subStream, err := marshalFunc(item)
		if err != nil {
			continue
		}

		// 容量控管與發送
		if len(requestBody)+len(subStream) > safeBodySize && len(requestBody) > 0 {
			_, returnID, err := sendWithRetry(requestBody, postRequestFunc, 3)

			if err != nil {
				hasError = true
				errBody += fmt.Sprintf(`<p style="color:red;"><b>[失敗批次]</b> Items: %s | 錯誤: %s</p>`, formatFailedItems(currentBatchItems), err.Error())
				requestBody, currentBatchKeys, currentBatchItems = []byte{}, []string{}, []T{}
				continue
			}

			sucBody += "<p>[成功] ReturnID: " + returnID + "</p>"
			for _, k := range currentBatchKeys {
				poReturnIdMap[k] = returnID
			}
			requestBody, currentBatchKeys, currentBatchItems = []byte{}, []string{}, []T{}
			time.Sleep(500 * time.Millisecond) // 流控
		}

		requestBody, _ = appendStream(requestBody, subStream)
		currentBatchItems = append(currentBatchItems, item)
		if key := extractKeyFromItem(item); key != "" {
			currentBatchKeys = append(currentBatchKeys, key)
		}
	}

	// 處理最後剩下的資料
	if len(requestBody) > 0 {
		_, returnID, err := sendWithRetry(requestBody, postRequestFunc, 3)
		if err != nil {
			hasError = true
			errBody += fmt.Sprintf(`<p style="color:red;"><b>[最後一批失敗]</b> Items: %s | 錯誤: %s</p>`, formatFailedItems(currentBatchItems), err.Error())
		} else {
			sucBody += "<p>[成功] 最後一批 ReturnID: " + returnID + "</p>"
			for _, k := range currentBatchKeys {
				poReturnIdMap[k] = returnID
			}
		}
	}

	// 最終郵件內容組裝
	if errBody != "" {
		*mailBody = "<h2>錯誤清單</h2>" + errBody + "<hr><h2>成功記錄</h2>" + sucBody
	} else {
		*mailBody = sucBody
	}

	var finalErr error
	if hasError {
		finalErr = fmt.Errorf("部分批次發送失敗")
	}
	return poReturnIdMap, finalErr
}
func appendStream(requestBody []byte, itemStream []byte) ([]byte, error) {
	var subOutput []interface{}
	var item interface{}

	err := json.Unmarshal(itemStream, &item)
	if err != nil {
		log.Printf("Error when unmarshal item: %v\n", err)
		return requestBody, err
	}

	if len(requestBody) <= 0 {
		subOutput = append(subOutput, item)
	} else {
		err = json.Unmarshal(requestBody, &subOutput)
		if err != nil {
			log.Printf("Error when unmarshal output: %v\n", err)
			return requestBody, err
		}

		subOutput = append(subOutput, item)
	}
	return json.Marshal(subOutput)
}

// 輔助：提取 PO Number (用於失敗時紀錄)
func extractPoNumber(item any) string {
	switch obj := item.(type) {
	case types.DailyPoStatus:
		return obj.PoNumber
	case types.DeckerOutput, types.TqcOutputPayload, types.RqcResult, types.BgradeInventory:
		// 若其他型別無 PO Number，返回空字串，郵件將跳過不顯示
		return ""
	}
	return ""
}

// 輔助：提取 Key (用於更新 ReturnID)
func extractKeyFromItem(item any) string {
	switch obj := item.(type) {
	case types.DailyPoStatus:
		return obj.PoNumber + "_" + obj.StyleNumber + "_" + obj.ColorCode + "_" + obj.ShipID
	case types.DeckerOutput:
		return strings.Join([]string{obj.StartTime, obj.EndTime, obj.ProductionLineNumber, obj.FactoryWorkOrderNumber, obj.SizeNumber}, "__")
		// 其他型別請依此類推
	}
	return ""
}
func sendWithRetry(requestBody []byte, postReq func([]byte) (string, error), maxRetries int) (string, string, error) {
	var lastErr error

	for attempt := 1; attempt <= maxRetries; attempt++ {
		// 1. 發送請求
		respStr, err := postReq(requestBody)
		if err != nil {
			lastErr = fmt.Errorf("HTTP 網路請求失敗: %v", err)
			log.Printf("第 %d 次嘗試失敗: %v\n", attempt, lastErr)
			time.Sleep(time.Second * time.Duration(attempt))
			continue
		}

		// 2. 解析回應 JSON
		var apiResp DeckerResponse
		if unmarshalErr := json.Unmarshal([]byte(respStr), &apiResp); unmarshalErr != nil {
			lastErr = fmt.Errorf("無法解析 JSON 回傳值: %v, 回傳內容: %s", unmarshalErr, respStr)
			log.Printf("第 %d 次嘗試失敗: %v\n", attempt, lastErr)
			time.Sleep(time.Second * time.Duration(attempt))
			continue
		}

		// 3. 核心邏輯：判斷 retCode
		if apiResp.RetCode == 0 {
			return respStr, apiResp.RetID, nil // 成功
		}

		return "", "", fmt.Errorf("API_REJECTED|retCode:%d|msg:%s", apiResp.RetCode, apiResp.RetMsg)
	}

	return "", "", fmt.Errorf("達到最大重試次數 (%d)。最後錯誤: %v", maxRetries, lastErr)
}
