package repo

import (
	"log"
	"time"
	"web-api/internal/pkg/config"
	"web-api/internal/pkg/models/types"

	"gorm.io/gorm"
)

type LogRepository struct{}

var LogRepositoryInstance LogRepository

func (w *LogRepository) SavePoLog(databaseType string, log types.PoLog) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	return db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(&log).Error; err != nil {
			return err
		}
		return nil
	})
}

func (w *LogRepository) LogAndSave(function string, err error) {
	log.Printf("Failed %s: %v", function, err)

	poLog := types.PoLog{
		AppName:  "dtd",
		Function: function,
		LogDate:  time.Now(),
		Source:   "cron",
		Env:      config.GetEnvironment(),
		Message:  err.Error(),
	}

	_ = w.SavePoLog(
		config.GetConfig().Database.DatabaseType,
		poLog,
	)
}
