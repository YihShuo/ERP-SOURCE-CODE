package repo

import (
	"log"
	"time"
	"web-api/internal/pkg/models/types"

	"gorm.io/gorm"
)

type TqcRepository struct{}

var TqcRepositoryInstance TqcRepository

func (tqc *TqcRepository) GetTqcData(databaseType string, startTime, endTime time.Time) ([]types.TqcQueryResult, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	productionLineNumber := "BDepartment.DepName AS DepName,"
	if databaseType == "A" {
		productionLineNumber = `
			CASE 
				WHEN RIGHT(BDepartment.DepName, 1) IN ('A', 'B', 'C') 
					THEN LEFT(BDepartment.DepName, LEN(BDepartment.DepName) - 1)
				ELSE BDepartment.DepName 
			END AS DepName,`
	}

	sqlQuery := `


	DECLARE @startTime DATETIME = CAST (@start AS DATETIME);
	DECLARE @endTime   DATETIME = CAST (@end AS DATETIME);


	-- 1. 準備所有檢驗員 (從 Pass 表和 Defect 表集合起來)
	WITH Combined_Inspectors AS (
		SELECT DDBH, DepNo, Stage, UserID FROM QCRMain 
		WHERE userdate >= @startTime AND userdate < @endTime
		UNION
		SELECT qcr.SCBH, qcr.DepNo, 
			CASE WHEN qcrd.YYBH LIKE 'Q1%' THEN 1 WHEN qcrd.YYBH LIKE 'Q2%' THEN 2 WHEN qcrd.YYBH LIKE 'Q3%' THEN 3 END,
			qcr.UserID
		FROM qcr 
		INNER JOIN qcrd ON qcr.ProNo = qcrd.ProNo
		WHERE qcr.SCDate >= @startTime AND qcr.SCDate < @endTime AND qcr.GXLB = 'A' AND qcrd.YYBH LIKE 'Q%'
	),

	Numbered_Inspectors AS (
		SELECT 
			DDBH, DepNo, Stage, UserID,
			ROW_NUMBER() OVER (PARTITION BY DDBH, DepNo, Stage ORDER BY UserID) AS Rnk
		FROM Combined_Inspectors
	),

	-- 2. 檢驗員名單 (用 MAX 壓平，效能最好，只取一人)
	Inspector_List AS (
		SELECT 
			DDBH, DepNo,
			-- TQC1 的人 (最多列出三個)
			MAX(CASE WHEN Stage = 1 AND Rnk = 1 THEN UserID ELSE '' END) + 
			MAX(CASE WHEN Stage = 1 AND Rnk = 2 THEN ',' + UserID ELSE '' END) +
			MAX(CASE WHEN Stage = 1 AND Rnk = 3 THEN ',' + UserID ELSE '' END) AS TQC1_Inspector,
			
			-- TQC2 的人
			MAX(CASE WHEN Stage = 2 AND Rnk = 1 THEN UserID ELSE '' END) + 
			MAX(CASE WHEN Stage = 2 AND Rnk = 2 THEN ',' + UserID ELSE '' END) AS TQC2_Inspector,
			
			-- TQC3 的人
			MAX(CASE WHEN Stage = 3 AND Rnk = 1 THEN UserID ELSE '' END) + 
			MAX(CASE WHEN Stage = 3 AND Rnk = 2 THEN ',' + UserID ELSE '' END) AS TQC3_Inspector
		FROM Numbered_Inspectors
		GROUP BY DDBH, DepNo
	),


	-- 3. PASS 摘要 (維持原樣)
	QCR_Pass_Summary AS (
		SELECT
			DDBH, DepNo,
			SUM(CASE WHEN stage = 1 THEN OKQty ELSE 0 END) AS TQC1_Pass_Qty,
			SUM(CASE WHEN stage = 2 THEN OKQty ELSE 0 END) AS TQC2_Pass_Qty,
			SUM(CASE WHEN stage = 3 THEN OKQty ELSE 0 END) AS TQC3_Pass_Qty
		FROM QCRMain
		WHERE userdate >= @startTime AND userdate < @endTime AND stage IN (1,2,3)
		GROUP BY DDBH, DepNo
	),

	-- 4. DEFECT 摘要 (維持原樣)
	Defect_Summary AS (
		SELECT
			qcr.SCBH, qcr.DepNo,
			SUM(qcrd.Qty) AS TQC_Defect_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q1%' AND RIGHT(qcrd.YYBH,1) NOT IN ('B','C') THEN qcrd.Qty ELSE 0 END) AS TQC1_Total_Defect_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q2%' AND RIGHT(qcrd.YYBH,1) NOT IN ('B','C') THEN qcrd.Qty ELSE 0 END) AS TQC2_Total_Defect_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q3%' AND RIGHT(qcrd.YYBH,1) NOT IN ('B','C') THEN qcrd.Qty ELSE 0 END) AS TQC3_Total_Defect_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q1%B' THEN qcrd.Qty ELSE 0 END) AS TQC1_Bgrade_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q2%B' THEN qcrd.Qty ELSE 0 END) AS TQC2_Bgrade_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q3%B' THEN qcrd.Qty ELSE 0 END) AS TQC3_Bgrade_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q1%C' THEN qcrd.Qty ELSE 0 END) AS TQC1_Cgrade_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q2%C' THEN qcrd.Qty ELSE 0 END) AS TQC2_Cgrade_Qty,
			SUM(CASE WHEN qcrd.YYBH LIKE 'Q3%C' THEN qcrd.Qty ELSE 0 END) AS TQC3_Cgrade_Qty
		FROM qcr
		LEFT JOIN qcrd ON qcr.ProNo = qcrd.ProNo
		WHERE qcr.SCDate >= @startTime AND qcr.SCDate < @endTime AND qcr.GXLB = 'A' AND qcrd.YYBH LIKE 'Q%'
		GROUP BY qcr.SCBH, qcr.DepNo
	),

	-- 5. 組裝產出 (維持原樣)
	Assembly_Output AS (
		SELECT
			SMDD.YSBH AS DDBH, SMZL.DepNO AS DepNo,
			SUM(SMZL.CTS * SMDDSS.Qty) AS assemblyTotalOutput
		FROM SMZL
		LEFT JOIN SMDDSS ON SMDDSS.CODEBAR = SMZL.CODEBAR
		LEFT JOIN SMDD ON SMDD.DDBH = SMDDSS.DDBH AND SMDD.GXLB = SMDDSS.GXLB
		WHERE SMZL.ScanDate >= @startTime AND SMZL.ScanDate < @endTime
		GROUP BY SMDD.YSBH, SMZL.DepNO
	),

	-- 6. PO 基本資訊 (維持原樣)
	PO_Info AS (
		SELECT
			DDZL.DDBH,
			DDZL.KHPO AS poNumber,
			` + getPoTypeQuery(DDBH, "DDZL.DDBH") + `
			@factoryCode AS factoryCode,
			@factoryName AS factoryName,
			kfzl.kfjc AS brand,
			CASE 
				WHEN CHARINDEX('-', DDZL.Article) > 0
					THEN SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1)
				ELSE DDZL.Article
			END AS styleNumber,
			xxzl.XieMing AS styleName,
			CASE 
				WHEN CHARINDEX('-', DDZL.Article) > 0
					THEN SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article))
				ELSE ''
			END AS colorCode,
			'TQC' AS inspectionType,
			CASE
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
			END AS shipId
		FROM DDZL
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb='13'
		WHERE DDZL.DDZT='Y'
	),


	-- 7. 聯集基礎表
	All_QC_Base AS (
		SELECT DDBH, DepNo FROM QCR_Pass_Summary
		UNION
		SELECT SCBH, DepNo FROM Defect_Summary
	)

	-- ================= FINAL SELECT =================
	SELECT
		POI.factoryCode, POI.factoryName, POI.brand, POI.styleNumber, POI.styleName, 
		POI.colorCode, POI.poNumber, POI.poType, POI.shipId,
		
		ISNULL(IL.TQC1_Inspector, '') AS TQC1_Inspector,
		ISNULL(IL.TQC2_Inspector, '') AS TQC2_Inspector,
		ISNULL(IL.TQC3_Inspector, '') AS TQC3_Inspector,

		BASE.DDBH AS SCBH,
		BASE.DepNo,
		` + productionLineNumber + `
		POI.inspectionType,
		@startTime AS startTime,
		@endTime AS endTime,

		ISNULL(QPS.TQC1_Pass_Qty,0) AS TQC1_Pass_Qty,
		ISNULL(QPS.TQC2_Pass_Qty,0) AS TQC2_Pass_Qty,
		ISNULL(QPS.TQC3_Pass_Qty,0) AS TQC3_Pass_Qty,

		ISNULL(DS.TQC_Defect_Qty,0) AS TQC_Defect_Qty,
		ISNULL(DS.TQC1_Total_Defect_Qty,0) AS TQC1_Repair_Qty,
		ISNULL(DS.TQC2_Total_Defect_Qty,0) AS TQC2_Repair_Qty,
		ISNULL(DS.TQC3_Total_Defect_Qty,0) AS TQC3_Repair_Qty,
		
		ISNULL(DS.TQC1_Bgrade_Qty,0) AS TQC1_Bgrade_Qty,
		ISNULL(DS.TQC2_Bgrade_Qty,0) AS TQC2_Bgrade_Qty,
		ISNULL(DS.TQC3_Bgrade_Qty,0) AS TQC3_Bgrade_Qty,
		ISNULL(DS.TQC1_Cgrade_Qty,0) AS TQC1_Cgrade_Qty,
		ISNULL(DS.TQC2_Cgrade_Qty,0) AS TQC2_Cgrade_Qty,
		ISNULL(DS.TQC3_Cgrade_Qty,0) AS TQC3_Cgrade_Qty,

		ISNULL(QPS.TQC3_Pass_Qty,0) AS assemblyTotalInspectionPassQty,
		ISNULL(MAX(AO.assemblyTotalOutput),0) AS assemblyTotalOutput

	FROM All_QC_Base BASE
	LEFT JOIN QCR_Pass_Summary QPS ON BASE.DDBH = QPS.DDBH AND BASE.DepNo = QPS.DepNo
	LEFT JOIN Inspector_List IL ON BASE.DDBH = IL.DDBH AND BASE.DepNo = IL.DepNo
	LEFT JOIN Defect_Summary DS ON BASE.DDBH = DS.SCBH AND BASE.DepNo = DS.DepNo
	LEFT JOIN Assembly_Output AO ON BASE.DDBH = AO.DDBH AND BASE.DepNo = AO.DepNo
	LEFT JOIN PO_Info POI ON BASE.DDBH = POI.DDBH
	LEFT JOIN BDepartment ON BDepartment.ID = BASE.DepNo
	GROUP BY
		POI.factoryCode, POI.factoryName, POI.brand, POI.styleNumber, POI.styleName, 
		POI.colorCode, POI.poNumber, POI.poType, POI.shipId, BASE.DDBH, BASE.DepNo, 
		BDepartment.DepName, POI.inspectionType,
		IL.TQC1_Inspector, IL.TQC2_Inspector, IL.TQC3_Inspector,
		QPS.TQC1_Pass_Qty, QPS.TQC2_Pass_Qty, QPS.TQC3_Pass_Qty,
		DS.TQC_Defect_Qty, DS.TQC1_Total_Defect_Qty, DS.TQC2_Total_Defect_Qty, DS.TQC3_Total_Defect_Qty,
		DS.TQC1_Bgrade_Qty, DS.TQC2_Bgrade_Qty, DS.TQC3_Bgrade_Qty,
		DS.TQC1_Cgrade_Qty, DS.TQC2_Cgrade_Qty, DS.TQC3_Cgrade_Qty
	ORDER BY BASE.DDBH
	`

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"start":       startTime,
		"end":         endTime,
		"gsbh":        GSBH,
	}

	var results []types.TqcQueryResult

	// 1. 查資料
	if err := db.Raw(sqlQuery, queryParams).Scan(&results).Error; err != nil {
		return nil, err
	}

	// 2. 組 InspectorName（重點）
	for i := range results {
		results[i].InspectorName = []string{
			results[i].Inspectors.TQC1Inspector,
			results[i].Inspectors.TQC2Inspector,
			results[i].Inspectors.TQC3Inspector,
		}
	}

	return results, nil

}

func (tqc *TqcRepository) GetTqcDefectReason(databaseType string, startTime, endTime time.Time) ([]types.Reason, error) {

	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlQuery := `
		DECLARE @startTime DATETIME = CAST (@start AS DATETIME);
		DECLARE @endTime DATETIME = CAST (@end AS DATETIME);
		SELECT
			'A' AS DefectLevel,
			Q.SCBH,
			Q.DepNo,
			S.YYBH,
			QS.defect_code,
			SUM(S.Qty) AS Qty
		FROM
			QCR AS Q
			LEFT JOIN QCRD AS S ON Q.ProNo = S.ProNo
			LEFT JOIN QCBLYYKH AS QS ON QS.YYBH = S.YYBH
		WHERE
			S.YYBH LIKE 'Q%'
			AND Q.SCDate >= @startTime
			AND Q.SCDate < @endTime
			AND RIGHT(S.YYBH, 1) NOT IN ('B', 'C')
		GROUP BY Q.SCBH, Q.DepNo, QS.defect_code, S.YYBH, S.YYBH

		UNION ALL

		SELECT
			'B' AS DefectLevel,
			Q.SCBH,
			Q.DepNo,
			S.YYBH,
			QS.defect_code,
			SUM(S.Qty) AS Qty
		FROM
			QCR AS Q
			LEFT JOIN QCRD AS S ON Q.ProNo = S.ProNo
			LEFT JOIN QCBLYYKH AS QS ON QS.YYBH = LEFT(S.YYBH, LEN(S.YYBH)-1)
		WHERE
			S.YYBH LIKE 'Q%B'
			AND Q.SCDate >= @startTime
			AND Q.SCDate < @endTime
		GROUP BY Q.SCBH, Q.DepNo, QS.defect_code, S.YYBH, S.YYBH

		UNION ALL

		SELECT 
			'C' AS DefectLevel,
			Q.SCBH,
			Q.DepNo,
			S.YYBH,
			QS.defect_code,
			SUM(S.Qty) AS Qty
		FROM
			QCR AS Q
			LEFT JOIN QCRD AS S ON Q.ProNo = S.ProNo
			LEFT JOIN QCBLYYKH AS QS ON QS.YYBH = LEFT(S.YYBH, LEN(S.YYBH)-1)
		WHERE
			S.YYBH LIKE 'Q%C'
			AND Q.SCDate >= @startTime
			AND Q.SCDate < @endTime
		GROUP BY Q.SCBH, Q.DepNo, QS.defect_code, S.YYBH, S.YYBH;
	`

	queryParams := map[string]interface{}{
		"start": startTime,
		"end":   endTime,
	}

	var result []types.Reason

	err = db.Raw(sqlQuery, queryParams).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (tqc *TqcRepository) SaveTqcDefectHourly(databaseType string, tqcList []types.TqcOutputPayload) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	return db.Transaction(func(tx *gorm.DB) error {
		query := `
			INSERT INTO AAA ()
			VALUES ()
		`

		params := map[string]interface{}{}

		for _, tqc := range tqcList {
			err = tx.Raw(query, params).Error
			if err != nil {
				log.Printf("failed to save tqc of po: %s\n", tqc.PoNumber)
				continue
			}
		}
		return nil
	})
}
