package repo

import (
	"fmt"
	"strings"
	"web-api/internal/pkg/models/types"
)

type delayWaring struct{}

var DelayWaringRepository delayWaring

func (d *delayWaring) GetDelayWaringOrder(databaseType string) ([]types.DelayWarningOrder, error) {

	db, _, _, _, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	factory := ""

	switch databaseType {
	case "A":
		factory = "YS"
	case "B":
		factory = "TB"
	case "C":
		factory = "YQ"
	}

	sqlQuery := fmt.Sprintf(`
		DECLARE @Today DATE = GETDATE();
 
		WITH TargetOrders AS
		(
			SELECT 
				DDZL.DDBH,
				ShipDate
			FROM DDZL
			WHERE DDZT = 'Y'
			AND ShipDate >= @Today
			AND (
				DDBH LIKE %s
			)
		),
		
		FirstScan AS
		(
			SELECT 
				d.YSBH,
				MIN(COALESCE(z.ScanDate, zd.ScanDate)) AS FirstScanDate
			FROM SMDD d
			JOIN TargetOrders t ON t.DDBH = d.YSBH
			JOIN SMDDSS s 
				ON s.DDBH = d.DDBH
				AND s.GXLB IN ('C','S','O','A')
			LEFT JOIN SMZL z ON z.CODEBAR = s.CODEBAR
			LEFT JOIN SMZLOld zd ON zd.CODEBAR = s.CODEBAR
			GROUP BY d.YSBH
		),
		
		FilterOrder AS 
		(
			SELECT 
				t.DDBH,
				t.ShipDate,
				f.FirstScanDate
			FROM TargetOrders t
				LEFT JOIN FirstScan f ON f.YSBH = t.DDBH
			WHERE
				(
				f.FirstScanDate IS NULL 
				AND @Today > DATEADD(DAY, -21, t.ShipDate)
				)
				OR f.FirstScanDate > DATEADD(DAY,-21,t.ShipDate)
		),

		CuttingCheck AS
		(
			SELECT 
				d.YSBH,
				SUM(all_l.CTS * s.Qty) AS Qty
			FROM FilterOrder o
			JOIN SMDD d 
				ON d.YSBH = o.DDBH
			JOIN SMDDSS s
				ON d.DDBH = s.DDBH
				AND d.GXLB = s.GXLB
				AND s.GXLB = 'C'
			LEFT JOIN (
				SELECT smno,CODEBAR, CTS FROM SMZL
				UNION
				SELECT smno,CODEBAR, CTS FROM SMZLOld
			) AS all_l 
				ON s.CODEBAR = all_l.CODEBAR
			GROUP BY d.YSBH, s.GXLB
		),

		QcCheck AS
		(
			SELECT 
				fo.DDBH,
				CASE 
					WHEN SUM(CASE WHEN qc.QC_Check = 'Fail' THEN 1 ELSE 0 END) > 0 
						THEN 'Fail'
					WHEN SUM(CASE WHEN qc.QC_Check = '' OR qc.QC_Check IS NULL THEN 1 ELSE 0 END) > 0 
						THEN 'Pending'
					ELSE 'Pass'
				END AS inspectionStatus
			FROM FilterOrder fo
				LEFT JOIN MaterialQCcheck_RY qcry
					ON fo.DDBH = qcry.RY
				LEFT JOIN MaterialQCCheck qc
					ON qcry.No_ID = qc.No_ID
			GROUP BY fo.DDBH
		)

		SELECT 
			qc.DDBH,
			xxzl.JiJie AS season,
			@factory AS Factory,
			CASE
				WHEN qc.DDBH LIKE %s
					THEN '20' + LEFT(DDZL.BUYNO, 2) + '-' + SUBSTRING(DDZL.BUYNO, 3, 2)
				ELSE ''
			END AS buyMonth,
			DDZL.KHPO,
			CASE 
				WHEN CHARINDEX('-', DDZL.Article) > 0
					THEN SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1)
				ELSE DDZL.Article
			END AS styleNumber,
			CASE
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
			END AS shipId,
			xxzl.XieMing AS styleName,
			CASE 
				WHEN CHARINDEX('-', DDZL.Article) > 0
					THEN SUBSTRING(
						DDZL.Article,
						CHARINDEX('-', DDZL.Article) + 1,
						LEN(DDZL.Article)
					)
				ELSE ''
			END AS colorCode,
			DDZL.Pairs AS quantity,
			CONVERT(VARCHAR, DDZL.ShipDate, 23) AS confirmXFDate,
			'N 尚未開始一裁' AS cuttingStatus,
			CASE
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
				ELSE SUBSTRING(lbzls.zwsm, CHARINDEX(' ', lbzls.zwsm) + 1, LEN(lbzls.zwsm))
			END AS destination,
			qc.inspectionStatus
		FROM QcCheck qc
			INNER JOIN DDZL ON qc.DDBH = DDZL.DDBH
			LEFT JOIN CuttingCheck cc ON qc.DDBH = cc.YSBH
			LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
			LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb   = '13'
		WHERE 
			cc.Qty = 0
			OR cc.Qty IS NULL
		`,
		getDDBHQueryExceptPreload(DDBH, "DDBH"), getDDBHQueryTypePO(DDBH, "qc.DDBH"))

	queryParams := map[string]interface{}{
		"factory": factory,
	}

	var result []types.DelayWarningOrder

	err = db.Raw(sqlQuery, queryParams).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (d *delayWaring) DoParentCuttingFilter(databaseType string, ddbhList []string) ([]string, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	// Nếu mảng ddbh rỗng, return luôn để tránh lỗi SQL syntax
	if len(ddbhList) == 0 {
		return []string{}, nil
	}

	placeholders := make([]string, len(ddbhList))
	args := make([]interface{}, len(ddbhList))
	for i, ddbh := range ddbhList {
		placeholders[i] = "?"
		args[i] = ddbh
	}

	sqlQuery := fmt.Sprintf(`
        SELECT 
            target.DDBH
        FROM (
            -- 1. Lấy danh sách mã gốc và KHPO dựa trên điều kiện IN truyền từ Golang
            SELECT DDBH, KHPO 
            FROM DDZL 
            WHERE DDBH IN (%s)
        ) target
        JOIN SMDD d 
            ON (d.YSBH = target.DDBH) -- 2a. Khớp chính nó (Mã con)
            OR (
                -- 2b. Khớp mã cha: Bỏ ký tự cuối và kiểm tra cùng KHPO
                RIGHT(target.DDBH, 1) LIKE '[A-Za-z]' 
                AND d.YSBH = SUBSTRING(target.DDBH, 1, LEN(target.DDBH) - 1)
                AND EXISTS (
                    SELECT 1 
                    FROM DDZL parent 
                    WHERE parent.DDBH = d.YSBH 
                    AND parent.KHPO = target.KHPO
                )
            )
        JOIN SMDDSS s 
            ON d.DDBH = s.DDBH 
            AND d.GXLB = s.GXLB 
            AND s.GXLB = 'C'
        LEFT JOIN (
            SELECT smno, CODEBAR, CTS FROM SMZL
            UNION
            SELECT smno, CODEBAR, CTS FROM SMZLOld
        ) AS all_l 
            ON s.CODEBAR = all_l.CODEBAR
        GROUP BY 
            target.DDBH
        -- 3. Sử dụng HAVING để lọc các Qty = 0 hoặc NULL sau khi đã gom nhóm
        HAVING 
            SUM(all_l.CTS * s.Qty) = 0 
            OR SUM(all_l.CTS * s.Qty) IS NULL; 
    `, strings.Join(placeholders, ","))

	var result []string

	// GORM sẽ tự động map cột target.DDBH vào mảng result
	err = db.Raw(sqlQuery, args...).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}
