package repo

import (
	"time"
	"web-api/internal/pkg/models/types"
)

type RqcRepository struct{}

var RqcRepositoryInstance RqcRepository

func (rqc *RqcRepository) GetRqcData(databaseType string, startTime, endTime time.Time) ([]types.RqcResult, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}
	// TB, YQ productionLineNumber: A01_LEAN04_A, A01_LEAN08_C
	// YS productionLineNumber: DT_M-LINE 11A, DT_M-LINE 11B
	productionLineNumber := "BDepartment.DepName AS DepName,"
	if databaseType == "A" {
		productionLineNumber = `
          CASE
              WHEN RIGHT(BDepartment.DepName, 1) IN ('A', 'B', 'C')
                  THEN LEFT(BDepartment.DepName, LEN(BDepartment.DepName) - 1)
              ELSE BDepartment.DepName
          END AS DepName,`
	}

	sqlQuery := `


  DECLARE @startTime DATETIME = CAST (@start AS DATETIME);
  DECLARE @endTime   DATETIME = CAST (@end AS DATETIME);


   -- 1. 取得這段時間內所有的檢驗員清單 (Pass + Defect)
   WITH Raw_Inspectors AS (
       SELECT DISTINCT DDBH, UserID, DepNo FROM QCRMain
       WHERE userdate >= @startTime AND userdate < @endTime AND stage = 0
       UNION
       SELECT DISTINCT qcr.SCBH, qcr.UserID, qcr.DepNo FROM qcr
       INNER JOIN qcrd ON qcr.ProNo = qcrd.ProNo
       WHERE qcr.SCDate >= @startTime AND qcr.SCDate < @endTime
       AND qcr.GXLB = 'A' AND qcrd.YYBH LIKE 'RQ%'
   ),


   -- 2. 為檢驗員排隊 (解決同單據多人的問題)
   Numbered_Inspectors AS (
       SELECT
           DDBH, UserID, DepNo,
           ROW_NUMBER() OVER (PARTITION BY DDBH, DepNo ORDER BY UserID) AS Rnk
       FROM Raw_Inspectors
   ),


   -- 3. 將檢驗員橫向展開 (最多取 3 人)
   Inspector_Flatten AS (
       SELECT
           DDBH, DepNo,
           MAX(CASE WHEN Rnk = 1 THEN UserID ELSE '' END) +
           MAX(CASE WHEN Rnk = 2 THEN ',' + UserID ELSE '' END) +
           MAX(CASE WHEN Rnk = 3 THEN ',' + UserID ELSE '' END) AS Combined_UserID
       FROM Numbered_Inspectors
       GROUP BY DDBH, DepNo
   ),


   -- 4. PASS
   QCR_Pass_Summary AS (
       SELECT
           DDBH, DepNo,
           SUM(OKQty) AS RQC_Pass_Qty
       FROM QCRMain
       WHERE stage = 0 AND userdate >= @startTime AND userdate < @endTime
       GROUP BY DDBH, DepNo
   ),


   -- 5. DEFECT
   Defect_Summary AS (
       SELECT
           qcr.SCBH, qcr.DepNo,
           SUM(qcrd.Qty) AS RQC_Total_Defect_Qty,
           SUM(CASE WHEN qcrd.YYBH LIKE 'RQ%' AND RIGHT(qcrd.YYBH,1) NOT IN ('B','C') THEN qcrd.Qty ELSE 0 END) AS RQC_Defect_Qty,
           SUM(CASE WHEN qcrd.YYBH LIKE 'RQ%B' THEN qcrd.Qty ELSE 0 END) AS RQC_Bgrade_Qty,
           SUM(CASE WHEN qcrd.YYBH LIKE 'RQ%C' THEN qcrd.Qty ELSE 0 END) AS RQC_Cgrade_Qty
       FROM qcr
       LEFT JOIN qcrd ON qcr.ProNo = qcrd.ProNo
       WHERE qcr.SCDate >= @startTime AND qcr.SCDate < @endTime AND qcr.GXLB = 'A' AND qcrd.YYBH LIKE 'RQ%'
       GROUP BY qcr.SCBH, qcr.DepNo
   ),


   -- 6. PO 基本資訊
   PO_Info AS (
       SELECT
           DDZL.DDBH,
           DDZL.KHPO AS poNumber,
           ` + getPoTypeQuery(DDBH, "DDZL.DDBH") + `
           @factoryCode AS factoryCode,
           @factoryName AS factoryName,
           kfzl.kfjc AS brand,




           CASE
               WHEN CHARINDEX('-', DDZL.Article) > 0
                   THEN SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1)
               ELSE DDZL.Article
           END AS styleNumber,




           xxzl.XieMing AS styleName,




           CASE
               WHEN CHARINDEX('-', DDZL.Article) > 0
                   THEN SUBSTRING(
                       DDZL.Article,
                       CHARINDEX('-', DDZL.Article) + 1,
                       LEN(DDZL.Article)
                   )
               ELSE ''
           END AS colorCode,
          
           'RQC' AS inspectionType,
           CASE
               WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
               ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
           END AS shipId
       FROM DDZL
       LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
       LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
       LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb='13'
       WHERE DDZL.DDZT='Y'
   ),


   -- 7. 核心基礎
   All_QC_Base AS (
       SELECT DDBH, DepNo FROM QCR_Pass_Summary
       UNION
       SELECT SCBH, DepNo FROM Defect_Summary
   )


   -- ================= FINAL SELECT =================
   SELECT
       POI.factoryCode, POI.factoryName, POI.brand, POI.styleNumber, POI.styleName,
       POI.colorCode, POI.poNumber, POI.poType, POI.shipId,
       BASE.DDBH AS SCBH,
      
       -- 顯示 "UserA,UserB,UserC"
       ISNULL(IL.Combined_UserID, '') AS RQCInspector,


       BASE.DepNo,
       ` + productionLineNumber + `
       POI.inspectionType,
       @startTime AS startTime,
       @endTime AS endTime,


       ISNULL(QPS.RQC_Pass_Qty, 0) AS rqcPassQty,
       ISNULL(DS.RQC_Total_Defect_Qty, 0) AS RQC_Total_Defect_Qty,
       ISNULL(DS.RQC_Defect_Qty, 0) AS rqcRepairQty,
       ISNULL(DS.RQC_Bgrade_Qty, 0) AS rqcBgradeQty,
       ISNULL(DS.RQC_Cgrade_Qty, 0) AS rqcCgradeQty


   FROM All_QC_Base BASE
   LEFT JOIN QCR_Pass_Summary QPS ON BASE.DDBH = QPS.DDBH AND BASE.DepNo = QPS.DepNo
   LEFT JOIN Defect_Summary DS ON BASE.DDBH = DS.SCBH AND BASE.DepNo = DS.DepNo
   LEFT JOIN Inspector_Flatten IL ON BASE.DDBH = IL.DDBH AND BASE.DepNo = IL.DepNo
   LEFT JOIN PO_Info POI ON BASE.DDBH = POI.DDBH
   LEFT JOIN BDepartment ON BDepartment.ID = BASE.DepNo
   ORDER BY BASE.DDBH;
  `

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"start":       startTime,
		"end":         endTime,
		"gsbh":        GSBH,
	}

	var rqcOutput []types.RqcResult
	err = db.Raw(sqlQuery, queryParams).Scan(&rqcOutput).Error
	if err != nil {
		return nil, err
	}

	return rqcOutput, nil
}

func (rqc *RqcRepository) GetRqcDefectReason(databaseType string, startTime, endTime time.Time) ([]types.Reason, error) {

	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlQuery := `
		DECLARE @startTime DATETIME = CAST (@start AS DATETIME);
		DECLARE @endTime DATETIME = CAST (@end AS DATETIME);
		
		SELECT
			'A' AS DefectLevel,
			Q.SCBH,
			Q.DepNo,
			S.YYBH,
			QS.defect_code,
			SUM(S.Qty) AS Qty
		FROM
			QCR AS Q
			LEFT JOIN QCRD AS S ON Q.ProNo = S.ProNo
			LEFT JOIN QCBLYYKH AS QS ON QS.YYBH = S.YYBH
		WHERE
			S.YYBH LIKE 'RQ%'
			AND Q.SCDate >= @startTime
			AND Q.SCDate < @endTime
			AND RIGHT(S.YYBH, 1) NOT IN ('B', 'C')
		GROUP BY Q.SCBH, Q.DepNo, QS.defect_code, S.YYBH, S.YYBH

		UNION ALL

		SELECT
			'B' AS DefectLevel,
			Q.SCBH,
			Q.DepNo,
			S.YYBH,
			QS.defect_code,
			SUM(S.Qty) AS Qty
		FROM
			QCR AS Q
			LEFT JOIN QCRD AS S ON Q.ProNo = S.ProNo
			LEFT JOIN QCBLYYKH AS QS ON QS.YYBH = LEFT(S.YYBH, LEN(S.YYBH)-1)
		WHERE
			S.YYBH LIKE 'RQ%B'
			AND Q.SCDate >= @startTime
			AND Q.SCDate < @endTime
		GROUP BY Q.SCBH, Q.DepNo, QS.defect_code, S.YYBH, S.YYBH

		UNION ALL

		SELECT 
			'C' AS DefectLevel,
			Q.SCBH,
			Q.DepNo,
			S.YYBH,
			QS.defect_code,
			SUM(S.Qty) AS Qty
		FROM
			QCR AS Q
			LEFT JOIN QCRD AS S ON Q.ProNo = S.ProNo
			LEFT JOIN QCBLYYKH AS QS ON QS.YYBH = LEFT(S.YYBH, LEN(S.YYBH)-1)
		WHERE
			S.YYBH LIKE 'RQ%C'
			AND Q.SCDate >= @startTime
			AND Q.SCDate < @endTime
		GROUP BY Q.SCBH, Q.DepNo, QS.defect_code, S.YYBH, S.YYBH;
	`

	queryParams := map[string]interface{}{
		"start": startTime,
		"end":   endTime,
	}

	var result []types.Reason

	err = db.Raw(sqlQuery, queryParams).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (rqc *RqcRepository) CheckRQCActive(databaseType string, startTime, endTime time.Time) (bool, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return false, err
	}

	// Dùng TOP 1 hoặc EXISTS để DB dừng tìm kiếm ngay khi có record
	sqlQuery := `
        DECLARE @startTime DATETIME = CAST (@start AS DATETIME);
        DECLARE @endTime DATETIME = CAST (@end AS DATETIME);

        SELECT TOP 1 1
        FROM (
            SELECT DDBH FROM QCRMain
            WHERE stage = 0 AND userdate >= @startTime AND userdate < @endTime
            
            UNION ALL
            
            SELECT qcr.SCBH
            FROM qcr
            LEFT JOIN qcrd ON qcr.ProNo = qcrd.ProNo
            WHERE qcr.SCDate >= @startTime AND qcr.SCDate < @endTime
              AND qcr.GXLB = 'A' AND qcrd.YYBH LIKE 'RQ%'
        ) AS TempCheck;
    `

	queryParams := map[string]interface{}{
		"start": startTime,
		"end":   endTime,
	}

	var exists []int
	// Nếu có data, exists sẽ = 1. Nếu không có data, GORM trả về lỗi ErrRecordNotFound (hoặc giá trị mặc định)
	err = db.Raw(sqlQuery, queryParams).Scan(&exists).Error
	if err != nil {
		return false, err
	}

	// No record found in time range
	if len(exists) == 0 {
		return false, nil
	}

	return exists[0] == 1, nil
}
