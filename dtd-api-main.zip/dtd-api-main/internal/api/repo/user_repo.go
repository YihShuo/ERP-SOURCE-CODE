package repo

import (
	"web-api/internal/pkg/models/request"
	"web-api/internal/pkg/models/types"
	"web-api/internal/pkg/utils"
)

type userRepo struct{}

var UserRepository userRepo

func (u *userRepo) GetUserLogin(request request.AuthRequest) (types.UserInfo, error) {

	var user types.UserInfo

	databaseType, err := utils.GetDatabaseTypeByFactory(request.Factory)
	if err != nil {
		return user, err
	}

	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return user, err
	}

	query := `
		SELECT
			? AS factory,
			USERID AS user_id,
			USERNAME AS username,
			PWD AS password
		FROM Busers
		WHERE USERID = ?
	`
	err = db.Raw(query, request.Factory, request.UserID).First(&user).Error
	if err != nil {
		return user, err
	}
	return user, nil
}
