package repo

import (
	"fmt"
	"time"
	"web-api/internal/integration/deckers"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type epcRepo struct{}

var EpcRepo epcRepo

func (e *epcRepo) SaveEpcData(databaseType string, epcList []deckers.EpcPullingApiResponse) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	dbName := ""
	factoryCode := ""
	switch databaseType {
	case "A":
		dbName = "LIY_TYTHAC"
		factoryCode = "FE12"
	case "B":
		dbName = "LIY_TYBACH"
		factoryCode = "FY10"
	case "C":
		dbName = "LIY_YIHQUAN"
		factoryCode = "FI11"
	}

	return db.Transaction(func(tx *gorm.DB) error {
		for _, epc := range epcList {

			if factoryCode != epc.FactoryCode {
				return fmt.Errorf("Factory Code %s does not match", epc.FactoryCode)
			}

			epc.USERID = "DTD"
			epc.USERDATE = time.Now()

			err = tx.Table(dbName + ".dbo.RFID_DataEPC").
				Clauses(clause.OnConflict{
					Columns: []clause.Column{
						{Name: "RFIDNO"},
					},
					DoNothing: true,
				}).
				Create(&epc).Error

			if err != nil {
				return err
			}
		}
		return nil
	})
}

func (e *epcRepo) CheckExist(databaseType string, epcList []string) ([]string, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	dbName := ""
	switch databaseType {
	case "A":
		dbName = "LIY_TYTHAC"
	case "B":
		dbName = "LIY_TYBACH"
	case "C":
		dbName = "LIY_YIHQUAN"
	}

	var result []string
	err = db.Table(dbName+".dbo.RFID_DataEPC").
		Select("RFIDNO").
		Where("RFIDNO IN ?", epcList).
		Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}
