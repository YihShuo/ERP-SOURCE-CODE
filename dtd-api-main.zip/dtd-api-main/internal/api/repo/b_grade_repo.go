package repo

import (
	"log"
	"web-api/internal/pkg/models/types"
)

type BgradeRepository struct{}

var BgradeRepositoryInstance BgradeRepository

func (bg *BgradeRepository) GetBgradeData(databaseType, date string) ([]types.BgradeInventory, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}
	log.Println(date)

	sqlQuery := `
		DECLARE @startDate DATETIME = CAST(@date AS DATETIME);
		DECLARE @endDate DATETIME = DATEADD(DAY, 1, @startDate);
		DECLARE @year INT = YEAR(@startDate);
		DECLARE @month INT = MONTH(@startDate);

		IF NOT EXISTS (
			SELECT 1 
			FROM BCShoeMonth 
			WHERE KCYEAR = @year 
			AND KCMonth = @month 
			AND Grade = 'B' 
			AND (DDBH LIKE ` + getDDBHQuery(DDBH, "DDBH") + `)
		)
		BEGIN
			-- Nếu không có, lùi startDate về 1 tháng trước và gán lại Year, Month
			DECLARE @prevDate DATETIME = DATEADD(MONTH, -1, @startDate);
			SET @year = YEAR(@prevDate);
			SET @month = MONTH(@prevDate);
		END;

		WITH
		/*========================================================
		STEP 1: Base Stock (Inventory on the 1st of the month)
		========================================================*/
		BaseStock AS (
			SELECT
				BCS.DDBH,
				BCS.Size,
				BCS.Grade,
				CAST(BCS.Qty AS BIGINT) AS Base_Qty
			FROM BCShoeMonth BCS
			WHERE BCS.KCYEAR  = @year
			AND BCS.KCMonth = @month
			AND BCS.Grade   = 'B'
			AND (BCS.DDBH LIKE ` + getDDBHQuery(DDBH, "BCS.DDBH") + `)
		),

		/*========================================================
		STEP 2: Inbound Quantity (after inventory date)
		========================================================*/
		Inbound AS (
			SELECT
				S.DDBH,
				S.Size,
				S.Grade,
				SUM(CAST(S.Qty AS BIGINT)) AS Inbound_Qty
			FROM KCRK_BC H
			INNER JOIN KCRKS_BC S ON H.RKNO = S.RKNO
			WHERE H.GSBH     = @gsbh
			AND H.UserDate >= @startDate
			AND H.UserDate < @endDate
			AND S.Grade    = 'B'
			GROUP BY
				S.DDBH, S.Size, S.Grade
		),

		/*========================================================
		STEP 3: Outbound Quantity (after inventory date)
		========================================================*/
		Outbound AS (
			SELECT
				S.DDBH,
				S.Size,
				S.Grade,
				SUM(CAST(S.Qty AS BIGINT)) AS Outbound_Qty
			FROM KCLL_BC H
			INNER JOIN KCLLs_BC S ON H.LLNO = S.LLNO
			WHERE H.GSBH     = @gsbh
			AND H.UserDate >= @startDate
			AND H.UserDate < @endDate
			AND S.Grade    = 'B'
			GROUP BY
				S.DDBH, S.Size, S.Grade
		),

		/*========================================================
		STEP 4: Final Stock = Base + In - Out
		========================================================*/
		FinalStock AS (
			SELECT
				B.DDBH,
				B.Size,
				B.Grade,
				B.Base_Qty
				+ COALESCE(I.Inbound_Qty,  0)
				- COALESCE(O.Outbound_Qty, 0) AS Stock_Qty
			FROM BaseStock B
			LEFT JOIN Inbound  I
				ON I.DDBH  = B.DDBH
			AND I.Size  = B.Size
			AND I.Grade = B.Grade
			LEFT JOIN Outbound O
				ON O.DDBH  = B.DDBH
			AND O.Size  = B.Size
			AND O.Grade = B.Grade
		),

		/*========================================================
		STEP 5: Order / Style Information
		========================================================*/
		OrderInfo AS (
			SELECT DISTINCT
				KF.kfjc AS Brand,
				D.DDBH,

				-- Style Number
				CASE
					WHEN CHARINDEX('-', D.Article) > 0
						THEN LEFT(D.Article, CHARINDEX('-', D.Article) - 1)
					ELSE D.Article
				END AS StyleNumber,

				X.XieMing AS StyleName,

				-- Color Code
				CASE
					WHEN CHARINDEX('-', D.Article) > 0
						THEN SUBSTRING(
								D.Article,
								CHARINDEX('-', D.Article) + 1,
								LEN(D.Article)
							)
					ELSE ''
				END AS ColorCode
			FROM DDZL D
			LEFT JOIN xxzl X
				ON X.XieXing = D.XieXing
			AND X.SheHao = D.SheHao
			LEFT JOIN kfzl KF
				ON KF.kfdh = D.KHBH
		)

		/*========================================================
		STEP 6: Aggregate B-Grade Inventory by Style
		========================================================*/
		SELECT
			@factoryCode  AS FactoryCode,
			@factoryName AS FactoryName,
			O.Brand,
			O.StyleNumber,
			O.StyleName,
			O.ColorCode,
			@date AS InventoryDate,
			SUM(F.Stock_Qty) AS TotalBGradeQty,
			'B-grade inventory as of end of day' AS Remark
			
		FROM FinalStock F
		LEFT JOIN OrderInfo O
			ON O.DDBH = F.DDBH
		GROUP BY
			O.Brand,
			O.StyleNumber,
			O.StyleName,
			O.ColorCode
		HAVING
    		SUM(F.Stock_Qty) > 0
		ORDER BY
			O.StyleNumber,
			O.ColorCode;
	`

	queryParams := map[string]interface{}{
		"date":        date,
		"gsbh":        GSBH,
		"factoryCode": factoryCode,
		"factoryName": factoryName,
	}

	var bgradeInventory []types.BgradeInventory
	err = db.Raw(sqlQuery, queryParams).Scan(&bgradeInventory).Error
	if err != nil {
		return nil, err
	}

	return bgradeInventory, nil
}

func (bg *BgradeRepository) GetSizeList(databaseType, date string) ([]types.SizeDetail, error) {

	db, _, _, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlQuery := `
		DECLARE @startDate DATETIME = CAST(@date AS DATETIME);
		DECLARE @endDate DATETIME = DATEADD(DAY, 1, @startDate);
		DECLARE @year INT = YEAR(@startDate);
		DECLARE @month INT = MONTH(@startDate);

		IF NOT EXISTS (
			SELECT 1 
			FROM BCShoeMonth 
			WHERE KCYEAR = @year 
			AND KCMonth = @month 
			AND Grade = 'B' 
			AND (DDBH LIKE ` + getDDBHQuery(DDBH, "DDBH") + `)
		)
		BEGIN
			-- Nếu không có, lùi startDate về 1 tháng trước và gán lại Year, Month
			DECLARE @prevDate DATETIME = DATEADD(MONTH, -1, @startDate);
			SET @year = YEAR(@prevDate);
			SET @month = MONTH(@prevDate);
		END;

		WITH
		BaseStock AS (
			SELECT
				BCS.DDBH,
				BCS.Size,
				BCS.Grade,
				CAST(BCS.Qty AS BIGINT) AS Base_Qty
			FROM BCShoeMonth BCS
			WHERE
				BCS.KCYEAR  = @year
				AND BCS.KCMonth = @month
				AND BCS.Grade = 'B'
				AND (BCS.DDBH LIKE ` + getDDBHQuery(DDBH, "BCS.DDBH") + `)
		),
		
		Inbound AS (
			SELECT
				S.DDBH,
				S.Size,
				S.Grade,
				SUM(CAST(S.Qty AS BIGINT)) AS Inbound_Qty
			FROM KCRK_BC H
			INNER JOIN KCRKS_BC S ON H.RKNO = S.RKNO
			WHERE
				H.GSBH = 'VDH'
				AND H.UserDate >= @startDate
				AND H.UserDate <  @endDate
				AND S.Grade = 'B'
			GROUP BY
				S.DDBH, S.Size, S.Grade
		),
		
		Outbound AS (
			SELECT
				S.DDBH,
				S.Size,
				S.Grade,
				SUM(CAST(S.Qty AS BIGINT)) AS Outbound_Qty
			FROM KCLL_BC H
			INNER JOIN KCLLs_BC S ON H.LLNO = S.LLNO
			WHERE
				H.GSBH = 'VDH'
				AND H.UserDate >= @startDate
				AND H.UserDate <  @endDate
				AND S.Grade = 'B'
			GROUP BY
				S.DDBH, S.Size, S.Grade
		),
		
		FinalStock AS (
			SELECT
				B.DDBH,
				B.Size,
				B.Grade,
				B.Base_Qty
				+ COALESCE(I.Inbound_Qty, 0)
				- COALESCE(O.Outbound_Qty, 0) AS Stock_Qty
			FROM BaseStock B
			LEFT JOIN Inbound I
				ON I.DDBH = B.DDBH
			AND I.Size = B.Size
			AND I.Grade = B.Grade
			LEFT JOIN Outbound O
				ON O.DDBH = B.DDBH
			AND O.Size = B.Size
			AND O.Grade = B.Grade
		),
		
		OrderInfo AS (
			SELECT DISTINCT
				D.DDBH,
				CASE
					WHEN CHARINDEX('-', D.Article) > 0
						THEN LEFT(D.Article, CHARINDEX('-', D.Article) - 1)
					ELSE D.Article
				END AS StyleNumber,
				X.XieMing AS StyleName,
				CASE
					WHEN CHARINDEX('-', D.Article) > 0
						THEN SUBSTRING(
							D.Article,
							CHARINDEX('-', D.Article) + 1,
							LEN(D.Article)
						)
					ELSE ''
				END AS ColorCode
			FROM DDZL D
			LEFT JOIN xxzl X
				ON X.XieXing = D.XieXing
			AND X.SheHao  = D.SheHao
		)
		
		SELECT
			O.StyleNumber,
			O.StyleName,
			O.ColorCode,
			F.Size,
			F.Grade,
			SUM(F.Stock_Qty) AS Qty
		FROM FinalStock F
		INNER JOIN OrderInfo O
			ON O.DDBH = F.DDBH
		GROUP BY
			O.StyleNumber,
			O.StyleName,
			O.ColorCode,
			F.Size,
			F.Grade
		HAVING
			SUM(F.Stock_Qty) > 0
		ORDER BY
			O.StyleNumber,
			O.ColorCode,
			F.Size,
			F.Grade;
	`

	params := map[string]interface{}{
		"date": date,
		"gsbh": GSBH,
	}

	var sizeDetailList []types.SizeDetail
	err = db.Raw(sqlQuery, params).Scan(&sizeDetailList).Error
	if err != nil {
		return nil, err
	}

	return sizeDetailList, nil
}

func (bg *BgradeRepository) GetInOutInventory(databaseType, date string) ([]types.IODetail, error) {

	db, _, _, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlQuery := `
		DECLARE @startDate DATETIME = CAST(@date AS DATETIME);
		DECLARE @endDate DATETIME = DATEADD(DAY, 1, @startDate);

		WITH
		/*========================================================
		STEP 1: Inbound Data (IN)
		========================================================*/
		Inbound AS (
			SELECT
				S.DDBH,
				S.Grade,
				S.Size,
				SUM(CAST(S.Qty AS BIGINT)) AS Quantity,
				'IN'  AS IoType,
				NULL  AS Purpose,
				H.CFMDate
			FROM KCRK_BC H
			INNER JOIN KCRKS_BC S
				ON H.RKNO = S.RKNO
			WHERE H.GSBH     = @gsbh
				AND H.UserDate >= @startDate
				AND H.UserDate <  @endDate
				AND S.Grade = 'B'
			GROUP BY
				S.DDBH,
				S.Grade,
				S.Size,
				H.CFMDate
		),

		/*========================================================
		STEP 2: Outbound Data (OUT)
		========================================================*/
		Outbound AS (
			SELECT
				S.DDBH,
				S.Grade,
				S.Size,
				SUM(CAST(S.Qty AS BIGINT)) AS Quantity,
				'OUT' AS IoType,
				H.Purpose,
				H.CFMDate
			FROM KCLL_BC H
			INNER JOIN KCLLs_BC S
				ON H.LLNO = S.LLNO
			WHERE H.GSBH     = @gsbh
				AND H.UserDate >= @startDate
				AND H.UserDate <  @endDate
				AND S.Grade = 'B'
			GROUP BY
				S.DDBH,
				S.Grade,
				S.Size,
				H.Purpose,
				H.CFMDate
		),

		/*========================================================
		STEP 3: Order / Style Information
		========================================================*/
		OrderInfo AS (
			SELECT DISTINCT
				D.DDBH,
				D.KHPO,
				` + getPoTypeQuery(DDBH, "D.DDBH") + `

				-- Style Number
				CASE
					WHEN CHARINDEX('-', D.Article) > 0
						THEN LEFT(D.Article, CHARINDEX('-', D.Article) - 1)
					ELSE D.Article
				END AS StyleNumber,

				X.XieMing AS StyleName,

				-- Color Code
				CASE
					WHEN CHARINDEX('-', D.Article) > 0
						THEN SUBSTRING(
								D.Article,
								CHARINDEX('-', D.Article) + 1,
								LEN(D.Article)
							)
					ELSE ''
				END AS ColorCode
			FROM DDZL D
			LEFT JOIN xxzl X
				ON X.XieXing = D.XieXing
			AND X.SheHao = D.SheHao
			WHERE D.KHPO IS NOT NULL
			AND D.KHPO <> ''
			AND (D.DDBH LIKE ` + getDDBHQuery(DDBH, "D.DDBH") + `)
			AND NOT (
					D.DDBH LIKE '%-B%'
				OR RIGHT(D.DDBH, 2) = 'BG'
				OR D.DDBH LIKE 'DHB%'
				)
		),

		/*========================================================
		STEP 4: Combine IN / OUT (Quantity always positive)
		========================================================*/
		StockIO AS (
			SELECT DDBH, Grade, Size, Quantity, IoType, Purpose, CFMDate
			FROM Inbound
			UNION ALL
			SELECT DDBH, Grade, Size, Quantity, IoType, Purpose, CFMDate
			FROM Outbound
		)

		/*========================================================
		STEP 5: Aggregate by Style & IO Type
		========================================================*/
		SELECT
			S.IoType,
			S.Size,
			OI.KHPO,
			OI.PoType,
			CASE
				WHEN S.IoType = 'IN' THEN 'Assembly Line'
				ELSE ''
			END AS [Source],
			SUM(S.Quantity) AS Io_Qty,
			CASE
				WHEN S.IoType = 'OUT' THEN S.Purpose
				ELSE 'Inspection return'
			END AS Reason,
			OI.StyleNumber,
			OI.StyleName,
			OI.ColorCode,
			S.CFMDate AS [Timestamp]
			
		FROM StockIO S
		INNER JOIN OrderInfo OI
			ON S.DDBH = OI.DDBH
		GROUP BY
			OI.StyleNumber,
			OI.StyleName,
			OI.ColorCode,
			OI.KHPO,
			OI.PoType,
			S.Purpose,
			S.Size,
			S.IoType,
			S.CFMDate
		ORDER BY
			S.IoType,
			OI.StyleNumber,
			OI.ColorCode;
	`

	params := map[string]interface{}{
		"gsbh": GSBH,
		"date": date,
	}

	var inOutInventory []types.IODetail
	err = db.Raw(sqlQuery, params).Scan(&inOutInventory).Error
	if err != nil {
		return nil, err
	}

	return inOutInventory, nil
}

func (bg *BgradeRepository) GetCgradeOut(databaseType, date string) ([]types.IODetail, error) {

	db, _, _, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlQuery := `
		DECLARE @startDate DATETIME = CAST(@date AS DATETIME);
		DECLARE @endDate DATETIME = DATEADD(DAY, 1, @startDate);

		WITH
		/*========================================================
		STEP 1: Outbound Data (OUT)
		========================================================*/
		Outbound AS (
			SELECT
				S.DDBH,
				S.Grade,
				S.Size,
				SUM(CAST(S.Qty AS BIGINT)) AS Quantity,
				'C-Grade OUT' AS IoType,
				H.Purpose,
				H.CFMDate
			FROM KCLL_BC H
			INNER JOIN KCLLs_BC S
				ON H.LLNO = S.LLNO
			WHERE H.GSBH     = @gsbh
			AND H.UserDate >= @startDate
			AND H.UserDate < @endDate
			GROUP BY
				S.DDBH,
				S.Grade,
				S.Size,
				H.Purpose,
				H.CFMDate
		),

		/*========================================================
		STEP 2: Order / Style Information
		========================================================*/
		OrderInfo AS (
			SELECT DISTINCT
				D.DDBH,
				D.KHPO,

				-- Style Number
				CASE
					WHEN CHARINDEX('-', D.Article) > 0
						THEN LEFT(D.Article, CHARINDEX('-', D.Article) - 1)
					ELSE D.Article
				END AS StyleNumber,

				X.XieMing AS StyleName,

				-- Color Code
				CASE
					WHEN CHARINDEX('-', D.Article) > 0
						THEN SUBSTRING(
								D.Article,
								CHARINDEX('-', D.Article) + 1,
								LEN(D.Article)
							)
					ELSE ''
				END AS ColorCode
			FROM DDZL D
			LEFT JOIN xxzl X
				ON X.XieXing = D.XieXing
			AND X.SheHao = D.SheHao
			WHERE D.KHPO IS NOT NULL
			AND D.KHPO <> ''
			AND (D.DDBH LIKE ` + getDDBHQuery(DDBH, "D.DDBH") + `)
			AND NOT (
					D.DDBH LIKE '%-B%'
				OR RIGHT(D.DDBH, 2) = 'BG'
				OR D.DDBH LIKE 'DHB%'
				)
		)

		/*========================================================
		STEP 3: Aggregate C-grade OUT by Style & Purpose
		========================================================*/
		SELECT
			ISNULL(OI.StyleNumber, 'N/A') AS StyleNumber,
			ISNULL(OI.StyleName,  'N/A') AS StyleName,
			ISNULL(OI.ColorCode,  'N/A') AS ColorCode,
			O.IoType,
			SUM(O.Quantity) AS Total_Io_Qty,
			O.Purpose AS Reason,
			O.CFMDate AS [Timestamp]
		FROM Outbound O
		LEFT JOIN OrderInfo OI
			ON O.DDBH = OI.DDBH
		GROUP BY
			ISNULL(OI.StyleNumber, 'N/A'),
			ISNULL(OI.StyleName,  'N/A'),
			ISNULL(OI.ColorCode,  'N/A'),
			O.Grade,
			O.IoType,
			O.Purpose,
			O.CFMDate
		ORDER BY
			StyleNumber,
			ColorCode,
			O.Purpose;
	`

	params := map[string]interface{}{
		"gsbh": GSBH,
		"date": date,
	}

	var cgradeOut []types.IODetail
	err = db.Raw(sqlQuery, params).Scan(&cgradeOut).Error
	if err != nil {
		return nil, err
	}

	return cgradeOut, nil
}
