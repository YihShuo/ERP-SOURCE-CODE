package repo

import (
	"web-api/internal/pkg/models/types"

	"gorm.io/gorm"
)

type poRepo struct{}

var PoRepository poRepo

func (d *poRepo) InsertPoPayload(databaseType string, poPayload types.PoPayload) error {

	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	return db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(&poPayload).Error; err != nil {
			return err
		}
		return nil
	})
}
