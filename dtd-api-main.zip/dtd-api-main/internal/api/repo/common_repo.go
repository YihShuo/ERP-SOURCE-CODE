package repo

import (
	"fmt"
	"web-api/internal/pkg/database"

	"gorm.io/gorm"
)

func setupDatabase(databaseType string) (*gorm.DB, string, string, string, map[string][]string, error) {
	db, factoryCode, factoryName, GSBH, DDBH, err := database.SetupDatabaseConnection(databaseType)
	if err != nil {
		return nil, "", "", "", nil, fmt.Errorf("failed to setup database: %v", err)
	}
	return db, factoryCode, factoryName, GSBH, DDBH, err
}

func getPoTypeQuery(DDBH map[string][]string, columnName string) string {

	poTypeQuery := "CASE "

	for poType, codeList := range DDBH {

		if len(codeList) == 0 {
			continue
		}

		counter := 0
		poTypeQuery += "WHEN " + columnName + " LIKE "

		for _, code := range codeList {
			if counter == 0 {
				poTypeQuery += "'" + code + "'"
			} else {
				poTypeQuery += " OR " + columnName + " LIKE '" + code + "'"
			}
			counter++
		}

		poTypeQuery += " THEN '" + poType + "' "
	}

	poTypeQuery += " ELSE 'PO' END AS poType, "

	return poTypeQuery
}

func getDDBHQueryTypePO(DDBH map[string][]string, columnName string) string {

	DDBHStr := ""
	counter := 0
	DDBHArr := DDBH["PO"]
	for _, code := range DDBHArr {
		if counter == 0 {
			DDBHStr = "'" + code + "'"
		} else {
			DDBHStr += " OR " + columnName + " LIKE '" + code + "'"
		}
		counter++
	}
	return DDBHStr
}

func getDDBHQuery(DDBH map[string][]string, columnName string) string {

	DDBHStr := ""
	counter := 0
	for _, codeList := range DDBH {
		for _, code := range codeList {
			if counter == 0 {
				DDBHStr = "'" + code + "'"
			} else {
				DDBHStr += " OR " + columnName + " LIKE '" + code + "'"
			}
			counter++
		}
	}
	return DDBHStr
}

func getDDBHQueryExceptPreload(DDBH map[string][]string, columnName string) string {

	DDBHStr := ""
	counter := 0
	for poType, codeList := range DDBH {
		if poType == "Preload" {
			continue
		}
		for _, code := range codeList {
			if counter == 0 {
				DDBHStr = "'" + code + "'"
			} else {
				DDBHStr += " OR " + columnName + " LIKE '" + code + "'"
			}
			counter++
		}
	}
	return DDBHStr
}
