package repo

type poBlacklistRepo struct{}

var PoBlacklistRepository poBlacklistRepo

func (p *poBlacklistRepo) GetAllBlacklistPo(databaseType string) ([]string, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	result := []string{}

	err = db.
		Table("po_daily_blacklist").
		Select("KHPO").
		Scan(&result).Error

	if err != nil {
		return nil, err
	}

	return result, nil
}

func (p *poBlacklistRepo) GetBlacklistPoByKHPO(databaseType, khpo string) (string, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return "", err
	}

	result := ""

	err = db.
		Table("po_daily_blacklist").
		Where("KHPO = ?", khpo).
		Select("KHPO").
		First(&result).Error

	if err != nil {
		return "", err
	}

	return result, nil
}

func (p *poBlacklistRepo) InsertPoBlacklist(databaseType string, blacklist []string) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	// bắt đầu transaction
	tx := db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	// nếu lỗi thì rollback
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
		}
	}()

	// prepare statement
	sqlQuery := `
		INSERT INTO po_daily_blacklist (KHPO)
		VALUES (?)
	`

	for _, po := range blacklist {
		if err := tx.Exec(sqlQuery, po).Error; err != nil {
			tx.Rollback()
			return err
		}
	}

	// commit
	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}

func (p *poBlacklistRepo) DeletePoBlacklist(databaseType string, blacklist []string) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	if len(blacklist) == 0 {
		return nil
	}

	tx := db.Begin()
	if tx.Error != nil {
		return tx.Error
	}

	sqlQuery := `
		DELETE FROM po_daily_blacklist
		WHERE KHPO IN (?)
	`

	if err := tx.Exec(sqlQuery, blacklist).Error; err != nil {
		tx.Rollback()
		return err
	}

	return tx.Commit().Error
}
