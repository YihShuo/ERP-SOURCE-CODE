package repo

import (
	"database/sql"
	"fmt"
	"log"
	"strings"
	"time"
	"web-api/internal/pkg/models/types"
)

type RepackingRepository struct{}
type ApprovedByRaw struct {
	Role         string    `gorm:"role"`
	Name         string    `gorm:"name"`
	ApprovedTime time.Time `gorm:"time"`
}

func (r RepackingRepository) GetUserApproved(databaseType string, id string) ([]ApprovedByRaw, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
		SELECT 
			ns.RoleName AS role,
			n.Username AS name,
			n.Created_At AS time
		FROM QCMA q
		LEFT JOIN N44_Approved n ON q.ID = n.ID_WOPR_MA 
		LEFT JOIN N44_Approveds ns ON n.IDRole = ns.ID
		WHERE q.ID = @id
	`
	queryParams := map[string]interface{}{
		"id": id,
	}
	var result []ApprovedByRaw
	err = db.Raw(query, queryParams).Scan(&result).Error
	if err != nil {
		return nil, err
	}
	if len(result) == 0 {
		return nil, sql.ErrNoRows
	}
	log.Println(result)
	return result, nil
}

func (r RepackingRepository) GetApprovedByIDs(databaseType string, ids []string) ([]ApprovedByRaw, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	idSQL := "'" + strings.Join(ids, "','") + "'"

	query := fmt.Sprintf(`
		SELECT 
			ns.RoleName AS role,
			n.Username AS name,
			n.Created_At AS time,
			n.ID_WOPR_MA AS id
		FROM N44_Approved n
		LEFT JOIN N44_Approveds ns ON n.IDRole = ns.ID
		WHERE n.ID_WOPR_MA IN (%s)
	`, idSQL)

	var result []ApprovedByRaw
	err = db.Raw(query).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

var RepackingRepositoryInstance RepackingRepository

func (r *RepackingRepository) GetLotNumbersByDate(databaseType string, targetDate string) ([]string, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
        SELECT LotNumber 
        FROM qcma 
        WHERE CAST(userdate AS DATE) = CAST(? AS DATE)
          AND LEN(LotNumber) >= 13
    `

	var lotNumbers []string
	err = db.Raw(query, targetDate).Scan(&lotNumbers).Error
	if err != nil {
		return nil, err
	}

	return lotNumbers, nil
}

func (r *RepackingRepository) GetIDsByLotNumbers(
	databaseType string,
	lotNumbers []string,
) ([]string, error) {

	// 防禦性機制：如果傳入的陣列是空的，直接回傳找不到，不跑資料庫
	if len(lotNumbers) == 0 {
		return nil, sql.ErrNoRows
	}

	db, _, _, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	// 2. 將 = 改為 IN，並使用位置參數 ?
	query := `
        SELECT DISTINCT q.ID
        FROM QCMA q
        WHERE q.GSBH = ?
          AND q.LotNumber IN ?
    `

	var result []string

	// 3. 依序帶入 GSBH 與 lotNumbers 陣列，GORM 會自動展開 IN 的內容
	err = db.Raw(query, GSBH, lotNumbers).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	if len(result) == 0 {
		return nil, sql.ErrNoRows
	}

	return result, nil
}

func (r *RepackingRepository) GetIDsByPONumber(
	databaseType string,
	khpo string,
) ([]string, error) {

	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	// 2. 將 = 改為 IN，並使用位置參數 ?
	query := `
        SELECT QCMA.ID
		FROM DDZL
			JOIN QCMA ON DDZL.DDBH = QCMA.SCBH
		WHERE DDZL.KHPO = ?
    `

	var result []string

	// 3. 依序帶入 GSBH 與 lotNumbers 陣列，GORM 會自動展開 IN 的內容
	err = db.Raw(query, khpo).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	if len(result) == 0 {
		return nil, sql.ErrNoRows
	}

	return result, nil
}

func (r *RepackingRepository) GetRepairAndRejectReasonsByIDs(
	databaseType string,
	ids []string,
) ([]types.Reason, error) {

	db, _, _, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	if len(ids) == 0 {
		return nil, nil
	}

	idSQL := "'" + strings.Join(ids, "','") + "'"

	query := fmt.Sprintf(`
		SELECT
			kh.defect_code AS defect_code,

			CASE
				WHEN RIGHT(d.YYBH, 1) = 'B' THEN 'RejectB'
				ELSE 'Repair'
			END AS DefectLevel,

			CAST(SUM(d.Qty) AS INT) AS Qty

		FROM QCMA q
		LEFT JOIN QCMAD d
			ON d.ProNo = q.ProNo

		LEFT JOIN QCBLYYKH kh
			ON kh.YYBH =
				CASE
					WHEN LEN(d.YYBH) = 5
						THEN LEFT(d.YYBH, 4)
					ELSE d.YYBH
				END

		WHERE q.GSBH = @gsbh
		  AND kh.defect_code IS NOT NULL
		  AND RIGHT(kh.defect_code, 2) NOT LIKE '-%%'
		  AND RIGHT(d.YYBH, 1) <> 'C'
		  AND q.ID IN (%s)

		GROUP BY
			kh.defect_code,
			CASE
				WHEN RIGHT(d.YYBH, 1) = 'B' THEN 'RejectB'
				ELSE 'Repair'
			END

		ORDER BY kh.defect_code
	`, idSQL)

	queryParams := map[string]interface{}{
		"gsbh": GSBH,
	}

	var result []types.Reason

	err = db.Raw(query, queryParams).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (r *RepackingRepository) GetRepairReasons(databaseType, id string) ([]types.Reason, error) {
	db, _, _, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
		SELECT
			y.defect_code AS defect_code,
			SUM(d.Qty) AS Qty
		FROM QCMA q
		LEFT JOIN QCMAD d ON d.ProNO = q.ProNo
		LEFT JOIN QCBLYYKH y ON y.YYBH = d.YYBH
		WHERE q.GSBH = @gsbh
		  AND y.defect_code IS NOT NULL
		  AND RIGHT(y.defect_code, 2) NOT LIKE '-%'
		  AND q.ID = @id
		GROUP BY y.defect_code
	`
	queryParams := map[string]interface{}{
		"id":   id,
		"gsbh": GSBH,
	}

	var result []types.Reason
	err = db.Raw(query, queryParams).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (r *RepackingRepository) GetRepairReasonsByIDs(
	databaseType string,
	ids []string,
) ([]types.Reason, error) {

	db, _, _, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	if len(ids) == 0 {
		return nil, nil
	}

	idSQL := "'" + strings.Join(ids, "','") + "'"

	query := fmt.Sprintf(`
		SELECT
			y.defect_code AS defect_code,
			SUM(d.Qty) AS Qty
		FROM QCMA q
		LEFT JOIN QCMAD d ON d.ProNO = q.ProNo
		LEFT JOIN QCBLYYKH y ON y.YYBH = d.YYBH
		WHERE q.GSBH = @gsbh
		  AND y.defect_code IS NOT NULL
		  AND RIGHT(y.defect_code, 2) NOT LIKE '-%%'
		  AND q.ID IN (%s)
		GROUP BY y.defect_code
	`, idSQL)

	queryParams := map[string]interface{}{
		"gsbh": GSBH,
	}

	var result []types.Reason

	err = db.Raw(query, queryParams).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (r *RepackingRepository) GetSCBH(databaseType, id string) (string, error) {
	db, _, _, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return "", err
	}
	query := `
		SELECT q.SCBH
		FROM QCMA q
		WHERE q.ID = @id
	`
	queryParams := map[string]interface{}{
		"id":   id,
		"gsbh": GSBH,
	}

	var scbh sql.NullString
	err = db.Raw(query, queryParams).Scan(&scbh).Error

	if err == sql.ErrNoRows {
		return "", sql.ErrNoRows
	}
	if err != nil {
		return "", err
	}

	if scbh.Valid {
		return scbh.String, nil
	}
	return "", nil
}

func (r *RepackingRepository) GetCommonInfo(databaseType string, id string) (*types.RepackingResult, error) {
	db, factoryCode, factoryName, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
		SELECT
			@factoryCode AS factoryCode,
			@factoryName AS factoryName,
			kfzl.kfjc AS brand,
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
			xxzl.XieMing AS styleName,
			SUBSTRING(
				DDZL.Article,
				CHARINDEX('-', DDZL.Article) + 1,
				LEN(DDZL.Article)
			) AS colorCode,
			DDZL.KHPO AS poNumber,
			CASE 
				WHEN DDZL.DDBH LIKE 'DHK%' THEN 'Seeding'
				WHEN DDZL.DDBH LIKE 'DH%' OR DDZL.DDBH LIKE 'DE%' THEN 'PO'
				WHEN DDZL.DDBH LIKE 'F%' THEN 'Preload'
				ELSE 'PO'
			END AS poType,
			CASE
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ''
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
			END AS shipId,
			BDepartment.DepName AS DepName,
			'Repacking' AS inspectionType,
			QCMA.USERDATE AS inspectTime,
			QCMA.LotNumber AS LotNumber
		FROM QCMA 
		LEFT JOIN DDZL ON DDZL.DDBH = QCMA.SCBH
		LEFT JOIN BDepartment ON BDepartment.ID = QCMA.DepNo
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		WHERE QCMA.ID = @id
		  AND DDZL.DDZT = 'Y'
		  AND NOT (
				DDZL.DDBH LIKE '%-B%'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE 'DHB%'
		  )
	`

	var c types.RepackingResult

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"gsbh":        GSBH,
		"id":          id,
	}

	err = db.Raw(query, queryParams).Scan(&c).Error
	if err == sql.ErrNoRows {
		return nil, sql.ErrNoRows
	}
	if err != nil {
		return nil, err
	}
	vnLoc, _ := time.LoadLocation("Asia/Ho_Chi_Minh")
	t, err := time.ParseInLocation(
		"2006-01-02T15:04:05",
		c.InspectTime.Format("2006-01-02T15:04:05"),
		vnLoc,
	)
	c.InspectTime = t
	return &c, nil
}

func (r *RepackingRepository) GetCommonInfoByLot(databaseType string, LotNumber string) (*types.RepackingResult, error) {
	db, factoryCode, factoryName, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
		SELECT TOP 1
			@factoryCode AS factoryCode,
			@factoryName AS factoryName,
			kfzl.kfjc AS brand,
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
			xxzl.XieMing AS styleName,
			SUBSTRING(
				DDZL.Article,
				CHARINDEX('-', DDZL.Article) + 1,
				LEN(DDZL.Article)
			) AS colorCode,
			DDZL.KHPO AS poNumber,
			CASE 
				WHEN DDZL.DDBH LIKE 'DHK%' THEN 'Seeding'
				WHEN DDZL.DDBH LIKE 'DH%' OR DDZL.DDBH LIKE 'DE%' THEN 'PO'
				WHEN DDZL.DDBH LIKE 'F%' THEN 'Preload'
				ELSE 'PO'
			END AS poType,
			CASE
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ''
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
			END AS shipId,
			BDepartment.DepName AS DepName,
			'Repacking' AS inspectionType,
			QCMA.USERDATE AS inspectTime,
			QCMA.LotNumber AS LotNumber
		FROM QCMA 
		LEFT JOIN DDZL ON DDZL.DDBH = QCMA.SCBH
		LEFT JOIN BDepartment ON BDepartment.ID = QCMA.DepNo
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		WHERE QCMA.LotNumber = @LotNumber
		  AND DDZL.DDZT = 'Y'
		  AND NOT (
				DDZL.DDBH LIKE '%-B%'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE 'DHB%'
		  )
		ORDER BY QCMA.USERDATE DESC
	`

	var c types.RepackingResult

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"LotNumber":   LotNumber,
	}

	err = db.Raw(query, queryParams).Scan(&c).Error
	if err == sql.ErrNoRows {
		return nil, sql.ErrNoRows
	}
	if err != nil {
		return nil, err
	}

	// 時區轉換（保留你原本邏輯）
	vnLoc, _ := time.LoadLocation("Asia/Ho_Chi_Minh")
	t, err := time.ParseInLocation(
		"2006-01-02T15:04:05",
		c.InspectTime.Format("2006-01-02T15:04:05"),
		vnLoc,
	)
	if err == nil {
		c.InspectTime = t
	}

	return &c, nil
}

func (r *RepackingRepository) GetCommonInfoByPONumber(databaseType string, khpo string) (*types.RepackingResult, error) {
	db, factoryCode, factoryName, _, DDBHMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
		SELECT TOP 1
			@factoryCode AS factoryCode,
			@factoryName AS factoryName,
			kfzl.kfjc AS brand,
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
			xxzl.XieMing AS styleName,
			SUBSTRING(
				DDZL.Article,
				CHARINDEX('-', DDZL.Article) + 1,
				LEN(DDZL.Article)
			) AS colorCode,
			DDZL.KHPO AS poNumber,
			` + getPoTypeQuery(DDBHMap, "DDZL.DDBH") + `
			CASE
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ''
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
			END AS shipId,
			BDepartment.DepName AS DepName,
			'Repacking' AS inspectionType,
			QCMA.USERDATE AS inspectTime,
			QCMA.LotNumber AS LotNumber
		FROM QCMA 
		LEFT JOIN DDZL ON DDZL.DDBH = QCMA.SCBH
		LEFT JOIN BDepartment ON BDepartment.ID = QCMA.DepNo
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		WHERE DDZL.KHPO = @khpo
		  AND DDZL.DDZT = 'Y'
		  AND NOT (
				DDZL.DDBH LIKE '%-B%'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE 'DHB%'
		  )
		ORDER BY QCMA.USERDATE DESC
	`

	var c types.RepackingResult

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"khpo":        khpo,
	}

	err = db.Raw(query, queryParams).Scan(&c).Error
	if err == sql.ErrNoRows {
		return nil, sql.ErrNoRows
	}
	if err != nil {
		return nil, err
	}

	// 時區轉換（保留你原本邏輯）
	vnLoc, _ := time.LoadLocation("Asia/Ho_Chi_Minh")
	t, err := time.ParseInLocation(
		"2006-01-02T15:04:05",
		c.InspectTime.Format("2006-01-02T15:04:05"),
		vnLoc,
	)
	if err == nil {
		c.InspectTime = t
	}

	return &c, nil
}

func (r *RepackingRepository) GetInspectedQty(databaseType, id string) (int, error) {

	db, _, _, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return 0, err
	}
	query := `
		SELECT ISNULL((q.InsQty), 0)
		FROM WOPR_MA q
		WHERE q.GSBH = @gsbh
		  AND q.ID = @id
	`
	queryParams := map[string]interface{}{
		"id":   id,
		"gsbh": GSBH,
	}

	var inspectedQty int
	err = db.Raw(query, queryParams).Scan(&inspectedQty).Error
	if err == sql.ErrNoRows {
		return 0, sql.ErrNoRows
	}
	if err != nil {
		return 0, err
	}
	return inspectedQty, nil
}
func (r *RepackingRepository) GetInspectedQtyByIDs(databaseType string, ids []string) (int, error) {

	db, _, _, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return 0, err
	}

	if len(ids) == 0 {
		return 0, nil
	}

	// 組 IN SQL
	idListSQL := "'" + strings.Join(ids, "','") + "'"

	query := fmt.Sprintf(`
		SELECT ISNULL(SUM(q.InsQty), 0)
		FROM WOPR_MA q
		WHERE q.GSBH = @gsbh
		  AND q.ID IN (%s)
	`, idListSQL)

	queryParams := map[string]interface{}{
		"gsbh": GSBH,
	}

	var inspectedQty int
	err = db.Raw(query, queryParams).Scan(&inspectedQty).Error
	if err != nil {
		return 0, err
	}

	return inspectedQty, nil
}
