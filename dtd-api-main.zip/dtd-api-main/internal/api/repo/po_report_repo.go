package repo

import (
	"fmt"
	"time"
	"web-api/internal/pkg/models/types"

	"gorm.io/gorm"
)

type poReportRepo struct{}

var PoReportRepository poReportRepo

func (p *poReportRepo) GetDashboardResentPo(khpo, startDate, endDate, databaseType string) ([]types.POExcelReport, error) {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
		SELECT 
			id, 
			CONVERT(VARCHAR, report_date, 23) AS report_date,
			khpo, 
			style_no, 
			color_code, 
			ship_id, 
			status, 
			quantity, 
			return_id,
			rm01, rm03, wip31, wip33, wip6, wip8, fg10, fg14, wip31output, wip33output, wip6output, wip8output
		FROM 
			po_daily
		WHERE 
			dashboard_resent = 1
	`

	var args []interface{}

	if khpo != "" {
		query += " AND khpo = ?"
		args = append(args, khpo)
	}
	if startDate != "" {
		start, err := time.Parse("2006-01-02", startDate)
		if err != nil {
			return nil, fmt.Errorf("startDate không hợp lệ: %w", err)
		}
		query += " AND report_date >= ?"
		args = append(args, start)
	}
	if endDate != "" {
		end, err := time.Parse("2006-01-02", endDate)
		if err != nil {
			return nil, fmt.Errorf("endDate không hợp lệ: %w", err)
		}
		query += " AND report_date <= ?"
		args = append(args, end)
	}

	query += " ORDER BY khpo, report_date"

	var result []types.POExcelReport

	err = db.Raw(query, args...).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (p *poReportRepo) GetUnsyncPo(date, databaseType string) ([]types.UnsyncPo, error) {
	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
		DECLARE @date DATE = CAST(@paramDate AS DATE); 
		DECLARE @start DATETIME = DATEADD(HOUR, -2, CAST(@date AS DATETIME));  
		DECLARE @end DATETIME = DATEADD(HOUR, 22, CAST(@date AS DATETIME)); 

		WITH ListKHPO AS ( 
			-- Lấy danh sách KHPO có biến động trong khoảng thời gian @start đến @end
			SELECT DISTINCT DDZL.KHPO 
			FROM YWCP  
			INNER JOIN DDZL ON DDZL.DDBH = YWCP.DDBH 
			WHERE DDZL.KHPO > ''
			AND ( 
				(YWCP.EXEDATE >= @start AND YWCP.EXEDATE < @end) OR  
				(YWCP.INDATE  >= @start AND YWCP.INDATE  < @end) OR  
				(YWCP.REDATE  >= @start AND YWCP.REDATE  < @end) 
			) 

			UNION 

			SELECT DISTINCT DDZL.KHPO 
			FROM SMDD  
			INNER JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH AND SMDD.GXLB = SMDDSS.GXLB 
			INNER JOIN DDZL ON DDZL.DDBH = SMDD.YSBH 
			WHERE SMDDSS.ScanEDate >= @start AND SMDDSS.ScanEDate < @end 

			UNION 

			SELECT DISTINCT DDZL.KHPO 
			FROM KCRK 
			LEFT JOIN KCRKS ON KCRK.RKNO = KCRKS.RKNO 
			INNER JOIN DDZL ON DDZL.DDBH = KCRKS.CGBH 
			WHERE KCRK.CFMDATE >= @start AND KCRK.CFMDATE < @end 
			AND KCRK.GSBH = @gsbh
			AND ( 
				KCRKS.CGBH LIKE %s
			) 
		), 

		FG AS ( 
			-- Tính toán số lượng FG10 và FG14 từ hệ thống kho
			SELECT 
				
				%s
				D.KHPO, 
				CASE  
					WHEN CHARINDEX('-', D.ARTICLE) > 0 
						THEN SUBSTRING(D.ARTICLE, 1, CHARINDEX('-', D.ARTICLE) - 1) 
					ELSE D.ARTICLE 
				END AS style_number, 
				CASE  
					WHEN CHARINDEX('-', D.ARTICLE) > 0 
						THEN SUBSTRING(D.ARTICLE, CHARINDEX('-', D.ARTICLE) + 1, LEN(D.ARTICLE)) 
					ELSE NULL 
				END AS color_code, 
				CASE  
					WHEN CHARINDEX(' ', L.zwsm) <= 1 THEN ' ' 
					ELSE SUBSTRING(L.zwsm, 1, CHARINDEX(' ', L.zwsm) - 1) 
				END AS ship_id, 
				Y.DDBH, 
				D.Dest, 
				D.Pairs, 
				SUM(CASE WHEN Y.SB IN ('1','2','3','4') THEN Y.Qty ELSE 0 END) AS FG10_Qty, 
				SUM(CASE WHEN Y.SB = '3' THEN Y.Qty ELSE 0 END) AS FG14_Qty 
			FROM YWCP AS Y 
			LEFT JOIN DDZL AS D ON D.DDBH = Y.DDBH 
			LEFT JOIN lbzls AS L ON L.lbdh = D.Dest AND L.lb = '13' 
			WHERE Y.SB IN ('1','2','3','4')    
			AND D.DDZT = 'Y' 
			AND D.GSBH = @gsbh
			GROUP BY 
				Y.DDBH, D.KHPO, D.Pairs, D.Dest, D.ARTICLE, L.zwsm 
		), 

		FG_KEY AS ( 
			-- Lọc các mã khác biệt từ kho
			SELECT DISTINCT 
				KHPO, 
				style_number, 
				color_code, 
				ship_id 
			FROM FG 
			WHERE FG10_Qty <> FG14_Qty 
		), 

		DTD AS ( 
			-- DTD (Lấy dữ liệu tracking mới nhất)
			SELECT * FROM ( 
				SELECT *, 
					ROW_NUMBER() OVER ( 
						PARTITION BY khpo, style_no, color_code, ship_id 
						ORDER BY report_date DESC 
					) AS rn 
				FROM po_daily 
			) t 
			WHERE rn = 1 
		), 

		DTD_KEY AS ( 
			-- Lọc các mã khác biệt từ DTD
			SELECT DISTINCT 
				khpo, 
				style_no AS style_number, 
				color_code, 
				ship_id 
			FROM DTD 
			WHERE fg10 <> fg14 
		), 

		ALL_KEYS AS ( 
			-- Tổng hợp Key khác biệt để kiểm tra
			SELECT KHPO, style_number, color_code, ship_id FROM FG_KEY 
			UNION 
			SELECT KHPO, style_number, color_code, ship_id FROM DTD_KEY 
		) 

		-- KẾT QUẢ CUỐI CÙNG
		SELECT 
			@factoryCode AS factoryCode,    
			@factoryName AS factoryName, 
			FG.poType AS po_type, 
			K.KHPO, 
			K.style_number, 
			K.color_code, 
			K.ship_id, 

			ISNULL(DTD.fg10, 0) AS dtd_tracking_fg10, 
			ISNULL(SUM(FG.FG10_Qty), 0) AS factory_warehouse_fg10, 

			ISNULL(DTD.fg14, 0) AS dtd_tracking_fg14, 
			ISNULL(SUM(FG.FG14_Qty), 0) AS factory_warehouse_fg14, 

			-- Chênh lệch
			ISNULL(SUM(FG.FG10_Qty), 0) - ISNULL(DTD.fg10, 0) AS diff_fg10, 
			ISNULL(SUM(FG.FG14_Qty), 0) - ISNULL(DTD.fg14, 0) AS diff_fg14, 

			-- Trạng thái khớp dữ liệu
			CASE  
				WHEN ISNULL(SUM(FG.FG10_Qty), 0) <> ISNULL(DTD.fg10, 0) 
				OR ISNULL(SUM(FG.FG14_Qty), 0) <> ISNULL(DTD.fg14, 0) 
				THEN 0 
				ELSE 1 
			END AS is_match, 
			DTD.return_id 

		FROM ALL_KEYS K 

		LEFT JOIN FG  
			ON FG.KHPO = K.KHPO 
		AND FG.style_number = K.style_number 
		AND FG.color_code = K.color_code 
		AND ( 
			FG.ship_id = K.ship_id 
			OR ISNULL(FG.ship_id, ' ') = ' ' 
			OR ISNULL(K.ship_id, ' ') = ' '
		) 

		LEFT JOIN DTD 
			ON DTD.KHPO = K.KHPO 
		AND DTD.style_no = K.style_number 
		AND DTD.color_code = K.color_code 
		AND ( 
			DTD.ship_id = K.ship_id 
			OR DTD.ship_id IS NULL 
			OR K.ship_id IS NULL 
		) 

		WHERE NOT EXISTS ( 
			SELECT 1  
			FROM ListKHPO L 
			WHERE L.KHPO = K.KHPO 
		) 

		GROUP BY 
			FG.poType, 
			K.KHPO, 
			K.style_number, 
			K.color_code, 
			K.ship_id, 
			DTD.fg10, 
			DTD.fg14, 
			DTD.return_id 

		HAVING  
			ISNULL(SUM(FG.FG10_Qty), 0) <> ISNULL(DTD.fg10, 0) 
			OR ISNULL(SUM(FG.FG14_Qty), 0) <> ISNULL(DTD.fg14, 0) 

		ORDER BY  
			diff_fg10,     
			K.KHPO, 
			K.style_number,  
			K.color_code,  
			K.ship_id;
	`

	query = fmt.Sprintf(
		query,
		getDDBHQuery(DDBH, "KCRKS.CGBH"),
		getPoTypeQuery(DDBH, "Y.DDBH"),
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"gsbh":        GSBH,
		"paramDate":   date,
	}

	var result []types.UnsyncPo
	err = db.Raw(query, queryParams).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (p *poReportRepo) SaveXFDetail(databaseType string, XFDetailList []types.XFDetailQuery, poDailyID uint) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	if len(XFDetailList) == 0 {
		return nil
	}

	for index := range XFDetailList {
		XFDetail := &XFDetailList[index]
		XFDetail.PoDailyID = poDailyID
	}

	return db.Transaction(func(tx *gorm.DB) error {

		for _, XFDetail := range XFDetailList {
			if err := tx.Create(&XFDetail).Error; err != nil {
				return err
			}
		}

		return nil
	})
}
