package services

import (
	"web-api/internal/api/repo"
	"web-api/internal/integration/deckers"
	"web-api/internal/pkg/models/types"
)

type dtdTrackingService struct {
}

var DtdTrackingService = &dtdTrackingService{}

func (d *dtdTrackingService) GetEPCPulling(token, factoryWorkOrder, po, commandNumber string) ([]deckers.EpcPullingApiResponse, error) {
	rawData, err := deckers.DeckerClient.GetEPCPulling(token, factoryWorkOrder, po, commandNumber)
	if err != nil {
		return nil, err
	}
	result := []deckers.EpcPullingApiResponse{}
	for _, rawEpc := range rawData {
		result = append(result, rawEpc.Parse(rawEpc))
	}
	return result, nil
}

func (d *dtdTrackingService) SaveEPCPulling(databaseType string, epcList []deckers.EpcPullingApiResponse) error {

	err := repo.EpcRepo.SaveEpcData(databaseType, epcList)
	if err != nil {
		return err
	}

	return nil
}

func (d *dtdTrackingService) CheckEpcInDatabase(databaseType string, epcList []string) (map[string]bool, error) {

	dbEpcList, err := repo.EpcRepo.CheckExist(databaseType, epcList)
	if err != nil {
		return nil, err
	}

	epcResultMap := make(map[string]bool, len(epcList))
	subMap := make(map[string]struct{}, len(dbEpcList))

	for _, epc := range dbEpcList {
		subMap[epc] = struct{}{}
	}

	for _, epc := range epcList {
		_, exists := subMap[epc]
		epcResultMap[epc] = exists
	}

	return epcResultMap, nil
}

func (d *dtdTrackingService) GetUnsyncPo(date, databaseType string) ([]types.UnsyncPo, error) {

	result, err := repo.PoReportRepository.GetUnsyncPo(date, databaseType)
	if err != nil {
		return nil, err
	}
	return result, nil
}
