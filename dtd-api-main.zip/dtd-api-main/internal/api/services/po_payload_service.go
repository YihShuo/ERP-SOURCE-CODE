package services

import (
	"web-api/internal/api/repo"
	"web-api/internal/pkg/models/types"
)

type poPayload struct{}

var PoPayloadService poPayload

func (p *poPayload) InsertPoPayload(payload, databaseType, returnID, date, userID, postId string, batchNo int) error {

	poPayload := types.PoPayload{
		SentDate:    date,
		BatchNumber: batchNo,
		Payload:     payload,
		ReturnID:    returnID,
		UserID:      userID,
		PostId:      postId,
	}

	err := repo.PoRepository.InsertPoPayload(databaseType, poPayload)
	if err != nil {
		return err
	}
	return nil
}

func (p *poPayload) ExtractPayload(poList []types.DailyPoStatus, batchNo int, date, returnID string) types.PoPayload {

	return types.PoPayload{
		SentDate:    date,
		BatchNumber: batchNo,
		Payload:     types.GetStringJson(poList),
		ReturnID:    returnID,
		UserID:      "",
	}
}
