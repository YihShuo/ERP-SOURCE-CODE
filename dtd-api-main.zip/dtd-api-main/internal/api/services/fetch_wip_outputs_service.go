package services

import (
	"fmt"
	"strings"
	"time"
	"web-api/internal/pkg/models/types"
)

type outputsWIPService struct {
	*BaseService
}

var OutputsWIPService = &outputsWIPService{}

func (service *outputsWIPService) GetDeckerOutputsWIP(databaseType, date string) ([]types.DeckerOutput, error) {
	// Calculate startTime and endTime
	startTime, endTime, err := calculateTimes(date)
	if err != nil {
		return nil, err
	}

	// Connect DB and get init values
	db, factoryCode, factoryName, _, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	// TB, YQ productionLineNumber: A01_LEAN04_A, A01_LEAN08_C
	// YS productionLineNumber: DT_M-LINE 11A, DT_M-LINE 11B
	productionLineNumber := "BDepartment.DepName AS productionLineNumber,"
	if databaseType == "A" {
		productionLineNumber = `
			CASE 
				WHEN RIGHT(BDepartment.DepName, 1) IN ('A', 'B', 'C') 
					THEN LEFT(BDepartment.DepName, LEN(BDepartment.DepName) - 1)
				ELSE BDepartment.DepName 
			END AS productionLineNumber,`
	}

	// SQL query
	query := `SELECT 
				'' AS startTime,
				'' AS endTime,
				? AS factoryCode,
				? AS factoryName,
				SMDDSS.GXLB AS stageCode,
				'Core' AS productionLineType,
				` + productionLineNumber + `
				DDZL.KHPO AS po,
				CASE 
					WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
					WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
					ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
				END AS shipId,
				SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
				xxzl.XieMing AS styleName,
				SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
				SMDDSS.XXCC AS sizeNumber,
				CONVERT(INT, SUM(SMZL.CTS * SMDDSS.Qty)) AS output,
				'1h' AS logType,
				kfzl.kfjc AS brand,
				SMDD.YSBH AS factoryWorkOrderNumber,
				DDZL.Pairs AS factoryWorkOrderQuantity
			FROM SMZL
			LEFT JOIN SMDDSS ON SMDDSS.CODEBAR = SMZL.CODEBAR
			LEFT JOIN SMDD ON SMDD.DDBH = SMDDSS.DDBH AND SMDD.GXLB = SMDDSS.GXLB
			LEFT JOIN DDZL ON DDZL.DDBH = SMDD.YSBH 
			LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
			LEFT JOIN BDepartment ON SMZL.DepNO = BDepartment.ID
			LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
			LEFT JOIN xxzl ON DDZL.XieXing = xxzl.XieXing AND DDZL.SheHao = xxzl.SheHao
			WHERE 
				DATEPART(HOUR, SMZL.ScanDate) = ?
				AND CONVERT(VARCHAR, SMZL.ScanDate, 23) = CONVERT(DATE, ?)
				AND (SMDD.YSBH LIKE ` + getDDBHQuery(DDBH, "SMDD.YSBH") + `)
			GROUP BY 
				BDepartment.DepName, 
				DDZL.KHPO, 
				DDZL.DDGB, 
				DDZL.Article, 
				DDZL.Pairs, 
				xxzl.XieMing, 
				SMDD.YSBH, 
				SMDDSS.GXLB, 
				SMDDSS.XXCC, 
				kfzl.kfjc, 
				lbzls.zwsm
			ORDER BY SMDDSS.GXLB;`

	// Params for query
	queryParams := []interface{}{
		factoryCode,
		factoryName,
		startTime.Hour(),
		date,
	}

	// Execute query
	var outputs []types.DeckerOutput
	if err := db.Raw(query, queryParams...).Scan(&outputs).Error; err != nil {
		return nil, fmt.Errorf("failed to execute query: %v", err)
	}

	// Processing result output
	processOutputs(outputs, startTime, endTime)

	return outputs, nil
}
func calculateTimes(date string) (startTime, endTime time.Time, err error) {
	dateTimeFormat := "2006-01-02 15:04:05"
	parsedTime, err := time.Parse(dateTimeFormat, date)
	if err != nil {
		parsedTime, err = time.Parse("2006-01-02", date)
		if err != nil {
			return time.Time{}, time.Time{}, fmt.Errorf("error parsing time: %v", err)
		}
	}

	// Set timezone location (GMT+7)
	location := time.FixedZone("GMT+7", 7*60*60)

	// Calculate startTime and endTime
	endTime = time.Date(parsedTime.Year(), parsedTime.Month(), parsedTime.Day(), parsedTime.Hour(), 29, 59, 0, location)
	startTime = endTime.Add(-1 * time.Hour).Add(1 * time.Second)

	return startTime, endTime, nil
}

func processOutputs(outputs []types.DeckerOutput, startTime, endTime time.Time) {
	for index := range outputs {
		row := &outputs[index]

		// Save value of Po and ShipId to PoList
		row.PoList = []types.PoItem{
			{Po: row.Po, ShipId: row.ShipId},
		}

		// Set StartTime and EndTime by calculated time
		row.StartTime = startTime.Format("2006-01-02T15:04:05-07:00")
		row.EndTime = endTime.Format("2006-01-02T15:04:05-07:00")

		// Change StageCode
		switch row.StageCode {
		case "C":
			row.StageCode = "WIP3-1"
		case "O":
			row.StageCode = "WIP3-3"
		case "S":
			row.StageCode = "WIP6"
		case "A":
			row.StageCode = "WIP8"
		}

		// Trim size number
		row.SizeNumber = strings.TrimSpace(row.SizeNumber)
	}
}

func (service *outputsWIPService) GetDeckerOutputsWIPByDate(databaseType, date string) ([]types.WIPExcelResult, error) {

	// Connect DB and get init values
	db, _, _, _, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	// SQL query
	query := `	DECLARE @Date DATE = CAST(? AS DATE)

				SELECT
					CONVERT(VARCHAR, @Date, 23) AS Date,
					DDZL.KHPO AS KHPO,
					SMDD.YSBH AS DDBH,
					SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS StyleNumber,
					SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS ColorCode,
					CASE 
						WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
						WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
						ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
					END AS ShipID,
					DDZL.Pairs AS Qty,
					SMDDSS.GXLB AS StageCode,
					CONVERT(INT, SUM(SMZL.CTS * SMDDSS.Qty)) AS Output
				FROM SMZL
				LEFT JOIN SMDDSS ON SMDDSS.CODEBAR = SMZL.CODEBAR
				LEFT JOIN SMDD ON SMDD.DDBH = SMDDSS.DDBH AND SMDD.GXLB = SMDDSS.GXLB
				LEFT JOIN DDZL ON DDZL.DDBH = SMDD.YSBH 
				LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
				WHERE 1=1
					AND SMZL.ScanDate >= @Date
					AND SMZL.ScanDate < DATEADD(DAY, 1, @Date)
					AND (SMDD.YSBH LIKE ` + getDDBHQuery(DDBH, "SMDD.YSBH") + `)
				GROUP BY 
					DDZL.KHPO, 
					DDZL.Article, 
					DDZL.Pairs, 
					SMDD.YSBH, 
					SMDDSS.GXLB, 
					lbzls.zwsm
				ORDER BY KHPO;`

	// Params for query
	queryParams := []interface{}{
		date,
	}

	// Execute query
	var queryWip []types.WIPQueryResult
	if err := db.Raw(query, queryParams...).Scan(&queryWip).Error; err != nil {
		return nil, fmt.Errorf("failed to execute query WIP: %v", err)
	}

	result := extractWIPResult(queryWip)

	return result, nil
}

func extractWIPResult(queryResult []types.WIPQueryResult) []types.WIPExcelResult {
	result := []types.WIPExcelResult{}
	wipMap := make(map[string]types.WIPExcelResult)
	for _, queryWip := range queryResult {
		key := queryWip.KHPO + "_" + queryWip.ColorCode + "_" + queryWip.StyleNumber + "_" + queryWip.ShipID
		excelWip, exist := wipMap[key]
		if !exist {
			excelWip = queryWip.ExtractExcelData()
		}
		switch queryWip.StageCode {
		case "C":
			excelWip.WIP31 = queryWip.Output
		case "O":
			excelWip.WIP33 = queryWip.Output
		case "S":
			excelWip.WIP6 = queryWip.Output
		case "A":
			excelWip.WIP8 = queryWip.Output
		}
		wipMap[key] = excelWip
	}

	for _, wip := range wipMap {
		result = append(result, wip)
	}

	return result
}
