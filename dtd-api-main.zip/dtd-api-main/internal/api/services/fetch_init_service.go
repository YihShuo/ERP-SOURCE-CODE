package services

import (
	"fmt"
	"log"
	"unicode"
	"web-api/internal/integration/deckers"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/models/types"
)

type initializeService struct {
	*BaseService
}

var InitializeService = &initializeService{}

func (s *initializeService) GetProcessingPoYS(databaseType, date string) ([]types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlGetDailyPoStatusData := fmt.Sprintf(`
		WITH UniquePO AS (
			select DDZL.KHPO
			from YWCP
			left join YWDD on YWDD.DDBH=YWCP.DDBH 
			right join DDZL on YWDD.YSBH=DDZl.DDBH 
			where (DDZL.DDBH like %s)
				and DDZL.GSBH=@gsbh 
				and DDZL.ShipDate BETWEEN '2025-01-01' AND GETDATE()
			group by DDZL.KHPO
		)
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			DDZL.KHPO AS poNumber, 
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			xxzl.jijie AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,  
			YWCP.Qty AS poCompletionQuantity,  
			DDZL.Pairs AS poQuantity,  
			'1d' AS logType,  
			kfzl.kfjc AS brand, 
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,  
			0 AS completionQuantity,  
			'sizeNumber' AS sizeNumber,  
			0 AS sizeCompletionQuantity,  
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL  
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh  
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH  
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH  
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR  
		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP  
			ON YWCP.DDBH = DDZL.DDBH  
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao 
		WHERE DDZL.KHPO != '' 
			AND DDZL.KHPO IN (SELECT KHPO FROM UniquePO)
			AND DDZL.DDZT = 'Y'
			AND (DDZL.DDBH like %s)
		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO, xxzl.jijie;
	`, getDDBHQuery(DDBH, "DDZL.DDBH"), getPoTypeQuery(DDBH, "DDZL.DDBH"), getDDBHQuery(DDBH, "DDZL.DDBH"))

	log.Println(sqlGetDailyPoStatusData)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
		"gsbh":        GSBH,
	}
	// 查詢 DailyPoStatus 資料
	var getDailyPoStatusData []types.DailyPoStatus
	err = db.Raw(sqlGetDailyPoStatusData, queryParams).Scan(&getDailyPoStatusData).Error
	if err != nil {
		return nil, err
	}

	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
	for i := range getDailyPoStatusData {
		value := &getDailyPoStatusData[i]
		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		// 獲取 Milestone 資料
		milestoneListData, err := GetMilestoneListInitialData(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH)
		if err != nil {
			return nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
		}

		// 如果有 Milestone 資料，才填充到 MilestoneList
		if len(milestoneListData) > 0 {
			milestoneMap := make(map[string]*types.Milestone)
			for _, ml := range milestoneListData {
				// 根據 StageCode 轉換
				switch ml.StageCode {
				case "C":
					ml.StageCode = "WIP3-1"
				case "O":
					ml.StageCode = "WIP3-3"
				case "S":
					ml.StageCode = "WIP6"
				case "A":
					ml.StageCode = "WIP8"
				}

				if milestone, exists := milestoneMap[ml.StageCode]; exists {
					milestone.CompletionQuantity += ml.CompletionQuantity
					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
				} else {
					milestoneMap[ml.StageCode] = &types.Milestone{
						StageCode:          ml.StageCode,
						CompletionQuantity: ml.CompletionQuantity,
						SizeList:           ml.SizeList,
					}
				}
			}

			var newMilestoneListData []types.Milestone
			for _, milestone := range milestoneMap {
				newMilestoneListData = append(newMilestoneListData, *milestone)
			}

			newMilestoneListData = fillMissingStages(newMilestoneListData)
			sortMilestones(newMilestoneListData)
			resolveConflictingData(newMilestoneListData)
			value.MilestoneList = newMilestoneListData
		}

		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
		for _, milestone := range value.MilestoneList {
			if milestone.StageCode == "WIP8" {
				value.PoCompletionQuantity = milestone.CompletionQuantity
				break // 找到 WIP8 就退出循環
			}
		}

		if value.PoCompletionQuantity == value.PoQuantity {
			value.Status = "001"
		}
	}

	result := mergeDuplicatePOs(getDailyPoStatusData)

	TestPoStatus(result)

	return result, nil
}

func (s *initializeService) GetProcessingPoTB(databaseType, date string) ([]types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlGetDailyPoStatusData := fmt.Sprintf(`
		WITH UniquePO AS (
			select KHPO
			from YWCP
			left join YWDD on YWDD.DDBH=YWCP.DDBH 
			right join DDZL on YWDD.YSBH=DDZl.DDBH 
			left join KFZL on KFZL.KFDH=DDZL.KHBH 
			where 
				(DDZL.DDBH like %s)
				and KFZL.KFJC = 'HOKA'
				and DDZL.GSBH= @gsbh 
				and DDZL.ShipDate BETWEEN '2025-01-01' AND @date
			group by KHPO
		)
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			DDZL.KHPO AS poNumber, 
			%s 
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			xxzl.jijie AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,  
			YWCP.Qty AS poCompletionQuantity,  
			DDZL.Pairs AS poQuantity,  
			'1d' AS logType,  
			kfzl.kfjc AS brand, 
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,  
			0 AS completionQuantity,  
			'sizeNumber' AS sizeNumber,  
			0 AS sizeCompletionQuantity,  
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL  
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh  
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH  
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH  
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR  
		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP  
			ON YWCP.DDBH = DDZL.DDBH  
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
		WHERE DDZL.KHPO != '' 
			AND DDZL.KHPO IN (SELECT KHPO FROM UniquePO)
			AND DDZL.DDZT = 'Y'
			AND (DDZL.DDBH like %s)
		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO, xxzl.jijie;
	`, getDDBHQuery(DDBH, "DDZL.DDBH"), getPoTypeQuery(DDBH, "DDZL.DDBH"), getDDBHQuery(DDBH, "DDZL.DDBH"))

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
		"gsbh":        GSBH,
	}
	// 查詢 DailyPoStatus 資料
	var getDailyPoStatusData []types.DailyPoStatus
	err = db.Raw(sqlGetDailyPoStatusData, queryParams).Scan(&getDailyPoStatusData).Error
	if err != nil {
		return nil, err
	}

	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
	for i := range getDailyPoStatusData {
		value := &getDailyPoStatusData[i]
		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		// 獲取 Milestone 資料
		milestoneListData, err := GetMilestoneListInitialData(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH)
		if err != nil {
			return nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
		}

		// 如果有 Milestone 資料，才填充到 MilestoneList
		if len(milestoneListData) > 0 {
			milestoneMap := make(map[string]*types.Milestone)
			for _, ml := range milestoneListData {
				// 根據 StageCode 轉換
				switch ml.StageCode {
				case "C":
					ml.StageCode = "WIP3-1"
				case "O":
					ml.StageCode = "WIP3-3"
				case "S":
					ml.StageCode = "WIP6"
				case "A":
					ml.StageCode = "WIP8"
				}

				if milestone, exists := milestoneMap[ml.StageCode]; exists {
					milestone.CompletionQuantity += ml.CompletionQuantity
					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
				} else {
					milestoneMap[ml.StageCode] = &types.Milestone{
						StageCode:          ml.StageCode,
						CompletionQuantity: ml.CompletionQuantity,
						SizeList:           ml.SizeList,
					}
				}
			}

			// 根據 StageCode 創建新的 MilestoneList
			var newMilestoneListData []types.Milestone
			for _, milestone := range milestoneMap {
				newMilestoneListData = append(newMilestoneListData, *milestone)
			}

			newMilestoneListData = fillMissingStages(newMilestoneListData)
			sortMilestones(newMilestoneListData)
			resolveConflictingData(newMilestoneListData)
			value.MilestoneList = newMilestoneListData
		}

		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
		for _, milestone := range value.MilestoneList {
			if milestone.StageCode == "WIP8" {
				value.PoCompletionQuantity = milestone.CompletionQuantity
				break // 找到 WIP8 就退出循環
			}
		}

		if value.PoCompletionQuantity == value.PoQuantity {
			value.Status = "001"
		}
	}

	result := mergeDuplicatePOs(getDailyPoStatusData)

	TestPoStatus(result)

	return result, nil
}

func (s *initializeService) GetInitTeva(databaseType, date string) ([]types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlGetDailyPoStatusData := fmt.Sprintf(`
		WITH ListKHPO AS (
			-- Nguồn 1: Bảng YWCP với ngày xuất hoặc ngày nhập
			SELECT DISTINCT DDZL.KHPO
			FROM YWCP 
			INNER JOIN DDZL 
			ON DDZL.DDBH = YWCP.DDBH
			WHERE 
			(
				CONVERT(DATE, YWCP.EXEDATE) >= CONVERT(DATE, @date)
				OR CONVERT(DATE, YWCP.INDATE) >= CONVERT(DATE, @date)
				OR CONVERT(DATE, YWCP.LastInDate) >= CONVERT(DATE, @date)
				OR CONVERT(DATE, YWCP.OUTDATE) >= CONVERT(DATE, @date)
			)
			AND DDZL.KHPO IS NOT NULL
			AND LTRIM(RTRIM(DDZL.KHPO)) <> ''

			
			UNION
			
			-- Nguồn 2: Bảng SMDDSS với ngày quét
			SELECT distinct KHPO
    		FROM SMDDSS 
				INNER JOIN DDZL ON DDZL.DDBH = SMDDSS.DDBH
			WHERE CONVERT(DATE, ScanEDate) >= CONVERT(DATE, @date)
			
			UNION
			
			-- Nguồn 3: Bảng KCRK + KCRKS với ngày xác nhận nhập kho
			SELECT  distinct DDZL.KHPO
			FROM KCRK
			LEFT JOIN KCRKS ON KCRK.RKNO = KCRKS.RKNO
			INNER JOIN DDZL ON DDZL.DDBH = KCRKS.CGBH
			WHERE CONVERT(DATE, CFMDATE) >= CONVERT(DATE, @date)
			AND KCRK.GSBH = @gsbh
			AND (KCRKS.CGBH LIKE %s)
		)
		SELECT
			CONVERT(VARCHAR(10), GETDATE(), 23) AS date,
			DDZL.KHPO AS poNumber, 
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			xxzl.jijie AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,  
			YWCP.Qty AS poCompletionQuantity,  
			DDZL.Pairs AS poQuantity,  
			'1d' AS logType,  
			kfzl.kfjc AS brand, 
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,  
			0 AS completionQuantity,  
			'sizeNumber' AS sizeNumber,  
			0 AS sizeCompletionQuantity,  
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL  
		INNER JOIN ListKHPO ON ListKHPO.KHPO = DDZL.KHPO 
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh  
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH  
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH  
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR  
		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP  
			ON YWCP.DDBH = DDZL.DDBH  
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
		WHERE DDZL.KHPO != '' 
			AND DDZL.KHPO IS NOT NULL 
			AND DDZL.DDZT = 'Y'
			AND (DDZL.DDBH LIKE %s)
			AND NOT (
				DDZL.DDBH LIKE '%s'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE '%s'
			)
		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, xxzl.jijie
		ORDER BY DDZL.KHPO;

	`, "'DE%'", getPoTypeQuery(DDBH, "DDZL.DDBH"), "'DE%'", "%-B%", "DHB%")

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
		"gsbh":        GSBH,
	}
	// 查詢 DailyPoStatus 資料
	var getDailyPoStatusData []types.DailyPoStatus
	err = db.Raw(sqlGetDailyPoStatusData, queryParams).Scan(&getDailyPoStatusData).Error
	if err != nil {
		return nil, err
	}

	// Remove po
	// removeList := []string{
	// 	"100595559",
	// 	"500115848",
	// 	"500114669",
	// }
	// getDailyPoStatusData = RemovePo(getDailyPoStatusData, removeList)

	// Cache size list from Decker
	deckerSizeList := make(map[string]string)

	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
	for i := range getDailyPoStatusData {
		value := &getDailyPoStatusData[i]
		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		sizeMapKey := value.StyleNumber + "-" + value.ColorCode

		// 獲取 Milestone 資料
		milestoneListData, err := GetMilestoneData(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH, date)
		if err != nil {
			return nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
		}

		// 如果有 Milestone 資料，才填充到 MilestoneList
		if len(milestoneListData) > 0 {
			milestoneMap := make(map[string]*types.Milestone)
			for _, ml := range milestoneListData {
				// 根據 StageCode 轉換
				switch ml.StageCode {
				case "C":
					ml.StageCode = "WIP3-1"
				case "O":
					ml.StageCode = "WIP3-3"
				case "S":
					ml.StageCode = "WIP6"
				case "A":
					ml.StageCode = "WIP8"
				}

				if milestone, exists := milestoneMap[ml.StageCode]; exists {
					milestone.CompletionQuantity += ml.CompletionQuantity
					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
				} else {
					milestoneMap[ml.StageCode] = &types.Milestone{
						StageCode:          ml.StageCode,
						CompletionQuantity: ml.CompletionQuantity,
						SizeList:           ml.SizeList,
					}
				}
			}

			var newMilestoneListData []types.Milestone
			for _, milestone := range milestoneMap {
				newMilestoneListData = append(newMilestoneListData, *milestone)
			}
			newMilestoneListData = fillMissingStages(newMilestoneListData)
			sortMilestones(newMilestoneListData)
			resolveConflictingData(newMilestoneListData)
			value.MilestoneList = newMilestoneListData
		}

		err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(databaseType), deckerSizeList)
		if err != nil {
			return nil, fmt.Errorf("error when get size list from deckers")
		}

		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
		for _, milestone := range value.MilestoneList {

			// Get last size string from size map and check if exist
			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

				// Change all size number: add last size string to the end
				for index := range milestone.SizeList {

					size := &milestone.SizeList[index]

					// Ignore empty size number
					if len(size.SizeNumber) > 0 {

						// Get last character in size number
						lastCharIndex := len(size.SizeNumber) - 1
						checkingChar := size.SizeNumber[lastCharIndex]

						// Check if it was added or not
						if !unicode.IsLetter(rune(checkingChar)) {

							// Add to the end
							size.SizeNumber += lastSizeStr
						}
					}
				}
			}

			// Add PO completion Qty = WIP8's Qty
			if milestone.StageCode == "WIP8" {
				value.PoCompletionQuantity = milestone.CompletionQuantity
			}
		}

		if value.PoCompletionQuantity == value.PoQuantity {
			value.Status = "001"
		}
	}

	result := mergeDuplicatePOs(getDailyPoStatusData)

	TestPoStatus(result)

	return result, nil
}
