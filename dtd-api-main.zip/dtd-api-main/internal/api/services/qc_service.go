package services

import (
	"log"
	"strings"
	"time"
	"unicode"
	"web-api/internal/api/repo"
	"web-api/internal/integration/deckers"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/models/types"
	"web-api/internal/pkg/utils"
)

type QcService struct {
}

var QcServiceInstance QcService

func (qc *QcService) GetHourlyTqcOutput(databaseType, datetime string) ([]types.TqcOutputPayload, error) {

	startTime, endTime, err := calculateTimes(datetime)
	if err != nil {
		return nil, err
	}

	result, err := repo.TqcRepositoryInstance.GetTqcData(databaseType, startTime, endTime)
	if err != nil {
		return nil, err
	}
	defectReason, err := repo.TqcRepositoryInstance.GetTqcDefectReason(databaseType, startTime, endTime)
	if err != nil {
		return nil, err
	}

	return transformTqcData(result, defectReason), nil
}

func (qc *QcService) GetRepackingOutput(databaseType string, date string) ([]types.RepackingResult, error) {
	repo := repo.RepackingRepositoryInstance

	// 1. 撈出當天所有的 LotNumbers
	lotNumbers, err := repo.GetLotNumbersByDate(databaseType, date)
	if err != nil {
		return nil, err
	}
	if len(lotNumbers) == 0 {
		return []types.RepackingResult{}, nil
	}

	taipeiLoc, _ := time.LoadLocation("Asia/Taipei")
	var results []types.RepackingResult

	// 2. 針對每一個 LotNumber 進行獨立的資料撈取與計算
	for _, lotNum := range lotNumbers {

		// ===== A1: 取得該 LotNumber 對應的 IDs =====
		ids, err := repo.GetIDsByLotNumbers(databaseType, []string{lotNum})
		if err != nil {
			return nil, err
		}
		if len(ids) == 0 {
			continue
		}

		// ===== B1: repairReasonList / rejectReasonList =====
		reasons, err := repo.GetRepairAndRejectReasonsByIDs(databaseType, ids)
		if err != nil {
			return nil, err
		}

		repairReasons := []types.Reason{}
		rejectReasons := []types.Reason{}

		var repairQty int
		var bGradeQty int

		for _, r := range reasons {

			switch r.Level {

			case "Repair":
				repairReasons = append(repairReasons, r)
				repairQty += int(r.Qty)

			case "RejectB":
				rejectReasons = append(rejectReasons, r)
				bGradeQty += int(r.Qty)
			}
		}

		cGradeQty := 0

		// ===== B2: common info =====
		common, err := repo.GetCommonInfoByLot(databaseType, lotNum)
		if err != nil {
			return nil, err
		}
		if common == nil {
			continue
		}

		// ===== B5: approvedBy =====
		approvedByResult, err := repo.GetApprovedByIDs(databaseType, ids)
		if err != nil {
			return nil, err
		}

		approvedBy := make([]types.ApprovedBy, 0, len(approvedByResult))
		for _, e := range approvedByResult {
			approvedBy = append(approvedBy, types.ApprovedBy{
				Name: e.Name,
				Role: e.Role,
			})
		}

		// ===== B6: 數量計算 =====
		inspectedQty, err := repo.GetInspectedQtyByIDs(databaseType, ids)
		if err != nil {
			return nil, err
		}

		defectQty := repairQty + bGradeQty + cGradeQty
		passQty := inspectedQty - defectQty

		if passQty < 0 {
			passQty = 0
		}

		// ===== 組合單一 LotNumber 的 Payload =====
		singleResult := types.RepackingResult{
			QcCommon: types.QcCommon{
				FactoryCode:    common.FactoryCode,
				FactoryName:    common.FactoryName,
				Brand:          common.Brand,
				StyleNumber:    common.StyleNumber,
				StyleName:      common.StyleName,
				ColorCode:      common.ColorCode,
				PoNumber:       common.PoNumber,
				PoType:         common.PoType,
				ShipID:         common.ShipID,
				LineNumber:     common.LineNumber,
				InspectionType: common.InspectionType,
			},
			InspectTime:      common.InspectTime.In(taipeiLoc),
			InspectedQty:     uint(inspectedQty),
			LotNumber:        common.LotNumber,
			PassQty:          uint(passQty),
			RepairQty:        uint(repairQty),
			BGradeQty:        uint(bGradeQty),
			CGradeQty:        uint(cGradeQty),
			RepairReasonList: repairReasons,
			RejectReasonList: rejectReasons,
			ApprovedBy:       approvedBy,
			ApprovedTime:     common.InspectTime.In(taipeiLoc),
		}

		results = append(results, singleResult)
	}

	return results, nil
}

func (qc *QcService) GetRepackingOutputByPO(
	databaseType string,
	khpo string,
) ([]types.RepackingResult, error) {
	repo := repo.RepackingRepositoryInstance

	ids, err := repo.GetIDsByPONumber(databaseType, khpo)
	if err != nil {
		return nil, err
	}
	if len(ids) == 0 {
		return []types.RepackingResult{}, nil
	}

	// ===== B1: repairReasonList / rejectReasonList =====
	// 參考 GetRepackingOutput 改用 GetRepairAndRejectReasonsByIDs
	reasons, err := repo.GetRepairAndRejectReasonsByIDs(databaseType, ids)
	if err != nil {
		return nil, err
	}

	repairReasons := []types.Reason{}
	rejectReasons := []types.Reason{}

	var repairQty int
	var bGradeQty int

	for _, r := range reasons {
		switch r.Level {
		case "Repair":
			repairReasons = append(repairReasons, r)
			repairQty += int(r.Qty)

		case "RejectB":
			rejectReasons = append(rejectReasons, r)
			bGradeQty += int(r.Qty)
		}
	}

	cGradeQty := 0

	// ===== B2: common info (傳入當前迴圈的 lotNum) =====
	common, err := repo.GetCommonInfoByPONumber(databaseType, khpo)
	if err != nil {
		return nil, err
	}
	if common == nil {
		return []types.RepackingResult{}, nil
	}

	// ===== B5: approvedBy =====
	approvedByResult, err := repo.GetApprovedByIDs(databaseType, ids)
	if err != nil {
		return nil, err
	}
	approvedBy := make([]types.ApprovedBy, 0, len(approvedByResult))
	for _, e := range approvedByResult {
		approvedBy = append(approvedBy, types.ApprovedBy{Name: e.Name, Role: e.Role})
	}

	// ===== B6: 數量計算 =====
	inspectedQty, err := repo.GetInspectedQtyByIDs(databaseType, ids)
	if err != nil {
		return nil, err
	}

	defectQty := repairQty + bGradeQty + cGradeQty
	passQty := inspectedQty - defectQty

	if passQty < 0 {
		passQty = 0
	}

	taipeiLoc, _ := time.LoadLocation("Asia/Taipei")

	// ===== 組合單一 LotNumber 的 Payload =====
	result := types.RepackingResult{
		QcCommon: types.QcCommon{
			FactoryCode:    common.FactoryCode,
			FactoryName:    common.FactoryName,
			Brand:          common.Brand,
			StyleNumber:    common.StyleNumber,
			StyleName:      common.StyleName,
			ColorCode:      common.ColorCode,
			PoNumber:       common.PoNumber,
			PoType:         common.PoType,
			ShipID:         common.ShipID,
			LineNumber:     common.LineNumber,
			InspectionType: common.InspectionType,
		},
		InspectTime:      common.InspectTime.In(taipeiLoc),
		InspectedQty:     uint(inspectedQty),
		LotNumber:        common.LotNumber,
		PassQty:          uint(passQty),
		RepairQty:        uint(repairQty),
		BGradeQty:        uint(bGradeQty),
		CGradeQty:        uint(cGradeQty),
		RepairReasonList: repairReasons,
		RejectReasonList: rejectReasons, // 這裡已正確綁定篩選後的 rejectReasons
		ApprovedBy:       approvedBy,
		ApprovedTime:     common.InspectTime.In(taipeiLoc),
	}

	return []types.RepackingResult{result}, nil
}

func buildKey(depNo, ddbh string) string {
	return strings.ToUpper(strings.TrimSpace(depNo)) + "_" +
		strings.ToUpper(strings.TrimSpace(ddbh))
}

func transformTqcData(
	tqcQueryResult []types.TqcQueryResult,
	defectReason []types.Reason,
) []types.TqcOutputPayload {

	payload := []types.TqcOutputPayload{}

	reasonMap := map[string][3][]types.Reason{}
	extractReason(defectReason, reasonMap)

	for _, tqcRow := range tqcQueryResult {

		// 用統一 key
		key := buildKey(tqcRow.DepNo, tqcRow.DDBH)

		// ===== Reason =====
		repairReason := reasonMap[key][0]
		if repairReason == nil {
			repairReason = []types.Reason{}
		}

		rejectReason := append(reasonMap[key][1], reasonMap[key][2]...)
		if rejectReason == nil {
			rejectReason = []types.Reason{}
		}

		// ===== Common =====
		commonInfo := types.QcCommon{
			FactoryCode:    tqcRow.FactoryCode,
			FactoryName:    tqcRow.FactoryName,
			Brand:          tqcRow.Brand,
			StyleNumber:    tqcRow.StyleNumber,
			StyleName:      tqcRow.StyleName,
			ColorCode:      tqcRow.ColorCode,
			PoNumber:       tqcRow.PoNumber,
			PoType:         tqcRow.PoType,
			ShipID:         tqcRow.ShipID,
			LineNumber:     tqcRow.LineNumber,
			InspectionType: tqcRow.InspectionType,
			StartTime:      tqcRow.StartTime,
			EndTime:        tqcRow.EndTime,
		}

		// ===== 組 InspectorName ⭐ =====
		inspectorName := []string{
			tqcRow.Inspectors.TQC1Inspector,
			tqcRow.Inspectors.TQC2Inspector,
			tqcRow.Inspectors.TQC3Inspector,
		}

		// ===== 主體 =====
		tqc := types.TqcOutputPayload{
			QcCommon: commonInfo,

			TqcInspectedQty: []uint{
				tqcRow.Tqc1PassQty + tqcRow.Tqc1RepairQty + tqcRow.Tqc1BgradeQty + tqcRow.Tqc1CgradeQty,
				tqcRow.Tqc2PassQty + tqcRow.Tqc2RepairQty + tqcRow.Tqc2BgradeQty + tqcRow.Tqc2CgradeQty,
				tqcRow.Tqc3PassQty + tqcRow.Tqc3RepairQty + tqcRow.Tqc3BgradeQty + tqcRow.Tqc3CgradeQty,
			},
			TqcPassQty: []uint{
				tqcRow.Tqc1PassQty,
				tqcRow.Tqc2PassQty,
				tqcRow.Tqc3PassQty,
			},
			TqcRepairQty: []uint{
				tqcRow.Tqc1RepairQty,
				tqcRow.Tqc2RepairQty,
				tqcRow.Tqc3RepairQty,
			},
			TqcBgradeQty: []uint{
				tqcRow.Tqc1BgradeQty,
				tqcRow.Tqc2BgradeQty,
				tqcRow.Tqc3BgradeQty,
			},
			TqcCgradeQty: []uint{
				tqcRow.Tqc1CgradeQty,
				tqcRow.Tqc2CgradeQty,
				tqcRow.Tqc3CgradeQty,
			},

			AssemblyTotalInspectionPassQty: tqcRow.AssemblyTotalInspectionPassQty,

			RepairReasonList: repairReason,
			RejectReasonList: rejectReason,

			InspectorName: inspectorName,
		}

		// ===== Rate =====
		tqcRejectRate := [3]float32{}
		tqcDefectRate := [3]float32{}

		for i := 0; i < 3; i++ {
			rejectQty := tqc.TqcBgradeQty[i] + tqc.TqcCgradeQty[i]
			defectQty := tqc.TqcRepairQty[i]
			inspectedQty := tqc.TqcInspectedQty[i]

			if inspectedQty > 0 {
				defectRate := float32(defectQty) / float32(inspectedQty)
				rejectRate := float32(rejectQty) / float32(inspectedQty)

				tqcDefectRate[i] = utils.Round4(defectRate)
				tqcRejectRate[i] = utils.Round4(rejectRate)
			}
		}

		tqc.RejectRate = tqcRejectRate[:]
		tqc.DefectRate = tqcDefectRate[:]
		tqc.DefectRateThreshold = utils.Round4(0.15)

		payload = append(payload, tqc)
	}

	return payload
}

func extractReason(defectReason []types.Reason, result map[string][3][]types.Reason) {
	for _, reason := range defectReason {
		key := buildKey(reason.DepNo, reason.DDBH)
		allDefectReason, exist := result[key]
		if !exist {
			allDefectReason = [3][]types.Reason{}
		}
		switch reason.Level {
		case "A":
			reason.Level = ""
			allDefectReason[0] = append(allDefectReason[0], reason)
		case "B":
			reason.Level = "B-Grade"
			allDefectReason[1] = append(allDefectReason[1], reason)
		case "C":
			reason.Level = "C-Grade"
			allDefectReason[2] = append(allDefectReason[2], reason)
		default:
			log.Printf("invalid defect level: %v\n", reason.Level)
		}
		result[key] = allDefectReason
	}
}

func (tqc *QcService) GetHourlyRqcOutput(databaseType, datetime string) ([]types.RqcResult, error) {

	startTime, endTime, err := calculateTimes(datetime)
	if err != nil {
		return nil, err
	}

	result, err := repo.RqcRepositoryInstance.GetRqcData(databaseType, startTime, endTime)
	if err != nil {
		return nil, err
	}
	defectReason, err := repo.RqcRepositoryInstance.GetRqcDefectReason(databaseType, startTime, endTime)
	if err != nil {
		return nil, err
	}

	return transformRqcData(result, defectReason), nil
}

func transformRqcData(tqcQueryResult []types.RqcResult, defectReason []types.Reason) []types.RqcResult {
	payload := []types.RqcResult{}

	reasonMap := map[string][3][]types.Reason{}
	extractReason(defectReason, reasonMap)

	for _, rqcRow := range tqcQueryResult {
		key := rqcRow.DepNo + "_" + rqcRow.DDBH

		repairReason := reasonMap[key][0]
		if repairReason == nil {
			repairReason = []types.Reason{}
		}
		rejectReason := append(reasonMap[key][1], reasonMap[key][2]...)
		if rejectReason == nil {
			rejectReason = []types.Reason{}
		}

		commonInfo := types.QcCommon{
			FactoryCode:    rqcRow.FactoryCode,
			FactoryName:    rqcRow.FactoryName,
			Brand:          rqcRow.Brand,
			StyleNumber:    rqcRow.StyleNumber,
			StyleName:      rqcRow.StyleName,
			ColorCode:      rqcRow.ColorCode,
			PoNumber:       rqcRow.PoNumber,
			PoType:         rqcRow.PoType,
			ShipID:         rqcRow.ShipID,
			LineNumber:     rqcRow.LineNumber,
			InspectionType: rqcRow.InspectionType,
			StartTime:      rqcRow.StartTime,
			EndTime:        rqcRow.EndTime,
		}

		rqc := types.RqcResult{
			QcCommon:         commonInfo,
			RqcInspectedQty:  rqcRow.RqcPassQty + rqcRow.RqcRepairQty + rqcRow.RqcBgradeQty + rqcRow.RqcCgradeQty,
			RqcPassQty:       rqcRow.RqcPassQty,
			RqcRepairQty:     rqcRow.RqcRepairQty,
			RqcBgradeQty:     rqcRow.RqcBgradeQty,
			RqcCgradeQty:     rqcRow.RqcCgradeQty,
			RepairReasonList: repairReason,
			RejectReasonList: rejectReason,
			InspectorName:    rqcRow.InspectorName,
		}

		rejectQty := rqc.RqcBgradeQty + rqc.RqcCgradeQty

		// If inspected = 0, operation will be failed
		if rqc.RqcInspectedQty > 0 {
			defectRate := float32(rqc.RqcRepairQty) / float32(rqc.RqcInspectedQty)
			rejectRate := float32(rejectQty) / float32(rqc.RqcInspectedQty)

			rqc.DefectRate = utils.Round4(defectRate)
			rqc.RejectRate = utils.Round4(rejectRate)
		}

		payload = append(payload, rqc)
	}

	return payload
}

func (tqc *QcService) GetDailyBgradeOutput(databaseType, date string) ([]types.BgradeInventory, error) {

	result, err := repo.BgradeRepositoryInstance.GetBgradeData(databaseType, date)
	if err != nil {
		return nil, err
	}

	sizeDetailList, err := repo.BgradeRepositoryInstance.GetSizeList(databaseType, date)
	if err != nil {
		return nil, err
	}

	inOutList, err := repo.BgradeRepositoryInstance.GetInOutInventory(databaseType, date)
	if err != nil {
		return nil, err
	}
	inOutList = groupIODetail(inOutList)

	// cgradeOut, err := repo.BgradeRepositoryInstance.GetCgradeOut(databaseType, date)
	// if err != nil {
	// 	return nil, err
	// }

	transformBgradeData(result, extractSizeMap(sizeDetailList), extractInOutMap(inOutList), databaseType)

	return result, err
}

func groupIODetail(data []types.IODetail) []types.IODetail {
	resultMap := make(map[string]*types.IODetail)

	for _, item := range data {
		// key để group
		key := item.Type + "|" + item.PoNumber + "|" + item.PoType + "|" + item.Reason + "|" + item.Timestamp

		if _, ok := resultMap[key]; !ok {
			resultMap[key] = &types.IODetail{
				Type:             item.Type,
				PoNumber:         item.PoNumber,
				PoType:           item.PoType,
				Reason:           item.Reason,
				Timestamp:        item.Timestamp,
				Source:           item.Source,
				StyleNumber:      item.StyleNumber,
				ColorCode:        item.ColorCode,
				QueryTime:        item.QueryTime,
				Qty:              0,
				IoSizeDetailList: []types.SizeDetail{},
			}
		}

		// cộng tổng qty
		resultMap[key].Qty += item.SizeQty

		// thêm size detail
		resultMap[key].IoSizeDetailList = append(
			resultMap[key].IoSizeDetailList,
			types.SizeDetail{
				SizeNumber: item.SizeNumber,
				Qty:        item.SizeQty,
			},
		)
	}

	// convert map → slice
	var result []types.IODetail
	for _, v := range resultMap {
		result = append(result, *v)
	}

	return result
}

func transformBgradeData(
	bgradeData []types.BgradeInventory,
	sizeDetailMap map[string][]types.SizeDetail,
	inOutInventoryMap map[string][]types.IODetail,
	databaseType string,
) error {

	deckersSizeMap := map[string]string{}

	for index := range bgradeData {
		row := &bgradeData[index] // Dùng con trỏ để gán lại dễ dàng
		key := row.StyleNumber + "-" + row.ColorCode

		// 1. Lấy data từ Deckers
		if _, loaded := deckersSizeMap[key]; !loaded {
			err := deckers.DeckerClient.GetSizeList(row.StyleNumber, row.ColorCode, jwt.GetJWT(databaseType), deckersSizeMap)
			if err != nil {
				return err
			}
		}

		// 2. Khởi tạo mảng mặc định nếu không tồn tại
		sizeList, exist := sizeDetailMap[key]
		if !exist {
			sizeList = []types.SizeDetail{}
		}

		ioList, exist := inOutInventoryMap[key]
		if !exist {
			ioList = []types.IODetail{}
		}

		// 3. Xử lý gộp chung: Thay đổi SizeNumber cho cả 2 List
		if lastSizeStr, exist := deckersSizeMap[key]; exist {

			// Update sizeList (Đã sửa lỗi trùng biến index thành biến i)
			for i := range sizeList {
				sizeList[i].SizeNumber = formatSizeNumber(sizeList[i].SizeNumber, lastSizeStr)
			}

			// Update ioList
			for i := range ioList {
				for j := range ioList[i].IoSizeDetailList {
					ioList[i].IoSizeDetailList[j].SizeNumber = formatSizeNumber(ioList[i].IoSizeDetailList[j].SizeNumber, lastSizeStr)
				}
			}
		}

		// 4. Gán lại kết quả vào bgradeData
		row.SizeDetailList = sizeList
		row.IODetailList = ioList
	}
	return nil
}

// formatSizeNumber kiểm tra và thêm chuỗi suffix vào cuối nếu ký tự cuối không phải là chữ cái
func formatSizeNumber(sizeNumber string, suffix string) string {
	if len(sizeNumber) == 0 {
		return sizeNumber // Bỏ qua nếu chuỗi rỗng
	}

	lastChar := sizeNumber[len(sizeNumber)-1]
	if !unicode.IsLetter(rune(lastChar)) {
		return sizeNumber + suffix
	}

	return sizeNumber
}

func extractSizeMap(sizeDetailList []types.SizeDetail) map[string][]types.SizeDetail {
	sizeDetailMap := map[string][]types.SizeDetail{}

	for _, size := range sizeDetailList {
		key := size.StyleNumber + "-" + size.ColorCode
		sizeList, exist := sizeDetailMap[key]
		if !exist {
			sizeList = []types.SizeDetail{}
		}
		sizeList = append(sizeList, size)
		sizeDetailMap[key] = sizeList
	}
	return sizeDetailMap
}

func extractInOutMap(inOutInventoryList []types.IODetail) map[string][]types.IODetail {
	ioDetailMap := map[string][]types.IODetail{}

	for _, ioDetail := range inOutInventoryList {
		key := ioDetail.StyleNumber + "-" + ioDetail.ColorCode
		ioList, exist := ioDetailMap[key]
		if !exist {
			ioList = []types.IODetail{}
		}

		dateFormat := "2006-01-02T15:04:05-07:00"
		ioDetail.Timestamp = formatDate(ioDetail.QueryTime, dateFormat)

		ioList = append(ioList, ioDetail)
		ioDetailMap[key] = ioList
	}
	return ioDetailMap
}

func formatDate(date time.Time, format string) string {

	// Set timezone location (GMT+7)
	location := time.FixedZone("GMT+7", 7*60*60)
	date = time.Date(date.Year(), date.Month(), date.Day(), date.Hour(), date.Minute(), date.Second(), date.Nanosecond(), location)
	return date.Format(format)
}

func (qc *QcService) CheckRQCActive(databaseType string, startTime, endTime time.Time) (bool, error) {

	return repo.RqcRepositoryInstance.CheckRQCActive(databaseType, startTime, endTime)
}

func (qc *QcService) GetRQCCheckTimeRange(datetime string, threshold time.Duration) (time.Time, time.Time, error) {
	endTime, err := time.Parse("2006-01-02 15:04:05", datetime)
	if err != nil {
		return time.Time{}, time.Time{}, err
	}

	endTime = time.Date(endTime.Year(), endTime.Month(), endTime.Day(), endTime.Hour(), 30, 0, 0, time.Now().Location())

	startTime := endTime.Add(threshold)

	return startTime, endTime, nil
}

func (qc *QcService) GenerateTimeString(startTime, endTime time.Time) string {
	dateFormatter := "15:04:05"
	return startTime.Format(dateFormatter) + " - " + endTime.Format(dateFormatter)
}

func (qc *QcService) SendRepackingMail(databaseType, date string, data []types.RepackingResult, keyMap map[string]string) error {

	excelList := []types.RepackingResultExcel{}

	for _, repacking := range data {
		excel := repacking.ExtractExcel()
		excelList = append(excelList, excel)
	}

	dbFactory, err := utils.GetFactoryByDatabaseType(databaseType)
	if err != nil {
		return err
	}

	for index := range excelList {
		excel := &excelList[index]
		key := extractKeyFromItem(*excel)

		if value, exist := keyMap[key]; exist {
			excel.ReturnID = value
		}
	}

	filename := "po-report/" + date + "-Repacking-" + dbFactory + ".xlsx"

	// Write excel file
	err = utils.WriteRepackingExcel(filename, "Repacking", excelList)
	if err != nil {
		return err
	}

	err = utils.MailSenderInstance.SendRepackingExcel(filename, databaseType, date)
	if err != nil {
		return err
	}
	defer utils.DeleteFile(filename)

	return nil
}

func (qc *QcService) SendBgradeMail(databaseType, date string, data []types.BgradeInventory, keyMap map[string]string) error {

	excelList := []types.BgradeInventoryExcel{}

	for _, bgrade := range data {
		excel := bgrade.ExtractExcel()
		excelList = append(excelList, excel)
	}

	dbFactory, err := utils.GetFactoryByDatabaseType(databaseType)
	if err != nil {
		return err
	}

	for index := range excelList {
		excel := &excelList[index]
		key := extractKeyFromItem(*excel)

		if value, exist := keyMap[key]; exist {
			excel.ReturnID = value
		}
	}

	filename := "po-report/" + date + "-Bgrade-" + dbFactory + ".xlsx"

	// Write excel file
	err = utils.WriteBgradeExcel(filename, "Bgrade", excelList)
	if err != nil {
		return err
	}

	err = utils.MailSenderInstance.SendBgradeExcel(filename, databaseType, date)
	if err != nil {
		return err
	}
	defer utils.DeleteFile(filename)

	return nil
}
