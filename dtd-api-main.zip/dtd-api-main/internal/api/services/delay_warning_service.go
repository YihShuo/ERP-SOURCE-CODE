package services

import (
	"log"
	"web-api/internal/api/repo"
	"web-api/internal/pkg/models/types"
)

type delayWarning struct {
}

var DelayWarningService = &delayWarning{}

func (d *delayWarning) GetDelayWaringOrder() ([]types.DelayWarningOrder, error) {

	dbList := []string{"A", "B", "C"}
	result := []types.DelayWarningOrder{}

	for _, databaseType := range dbList {
		warningOrder, err := repo.DelayWaringRepository.GetDelayWaringOrder(databaseType)
		if err != nil {
			log.Printf("error get delay warning orders for DB %s: %v", databaseType, err)
			continue
		}
		ddbhList, err := repo.DelayWaringRepository.DoParentCuttingFilter(databaseType, getDDBHList(warningOrder))
		if err != nil {
			log.Printf("error filter parent delay warning orders for DB %s: %v", databaseType, err)
			continue
		}

		ddbhMap := map[string]struct{}{}
		for _, ddbh := range ddbhList {
			ddbhMap[ddbh] = struct{}{}
		}

		for _, order := range warningOrder {
			_, exist := ddbhMap[order.RY]
			if exist {
				result = append(result, order)
			}
		}
	}

	return result, nil
}

func getDDBHList(orderList []types.DelayWarningOrder) []string {
	ddbhList := []string{}
	for _, order := range orderList {
		ddbhList = append(ddbhList, order.RY)
	}
	return ddbhList
}
