package services

import (
	"fmt"
	"strings"
	"time"
	"unicode"

	"gorm.io/gorm"

	"web-api/internal/integration/deckers"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/models/types"
)

// func (s *poStatusService) GetDailyPoStatusByPOList(databaseType, date string, poList []string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

// 	db, factoryCode, factoryName, GSBH, DDBH_TypeMap, err := setupDatabase(databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	poStatusData, err := s.queryPoStatusByList(db, date, poList, factoryCode, factoryName, DDBH_TypeMap)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	deckerSizeSuffixMap := make(map[string]string)

// 	xFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	for i := range poStatusData {

// 		po := &poStatusData[i]

// 		// Load milestone
// 		milestones, err := s.loadMilestones(db, po, GSBH, date)
// 		if err != nil {
// 			return nil, nil, err
// 		}
// 		if len(milestones) == 0 {
// 			continue
// 		}

// 		// Milestone business rules
// 		milestones = s.applyMilestoneRules(milestones)

// 		// Load size rules (Decker)
// 		if err := deckers.DeckerClient.GetSizeList(
// 			po.StyleNumber,
// 			po.ColorCode,
// 			jwt.GetJWT(databaseType),
// 			deckerSizeSuffixMap,
// 		); err != nil {
// 			return nil, nil, err
// 		}

// 		// Size + WIP calculation
// 		milestones, wip8Qty := s.applyMilestoneSizeRules(
// 			milestones,
// 			deckerSizeSuffixMap,
// 			po.StyleNumber+"-"+po.ColorCode,
// 		)

// 		po.MilestoneList = milestones
// 		po.PoCompletionQuantity = wip8Qty

// 		// XFDetail enrichment
// 		po.XFDetail = s.applyXFDetail(
// 			xFDetailMap,
// 			po,
// 			deckerSizeSuffixMap,
// 		)

// 		// Status rule
// 		if po.PoCompletionQuantity == po.PoQuantity {
// 			po.Status = "001"
// 		}
// 	}

// 	result := mergeDuplicatePOs(poStatusData)
// 	TestPoStatus(result)

//		return result, []types.DailyPoStatus{}, nil
//	}
type poStatusService struct {
	*BaseService
}

var PoStatusService = &poStatusService{}

func (s *poStatusService) GetXFShippedPoStatus(
	databaseType,
	startDate,
	endDate string,
) ([]types.DailyPoXFStatusSummary, []types.DailyPoXFStatusSummary, error) {

	db, _, _, _, DDBH_TypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, err
	}

	// 依時間區間撈出 poList
	poList, err := getShippedPoList(
		db,
		startDate,
		endDate,
		DDBH_TypeMap,
	)

	if err != nil {
		return nil, nil, err
	}

	// 改成使用「今天日期」
	today := time.Now().Format("2006-01-02")

	return s.GetXFShippedPoStatusByPOList(
		databaseType,
		today,
		poList,
	)
}

func (s *poStatusService) GetXFShippedPoStatusByPOList(
	databaseType,
	date string,
	poList []string,
) ([]types.DailyPoXFStatusSummary, []types.DailyPoXFStatusSummary, error) {

	db, factoryCode, factoryName, _, DDBH_TypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, err
	}

	// SQL Server parameter safe size
	const chunkSize = 2000

	// =====================================================
	// 找出特殊 PO
	// =====================================================

	specialPOMap := make(map[string]bool)

	if len(poList) > 0 {

		query := `
        WITH PoFromMemo AS (
            SELECT DISTINCT 
                SUBSTRING(
                    REPLACE(REPLACE(YWBZPOS.MEMO, CHAR(13), ''), CHAR(10), ''),
                    1,
                    9
                ) AS MATCH_PO
            FROM YWBZPOS
        )
        SELECT DISTINCT MATCH_PO 
        FROM PoFromMemo
        WHERE MATCH_PO IN (?)
        `

		// 分批避免 SQL Server 2100 parameter limit
		for i := 0; i < len(poList); i += chunkSize {

			end := i + chunkSize
			if end > len(poList) {
				end = len(poList)
			}

			currentChunk := poList[i:end]

			var matchedPOs []string

			if err := db.Raw(query, currentChunk).
				Scan(&matchedPOs).Error; err != nil {

				return nil, nil, err
			}

			for _, po := range matchedPOs {
				specialPOMap[po] = true
			}
		}
	}

	// =====================================================
	// 分離一般 / 特殊 PO
	// =====================================================

	var regularPoList []string
	var specialPoList []string

	for _, po := range poList {

		if specialPOMap[po] {
			specialPoList = append(specialPoList, po)
		} else {
			regularPoList = append(regularPoList, po)
		}
	}

	fmt.Println("一般 PO:", len(regularPoList))
	fmt.Println("特殊 PO:", len(specialPoList))

	var poStatusData []types.DailyPoStatus

	// =====================================================
	// 一般流程
	// 一般 PO -> queryPoStatusByList
	// =====================================================

	if len(regularPoList) > 0 {

		for i := 0; i < len(regularPoList); i += chunkSize {

			end := i + chunkSize
			if end > len(regularPoList) {
				end = len(regularPoList)
			}

			currentChunk := regularPoList[i:end]

			regularData, err := s.queryPoStatusByList(
				db,
				date,
				currentChunk,
				factoryCode,
				factoryName,
				DDBH_TypeMap,
			)

			if err != nil {
				return nil, nil, err
			}

			poStatusData = append(poStatusData, regularData...)
		}
	}

	// =====================================================
	// 特殊流程
	// 特殊 PO -> queryPoStatusByListSpecial
	// =====================================================

	if len(specialPoList) > 0 {

		for i := 0; i < len(specialPoList); i += chunkSize {

			end := i + chunkSize
			if end > len(specialPoList) {
				end = len(specialPoList)
			}

			currentChunk := specialPoList[i:end]

			specialData, err := s.queryPoStatusByListSpecial(
				db,
				date,
				currentChunk,
				factoryCode,
				factoryName,
				DDBH_TypeMap,
			)

			if err != nil {
				return nil, nil, err
			}

			poStatusData = append(poStatusData, specialData...)
		}
	}

	// =====================================================
	// XF Detail
	// =====================================================

	deckerSizeSuffixMap := make(map[string]string)

	xFDetailMap, err := GetXFDetailMap(
		db,
		poStatusData,
		date,
		databaseType,
	)

	if err != nil {
		return nil, nil, err
	}

	for i := range poStatusData {

		po := &poStatusData[i]

		po.XFDetail = s.applyXFDetail(
			xFDetailMap,
			po,
			deckerSizeSuffixMap,
		)
	}

	// =====================================================
	// Merge
	// =====================================================

	result := mergeDuplicatePOs(poStatusData)

	// =====================================================
	// Flatten Summary
	// =====================================================

	finalSummaryResult := ConvertToFlattenSummary(result)

	// =====================================================
	// Save DB
	// =====================================================

	if err := s.SaveShippedDetailSummary(
		db,
		finalSummaryResult,
	); err != nil {

		fmt.Println("警告: 寫入 ShippedDetail 失敗:", err)

		return nil, nil, err
	}

	return finalSummaryResult, []types.DailyPoXFStatusSummary{}, nil
}

// SaveShippedDetailSummary 將扁平化後的結果以 UPSERT (複合Key相同則覆蓋) 的方式寫入 ShippedDetail 表
func (s *poStatusService) SaveShippedDetailSummary(db *gorm.DB, summaries []types.DailyPoXFStatusSummary) error {
	if len(summaries) == 0 {
		return nil
	}

	return db.Transaction(func(tx *gorm.DB) error {

		// 1. 主表 UPSERT 語法 (拿掉了 XFDetail 欄位)
		mainMergeSQL := `
		MERGE INTO ShippedDetail AS target
		USING (SELECT ? AS [date], ? AS poNumber, ? AS shipId) AS source
		ON (target.[date] = source.[date] AND target.poNumber = source.poNumber AND target.shipId = source.shipId)
		WHEN MATCHED THEN
			UPDATE SET 
				poType = ?, factoryCode = ?, factoryName = ?, [status] = ?, statusMessage = ?,
				styleNumber = ?, styleName = ?, colorCode = ?, season = ?, poQuantity = ?, 
				logType = ?, brand = ?, confirmXFDate = ?, updated_at = GETDATE()
		WHEN NOT MATCHED THEN
			INSERT ([date], poNumber, poType, factoryCode, factoryName, [status], statusMessage, 
			        styleNumber, styleName, colorCode, season, shipId, poQuantity, logType, brand, confirmXFDate, updated_at)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, GETDATE());`

		// 2. 子表 UPSERT 語法
		subMergeSQL := `
		MERGE INTO ShippedDetailXF AS target
		USING (SELECT ? AS [date], ? AS poNumber, ? AS shipId, ? AS XFTime, ? AS truckNumber, ? AS containerNumber) AS source
		ON (target.[date] = source.[date] AND target.poNumber = source.poNumber AND target.shipId = source.shipId 
		    AND target.XFTime = source.XFTime AND target.truckNumber = source.truckNumber AND target.containerNumber = source.containerNumber)
		WHEN MATCHED THEN
			UPDATE SET totalXFQuantity = ?, updated_at = GETDATE()
		WHEN NOT MATCHED THEN
			INSERT ([date], poNumber, shipId, XFTime, truckNumber, containerNumber, totalXFQuantity, updated_at)
			VALUES (?, ?, ?, ?, ?, ?, ?, GETDATE());`

		for _, po := range summaries {
			// 執行寫入主表
			err := tx.Exec(mainMergeSQL,
				po.Date, po.PoNumber, po.ShipID, // ON
				po.PoType, po.FactoryCode, po.FactoryName, po.Status, po.StatusMessage,
				po.StyleNumber, po.StyleName, po.ColorCode, po.Season, po.PoQuantity, po.LogType, po.Brand, po.ConfirmXFDate, // UPDATE
				po.Date, po.PoNumber, po.PoType, po.FactoryCode, po.FactoryName, po.Status, po.StatusMessage,
				po.StyleNumber, po.StyleName, po.ColorCode, po.Season, po.ShipID, po.PoQuantity, po.LogType, po.Brand, po.ConfirmXFDate, // INSERT
			).Error
			if err != nil {
				return err
			}

			// 如果這筆 PO 有明細，拉直寫入子表
			if len(po.XFDetail) > 0 {
				// 🚀 關鍵安全防護：寫入前先刪除該 PO 在這天這個 ShipID 底下的舊明細，避免覆蓋時因為車牌換了導致殘留髒資料
				err = tx.Exec("DELETE FROM ShippedDetailXF WHERE [date] = ? AND poNumber = ? AND shipId = ?", po.Date, po.PoNumber, po.ShipID).Error
				if err != nil {
					return err
				}

				for _, det := range po.XFDetail {
					err = tx.Exec(subMergeSQL,
						po.Date, po.PoNumber, po.ShipID, det.XFTime, det.TruckNumber, det.ContainerNumber, // ON
						det.TotalXFQuantity,                                                                                    // UPDATE
						po.Date, po.PoNumber, po.ShipID, det.XFTime, det.TruckNumber, det.ContainerNumber, det.TotalXFQuantity, // INSERT
					).Error
					if err != nil {
						return err
					}
				}
			}
		}
		return nil
	})
}

func (s *poStatusService) GetDailyPoStatusByPOList(
	databaseType,
	date string,
	poList []string,
) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH_TypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, err
	}

	// =====================================================
	// 找出特殊 PO
	// =====================================================

	specialPOMap := make(map[string]bool)

	if len(poList) > 0 {

		query := `
        WITH PoFromMemo AS (
            SELECT DISTINCT 
                SUBSTRING(
                    REPLACE(REPLACE(YWBZPOS.MEMO, CHAR(13), ''), CHAR(10), ''),
                    1,
                    9
                ) AS MATCH_PO
            FROM YWBZPOS
        )
        SELECT DISTINCT MATCH_PO 
        FROM PoFromMemo
        WHERE MATCH_PO IN (?)
        `

		var matchedPOs []string

		if err := db.Raw(query, poList).Scan(&matchedPOs).Error; err != nil {
			return nil, nil, err
		}

		for _, po := range matchedPOs {
			specialPOMap[po] = true
		}
	}

	// =====================================================
	// 拆分 特殊 PO / 一般 PO
	// =====================================================

	var specialPoList []string

	for _, po := range poList {
		if specialPOMap[po] {
			specialPoList = append(specialPoList, po)
		}
	}

	specialPOSet := make(map[string]bool)

	for _, po := range specialPoList {
		specialPOSet[po] = true
	}

	var regularPoList []string

	for _, po := range poList {
		if !specialPOSet[po] {
			regularPoList = append(regularPoList, po)
		}
	}

	// =====================================================
	// 共用資料
	// =====================================================

	var poStatusData []types.DailyPoStatus

	deckerSizeSuffixMap := make(map[string]string)

	// =====================================================
	// 一般流程
	// queryPoStatusByList
	// -> loadMilestones
	// =====================================================

	if len(regularPoList) > 0 {

		regularData, err := s.queryPoStatusByList(
			db,
			date,
			regularPoList,
			factoryCode,
			factoryName,
			DDBH_TypeMap,
		)

		if err != nil {
			return nil, nil, err
		}

		xFDetailMap, err := GetXFDetailMap(
			db,
			regularData,
			date,
			databaseType,
		)

		if err != nil {
			return nil, nil, err
		}

		for i := range regularData {

			po := &regularData[i]

			milestones, err := s.loadMilestones(
				db,
				po,
				GSBH,
				date,
			)

			if err != nil {
				return nil, nil, err
			}

			if len(milestones) == 0 {
				continue
			}

			milestones = s.applyMilestoneRules(milestones)

			if err := deckers.DeckerClient.GetSizeList(
				po.StyleNumber,
				po.ColorCode,
				jwt.GetJWT(databaseType),
				deckerSizeSuffixMap,
			); err != nil {
				return nil, nil, err
			}

			milestones, wip8Qty := s.applyMilestoneSizeRules(
				milestones,
				deckerSizeSuffixMap,
				po.StyleNumber+"-"+po.ColorCode,
			)

			po.MilestoneList = milestones
			po.PoCompletionQuantity = wip8Qty

			po.XFDetail = s.applyXFDetail(
				xFDetailMap,
				po,
				deckerSizeSuffixMap,
			)

			if po.PoCompletionQuantity == po.PoQuantity {
				po.Status = "001"
			}
		}

		poStatusData = append(poStatusData, regularData...)
	}

	// =====================================================
	// 特殊流程
	// queryPoStatusByListSpecial
	// -> loadSpecialMilestones
	// =====================================================

	if len(specialPoList) > 0 {

		specialData, err := s.queryPoStatusByListSpecial(
			db,
			date,
			specialPoList,
			factoryCode,
			factoryName,
			DDBH_TypeMap,
		)
		if err != nil {
			return nil, nil, err
		}

		xFDetailMap, err := GetXFDetailMap(
			db,
			specialData,
			date,
			databaseType,
		)

		if err != nil {
			return nil, nil, err
		}

		for i := range specialData {

			po := &specialData[i]

			poQty := 0

			milestones, err := s.loadSpecialMilestones(
				db,
				po,
				GSBH,
				date,
			)
			if err != nil {
				return nil, nil, err
			}

			if len(milestones) == 0 {
				continue
			}

			for _, size := range milestones[0].SizeList {
				poQty += size.SizeTargetQuantity
			}

			po.PoQuantity = poQty

			milestones = s.applyMilestoneRules(milestones)

			if err := deckers.DeckerClient.GetSizeList(
				po.StyleNumber,
				po.ColorCode,
				jwt.GetJWT(databaseType),
				deckerSizeSuffixMap,
			); err != nil {
				return nil, nil, err
			}

			milestones, wip8Qty := s.applyMilestoneSizeRules(
				milestones,
				deckerSizeSuffixMap,
				po.StyleNumber+"-"+po.ColorCode,
			)

			po.MilestoneList = milestones
			po.PoCompletionQuantity = wip8Qty

			po.XFDetail = s.applyXFDetail(
				xFDetailMap,
				po,
				deckerSizeSuffixMap,
			)

			if po.PoCompletionQuantity == po.PoQuantity {
				po.Status = "001"
			}
		}

		poStatusData = append(poStatusData, specialData...)

	}

	result := mergeDuplicatePOs(poStatusData)

	return result, []types.DailyPoStatus{}, nil
}

func (s *poStatusService) GetDailySpecialPoStatusByPOList(databaseType, date string, poList []string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH_TypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, err
	}

	poStatusData, err := s.queryPoStatusByListSpecial(db, date, poList, factoryCode, factoryName, DDBH_TypeMap)
	if err != nil {
		return nil, nil, err
	}

	deckerSizeSuffixMap := make(map[string]string)

	xFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
	if err != nil {
		return nil, nil, err
	}

	for i := range poStatusData {

		po := &poStatusData[i]

		// Load milestone
		milestones, err := s.loadSpecialMilestones(db, po, GSBH, date)
		if err != nil {
			return nil, nil, err
		}
		if len(milestones) == 0 {
			continue
		}

		// Milestone business rules
		milestones = s.applyMilestoneRules(milestones)

		// Load size rules (Decker)
		if err := deckers.DeckerClient.GetSizeList(
			po.StyleNumber,
			po.ColorCode,
			jwt.GetJWT(databaseType),
			deckerSizeSuffixMap,
		); err != nil {
			return nil, nil, err
		}

		// Size + WIP calculation
		milestones, wip8Qty := s.applyMilestoneSizeRules(
			milestones,
			deckerSizeSuffixMap,
			po.StyleNumber+"-"+po.ColorCode,
		)

		po.MilestoneList = milestones
		po.PoCompletionQuantity = wip8Qty
		po.PoQuantity = wip8Qty

		// XFDetail enrichment
		po.XFDetail = s.applyXFDetail(
			xFDetailMap,
			po,
			deckerSizeSuffixMap,
		)

		// Status rule
		if po.PoCompletionQuantity == po.PoQuantity {
			po.Status = "001"
		}
	}

	result := mergeDuplicatePOs(poStatusData)
	TestPoStatus(result)

	return result, []types.DailyPoStatus{}, nil
}

func (s *poStatusService) GetDailyPoStatusPreloadByRyList(databaseType, date string, ryList []string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH_TypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, err
	}

	poStatusData, err := s.queryPoStatusByRYList(db, date, factoryCode, factoryName, ryList, DDBH_TypeMap, GSBH)
	if err != nil {
		return nil, nil, err
	}

	deckerSizeSuffixMap := make(map[string]string)

	xFDetailMap := map[string][]types.XFDetail{}

	// xFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
	// if err != nil {
	// 	return nil, nil, err
	// }

	for i := range poStatusData {

		po := &poStatusData[i]

		// Load milestone
		milestones, err := s.loadPreloadMilestones(db, po, GSBH, date)
		if err != nil {
			return nil, nil, err
		}
		if len(milestones) == 0 {
			continue
		}

		// Milestone business rules
		milestones = s.applyMilestoneRules(milestones)

		// Load size rules (Decker)
		if err := deckers.DeckerClient.GetSizeList(
			po.StyleNumber,
			po.ColorCode,
			jwt.GetJWT(databaseType),
			deckerSizeSuffixMap,
		); err != nil {
			return nil, nil, err
		}

		// Size + WIP calculation
		milestones, wip8Qty := s.applyMilestoneSizeRules(
			milestones,
			deckerSizeSuffixMap,
			po.StyleNumber+"-"+po.ColorCode,
		)

		po.MilestoneList = milestones
		po.PoCompletionQuantity = wip8Qty

		// XFDetail enrichment
		po.XFDetail = s.applyXFDetail(
			xFDetailMap,
			po,
			deckerSizeSuffixMap,
		)

		// Status rule
		if po.PoCompletionQuantity == po.PoQuantity {
			po.Status = "001"
		}
	}

	result := mergeDuplicatePOs(poStatusData)
	TestPoStatus(result)

	return result, []types.DailyPoStatus{}, nil
}

func (s *poStatusService) GetDailyPoStatusPreload(databaseType, date string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH_TypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, err
	}

	poStatusData, err := s.queryPoStatusPreload(
		db,
		date,
		factoryCode,
		factoryName,
		DDBH_TypeMap,
	)

	// YQ Preload order have 'P' at the end of DDBH
	if databaseType == "C" {
		preloadOrder := []types.DailyPoStatus{}
		for _, po := range poStatusData {
			runes := []rune(po.DDBH) // Ép kiểu string về mảng rune

			if len(runes) > 0 {
				// Lấy rune cuối cùng và ép ngược lại thành string
				lastChar := string(runes[len(runes)-1])

				if lastChar == "P" {
					preloadOrder = append(preloadOrder, po)
				}
			}

		}
		poStatusData = preloadOrder
	}

	deckerSizeSuffixMap := make(map[string]string)

	xFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
	if err != nil {
		return nil, nil, err
	}

	for i := range poStatusData {

		po := &poStatusData[i]

		// Load milestone
		milestones, err := s.loadMilestones(db, po, GSBH, date)
		if err != nil {
			return nil, nil, err
		}
		if len(milestones) == 0 {
			continue
		}

		// Milestone business rules
		milestones = s.applyMilestoneRules(milestones)

		// Load size rules (Decker)
		if err := deckers.DeckerClient.GetSizeList(
			po.StyleNumber,
			po.ColorCode,
			jwt.GetJWT(databaseType),
			deckerSizeSuffixMap,
		); err != nil {
			return nil, nil, err
		}

		// Size + WIP calculation
		milestones, wip8Qty := s.applyMilestoneSizeRules(
			milestones,
			deckerSizeSuffixMap,
			po.StyleNumber+"-"+po.ColorCode,
		)

		po.MilestoneList = milestones
		po.PoCompletionQuantity = wip8Qty

		// XFDetail enrichment
		po.XFDetail = s.applyXFDetail(
			xFDetailMap,
			po,
			deckerSizeSuffixMap,
		)

		// Status rule
		if po.PoCompletionQuantity == po.PoQuantity {
			po.Status = "001"
		}
	}

	result := filterPreload(poStatusData)
	result = mergeDuplicatePOs(poStatusData)
	TestPoStatus(result)

	return result, []types.DailyPoStatus{}, nil

}

func filterPreload(poList []types.DailyPoStatus) []types.DailyPoStatus {
	result := []types.DailyPoStatus{}

	for _, po := range poList {
		milestone := po.MilestoneList[0]
		if milestone.CompletionQuantity == po.PoQuantity {
			result = append(result, po)
		}
	}

	return result
}

func (s *poStatusService) GetDailyPoStatusCancelByKeyList(databaseType, date string, RyMap map[string]types.CancelPoInfo) ([]types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, PoTypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	poStatusData, err := s.queryPoStatusCancelByKeyList(
		db,
		date,
		RyMap,
		factoryCode,
		factoryName,
		PoTypeMap,
	)
	if err != nil {
		return nil, err
	}

	deckerSizeSuffixMap := make(map[string]string)

	xFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
	if err != nil {
		return nil, err
	}

	for i := range poStatusData {

		po := &poStatusData[i]

		milestones, err := s.loadMilestonesCancelPo(db, po, GSBH, date)
		if err != nil {
			return nil, err
		}
		if len(milestones) == 0 {
			continue
		}

		milestones = s.applyMilestoneRules(milestones)

		if err := deckers.DeckerClient.GetSizeList(
			po.StyleNumber,
			po.ColorCode,
			jwt.GetJWT(databaseType),
			deckerSizeSuffixMap,
		); err != nil {
			return nil, err
		}

		milestones, wip8Qty := s.applyMilestoneSizeRules(
			milestones,
			deckerSizeSuffixMap,
			po.StyleNumber+"-"+po.ColorCode,
		)

		po.MilestoneList = milestones
		po.PoCompletionQuantity = wip8Qty

		po.XFDetail = s.applyXFDetail(
			xFDetailMap,
			po,
			deckerSizeSuffixMap,
		)

		if po.PoCompletionQuantity == po.PoQuantity {
			po.Status = "001"
		}

		// Replace new KHPO with old KHPO
		if oldPoInfo, exist := RyMap[po.DDBH]; exist {
			po.PoNumber = oldPoInfo.PoNumber
			po.ShipID = oldPoInfo.ShipId
		}

	}

	result := mergeDuplicatePOs(poStatusData)
	TestPoStatus(result)

	return result, nil
}

func (s *poStatusService) loadMilestonesCancelPo(
	db *gorm.DB,
	po *types.DailyPoStatus,
	gsbh string,
	date string,
) ([]types.Milestone, error) {

	data, err := GetMilestoneDataCancelPo(
		db,
		po.PoNumber,
		gsbh,
		po.StyleNumber+"-"+po.ColorCode,
		po.DDBH,
		date,
	)
	if err != nil {
		return nil, err
	}

	if len(data) == 0 {
		return nil, nil
	}

	milestones, _ := buildMilestones(data)
	return milestones, nil
}

func (s *poStatusService) loadMilestones(
	db *gorm.DB,
	po *types.DailyPoStatus,
	gsbh string,
	date string,
) ([]types.Milestone, error) {

	data, err := GetMilestoneData(
		db,
		po.PoNumber,
		gsbh,
		po.StyleNumber+"-"+po.ColorCode,
		po.DDBH,
		date,
	)
	if err != nil {
		return nil, err
	}

	if len(data) == 0 {
		return nil, nil
	}

	milestones, _ := buildMilestones(data)
	return milestones, nil
}

func (s *poStatusService) loadPreloadMilestones(
	db *gorm.DB,
	po *types.DailyPoStatus,
	gsbh string,
	date string,
) ([]types.Milestone, error) {

	// data, err := GetPreloadMilestoneData(
	data, err := GetMilestoneData(
		db,
		po.PoNumber,
		gsbh,
		po.StyleNumber+"-"+po.ColorCode,
		po.DDBH,
		date,
	)
	if err != nil {
		return nil, err
	}

	if len(data) == 0 {
		return nil, nil
	}

	milestones, _ := buildMilestones(data)
	return milestones, nil
}

func (s *poStatusService) loadSpecialMilestones(
	db *gorm.DB,
	po *types.DailyPoStatus,
	gsbh string,
	date string,
) ([]types.Milestone, error) {

	data, err := GetAllSpecialSplitPoMilestoneData(
		db,
		po.PoNumber,
		gsbh,
		po.StyleNumber+"-"+po.ColorCode,
		po.DDBH,
		date,
	)
	if err != nil {
		return nil, err
	}

	if len(data) == 0 {
		return nil, nil
	}

	milestones, _ := buildMilestones(data)

	return milestones, nil
}

func (s *poStatusService) applyMilestoneRules(
	milestones []types.Milestone,
) []types.Milestone {

	milestones = fillMissingStages(milestones)
	milestones = sortMilestones(milestones)
	milestones = AdjustQtyByStage(milestones)
	milestones = RemoveStageWithEmptySizeList(milestones)
	milestones = fillEmptyStage(milestones)

	return milestones
}

func (s *poStatusService) applyMilestoneSizeRules(
	milestones []types.Milestone,
	deckerSizeSuffixMap map[string]string,
	styleColorCode string,
) ([]types.Milestone, int) {

	var wip8Qty int

	sizeSuffix, exist := deckerSizeSuffixMap[styleColorCode]

	for i := range milestones {
		m := &milestones[i]

		for si := range m.SizeList {
			size := &m.SizeList[si]

			if len(size.SizeNumber) == 0 {
				continue
			}

			lastChar := size.SizeNumber[len(size.SizeNumber)-1]

			if exist && !unicode.IsLetter(rune(lastChar)) {
				size.SizeNumber += sizeSuffix
			}
		}

		if m.StageCode == "WIP8" {
			wip8Qty = m.CompletionQuantity
		}
	}

	return milestones, wip8Qty
}

// ConvertToFlattenSummary 將原本帶有 Size 的 PO 資料轉換為全新扁平化總量的結構體
func ConvertToFlattenSummary(poList []types.DailyPoStatus) []types.DailyPoXFStatusSummary {
	summaryResult := make([]types.DailyPoXFStatusSummary, len(poList))

	for i, po := range poList {
		// 用來將相同車牌、貨櫃、時間的數量累加的 Map
		summaryMap := make(map[string]*types.XFSummary)

		for _, xf := range po.XFDetail {
			for _, det := range xf.Detail {
				// 建立唯一的 Key (時間 + 車牌 + 貨櫃)
				key := det.XFTime + "_" + det.TruckNumber + "_" + det.ContainerNumber

				if existing, found := summaryMap[key]; found {
					// 如果存在，直接累加數量
					existing.TotalXFQuantity += det.XFQuantity
				} else {
					// 如果不存在，建立新的一筆
					summaryMap[key] = &types.XFSummary{
						XFTime:          det.XFTime,
						TruckNumber:     det.TruckNumber,
						ContainerNumber: det.ContainerNumber,
						TotalXFQuantity: det.XFQuantity,
					}
				}
			}
		}

		// 將 Map 轉回 Array
		var xfSummaries []types.XFSummary
		for _, v := range summaryMap {
			xfSummaries = append(xfSummaries, *v)
		}

		// 對應映射到全新的扁平化結構體
		summaryResult[i] = types.DailyPoXFStatusSummary{
			Date:          po.Date,
			PoNumber:      po.PoNumber,
			PoType:        po.PoType,
			FactoryCode:   po.FactoryCode,
			FactoryName:   po.FactoryName,
			Status:        po.Status,
			StatusMessage: po.StatusMessage,
			StyleNumber:   po.StyleNumber,
			StyleName:     po.StyleName,
			ColorCode:     po.ColorCode,
			Season:        po.Season,
			ShipID:        po.ShipID,
			PoQuantity:    po.PoQuantity,
			LogType:       po.LogType,
			Brand:         po.Brand,
			ConfirmXFDate: po.ConfirmXFDate,
			XFDetail:      xfSummaries, // 塞入加總後的總量明細
		}
	}

	return summaryResult
}

func (s *poStatusService) applyXFDetail(
	xFDetailMap map[string][]types.XFDetail,
	po *types.DailyPoStatus,
	deckerSizeSuffixMap map[string]string,
) []types.XFDetail {

	xf, exist := xFDetailMap[po.DDBH]
	if !exist {
		return []types.XFDetail{}
	}

	sizeSuffix, exist := deckerSizeSuffixMap[po.StyleNumber+"-"+po.ColorCode]

	if !exist {
		return xf
	}

	for i := range xf {

		sizeNumber := xf[i].SizeNumber

		if len(sizeNumber) == 0 {
			continue
		}

		lastChar := sizeNumber[len(sizeNumber)-1]

		if !unicode.IsLetter(rune(lastChar)) {
			xf[i].SizeNumber = sizeNumber + sizeSuffix
		}
	}

	return xf
}

func (s *poStatusService) queryPoStatusByList(
	db *gorm.DB,
	date string,
	poList []string,
	factoryCode string,
	factoryName string,
	DDBH_typeMap map[string][]string,

) ([]types.DailyPoStatus, error) {

	poListSQL := BuildPoListSQL(poList)

	sqlTemplate := `
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			DDZL.KHPO AS poNumber,
			%s
			@factoryCode AS factoryCode,
			@factoryName AS factoryName,
			'002' AS status,
			'Normal' AS statusMessage,
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
			xxzl.XieMing AS styleName,
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
			CASE
				WHEN DDZL.BUYNO LIKE '%s' THEN SUBSTRING(DDZL.BUYNO, 1, 3)
				ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
			END AS season,
			CASE
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
				WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' '
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
			END AS shipId,
			YWCP.Qty AS poCompletionQuantity,
			DDZL.Pairs AS poQuantity,
			'1d' AS logType,
			kfzl.kfjc AS brand,
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,
			0 AS completionQuantity,
			'sizeNumber' AS sizeNumber,
			0 AS sizeCompletionQuantity,
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
		LEFT JOIN (
			SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty
			FROM YWCP
			WHERE YWCP.SB = 1
			GROUP BY YWCP.DDBH
		) YWCP ON YWCP.DDBH = DDZL.DDBH
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		WHERE DDZL.KHPO IN (%s)
			AND DDZL.DDZT = 'Y'
			AND NOT (
				DDZL.DDBH LIKE '%s'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE '%s'
			)
		GROUP BY
			DDZL.DDBH, DDZL.KHPO, DDZL.Article,
			YWCP.Qty, DDZL.Pairs, kfzl.kfjc,
			DDZL.ShipDate, xxzl.XieMing,
			lbzls.zwsm, DDZL.BUYNO;
	`

	sqlQuery := fmt.Sprintf(sqlTemplate,
		getPoTypeQuery(DDBH_typeMap, "DDZL.DDBH"),
		"%PR%",
		poListSQL,
		"%-B%",
		"DHB%",
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
	}

	var poStatusData []types.DailyPoStatus

	if err := db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error; err != nil {
		return nil, err
	}

	return poStatusData, nil
}

func (s *poStatusService) queryPoStatusByListSpecial(
	db *gorm.DB,
	date string,
	poList []string,
	factoryCode string,
	factoryName string,
	DDBH_typeMap map[string][]string,
) ([]types.DailyPoStatus, error) {

	// =====================================================
	// MEMO LIKE 條件
	// =====================================================

	memoConditions := make([]string, len(poList))

	for i, po := range poList {
		memoConditions[i] = fmt.Sprintf(
			"YWBZPOS.MEMO LIKE '%s%%'",
			po,
		)
	}

	memoWhere := strings.Join(memoConditions, " OR ")

	// =====================================================
	// KHPO IN 條件
	// =====================================================

	quotedPOList := make([]string, len(poList))

	for i, po := range poList {
		quotedPOList[i] = fmt.Sprintf("'%s'", po)
	}

	khpoInClause := strings.Join(quotedPOList, ",")

	// =====================================================
	// SQL
	// =====================================================

	sqlTemplate := `
	WITH PoFromMemo AS (

		-- 從 MEMO 找
		SELECT DISTINCT 
			YWBZPOS.DDBH,
			REPLACE(REPLACE(RTRIM(YWBZPOS.MEMO), CHAR(13), ''), CHAR(10), '') AS PO_NUMBER
		FROM YWBZPOS
		WHERE %s

		UNION

		-- 從 KHPO 找
		SELECT DISTINCT
			DDZL.DDBH,
			DDZL.KHPO AS PO_NUMBER
		FROM DDZL
		WHERE DDZL.KHPO IN (%s)
	)

	SELECT
		CONVERT(VARCHAR(10), @date, 23) AS date,

		PoFromMemo.PO_NUMBER AS poNumber,

		%s

		@factoryCode AS factoryCode,

		@factoryName AS factoryName,

		'002' AS status,

		'Normal' AS statusMessage,

		SUBSTRING(
			DDZL.Article,
			1,
			CHARINDEX('-', DDZL.Article) - 1
		) AS styleNumber,

		xxzl.XieMing AS styleName,

		SUBSTRING(
			DDZL.Article,
			CHARINDEX('-', DDZL.Article) + 1,
			LEN(DDZL.Article)
		) AS colorCode,

		CASE
			WHEN DDZL.BUYNO LIKE '%s'
				THEN SUBSTRING(DDZL.BUYNO, 1, 3)
			ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
		END AS season,

		CASE
			WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
			WHEN SUBSTRING(
				lbzls.zwsm,
				1,
				CHARINDEX(' ', lbzls.zwsm) - 1
			) IS NULL THEN ' '
			ELSE SUBSTRING(
				lbzls.zwsm,
				1,
				CHARINDEX(' ', lbzls.zwsm) - 1
			)
		END AS shipId,

		0 AS poCompletionQuantity,

		ISNULL(YWBZPOS_AGG.poQuantity, 0) AS poQuantity,

		'1d' AS logType,

		kfzl.kfjc AS brand,

		CONVERT(VARCHAR, DDZL.ShipDate, 23) AS confirmXFDate,

		'stageCode' AS stageCode,

		0 AS completionQuantity,

		'sizeNumber' AS sizeNumber,

		0 AS sizeCompletionQuantity,

		0 AS sizeTargetQuantity,

		DDZL.DDBH AS DDBH

	FROM PoFromMemo

	LEFT JOIN DDZL 
		ON DDZL.DDBH = PoFromMemo.DDBH

	LEFT JOIN kfzl 
		ON DDZL.KHBH = kfzl.kfdh

	LEFT JOIN SMDD 
		ON SMDD.YSBH = DDZL.DDBH

	LEFT JOIN SMDDSS 
		ON SMDDSS.DDBH = SMDD.DDBH

	LEFT JOIN SMZL 
		ON SMZL.CODEBAR = SMDDSS.CODEBAR

	LEFT JOIN xxzl 
		ON xxzl.XieXing = DDZL.XieXing 
		AND xxzl.SheHao = DDZL.SheHao

	LEFT JOIN (
		SELECT 
			YWCP.DDBH,
			SUM(YWCP.Qty) AS Qty
		FROM YWCP
		WHERE YWCP.SB = 1
		GROUP BY YWCP.DDBH
	) YWCP 
		ON YWCP.DDBH = DDZL.DDBH

	LEFT JOIN (
		SELECT 
			DDBH,
			SUM(Qty * CTS) AS poQuantity
		FROM YWBZPOS
		GROUP BY DDBH
	) YWBZPOS_AGG
		ON YWBZPOS_AGG.DDBH = DDZL.DDBH

	LEFT JOIN lbzls 
		ON DDZL.Dest = lbzls.lbdh 
		AND lbzls.lb = '13'

	WHERE DDZL.DDZT = 'Y'
		AND NOT (
			DDZL.DDBH LIKE '%s'
			OR RIGHT(DDZL.DDBH, 2) = 'BG'
			OR DDZL.DDBH LIKE '%s'
		)

	GROUP BY
		PoFromMemo.PO_NUMBER,
		DDZL.DDBH,
		DDZL.Article,
		YWCP.Qty,
		YWBZPOS_AGG.poQuantity,
		DDZL.Pairs,
		kfzl.kfjc,
		DDZL.ShipDate,
		xxzl.XieMing,
		lbzls.zwsm,
		DDZL.BUYNO;
	`

	sqlQuery := fmt.Sprintf(
		sqlTemplate,
		memoWhere,
		khpoInClause,
		getPoTypeQuery(DDBH_typeMap, "DDZL.DDBH"),
		"%PR%",
		"%-B%",
		"DHB%",
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
	}

	var poStatusData []types.DailyPoStatus

	if err := db.Raw(sqlQuery, queryParams).
		Scan(&poStatusData).Error; err != nil {

		return nil, err
	}

	return poStatusData, nil
}

func (s *poStatusService) queryPoStatusByRYList(
	db *gorm.DB,
	date string,
	factoryCode string,
	factoryName string,
	ddbhList []string,
	DDBH map[string][]string,
	GSBH string,
) ([]types.DailyPoStatus, error) {

	if len(ddbhList) == 0 {
		return []types.DailyPoStatus{}, nil
	}

	ddbhStr := "'" + strings.Join(ddbhList, "','") + "'"

	if DDBH == nil {
		DDBH = map[string][]string{}
	}

	sqlQuery := fmt.Sprintf(`
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			ISNULL(DDZL.DDBH, '') AS poNumber,
			%s
			@factoryCode AS factoryCode,
			@factoryName AS factoryName,
			'002' AS status,
			'Normal' AS statusMessage,
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
			xxzl.XieMing AS styleName,
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
			xxzl.jijie AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,
			YWCP.Qty AS poCompletionQuantity,
			DDZL.Pairs AS poQuantity,
			'1d' AS logType,
			kfzl.kfjc AS brand,
			CONVERT(VARCHAR, DDZL.ShipDate, 23) AS confirmXFDate,
			'stageCode' AS stageCode,
			0 AS completionQuantity,
			'sizeNumber' AS sizeNumber,
			0 AS sizeCompletionQuantity,
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
		LEFT JOIN (
			SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty 
			FROM YWCP 
			WHERE YWCP.SB = 1 
			GROUP BY YWCP.DDBH
		) YWCP ON YWCP.DDBH = DDZL.DDBH
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
		WHERE DDZL.DDBH IN (%s)
		GROUP BY 
			DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs,
			kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, xxzl.jijie
		ORDER BY DDZL.KHPO
	`,
		getPoTypeQuery(DDBH, "DDZL.DDBH"),
		ddbhStr,
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
		"gsbh":        GSBH,
	}

	var poStatusData []types.DailyPoStatus

	if err := db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error; err != nil {
		return nil, err
	}

	return poStatusData, nil
}

func (s *poStatusService) queryPoStatusPreload(
	db *gorm.DB,
	date string,
	factoryCode string,
	factoryName string,
	DDBH map[string][]string,
) ([]types.DailyPoStatus, error) {

	// 防止 nil map
	if DDBH == nil {
		DDBH = map[string][]string{}
	}

	sqlQuery := fmt.Sprintf(`
		DECLARE @StartDate DATETIME = CAST(@date AS DATETIME);
		DECLARE @EndDate DATETIME = DATEADD(DAY, 1, @StartDate); 

		
		WITH ListDDBH AS (
			SELECT
				k.CGBH AS DDBH
			FROM kcrks k
				join DDZL d ON k.CGBH = d.DDBH
			WHERE
				k.CGBH LIKE %s
				AND k.USERDATE >= @StartDate
				AND k.USERDATE < @EndDate
				AND d.BUYNO NOT LIKE %s
			GROUP BY k.CGBH
		)
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			ISNULL(DDZL.DDBH, '') AS poNumber, 
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			xxzl.jijie AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,  
			YWCP.Qty AS poCompletionQuantity,  
			DDZL.Pairs AS poQuantity,  
			'1d' AS logType,  
			kfzl.kfjc AS brand, 
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,  
			0 AS completionQuantity,  
			'sizeNumber' AS sizeNumber,  
			0 AS sizeCompletionQuantity,  
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL  
		INNER JOIN ListDDBH ON ListDDBH.DDBH = DDZL.DDBH 
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh  
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH  
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH  
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR  
		LEFT JOIN (
			SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty 
			FROM YWCP 
			WHERE YWCP.SB = 1 
			GROUP BY YWCP.DDBH
		) YWCP ON YWCP.DDBH = DDZL.DDBH  
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
		GROUP BY 
			DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, 
			kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, xxzl.jijie
		ORDER BY DDZL.KHPO;
	`,
		"'F%'", // Preload 關鍵條件
		"'%L'", // Filter Forcast orders
		getPoTypeQuery(DDBH, "DDZL.DDBH"),
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
	}

	var poStatusData []types.DailyPoStatus

	if err := db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error; err != nil {
		return nil, err
	}

	return poStatusData, nil
}

func (s *poStatusService) queryPoStatusCancelByKeyList(
	db *gorm.DB,
	date string,
	ryMap map[string]types.CancelPoInfo, // 你目前是用 Keys(ryMap)
	factoryCode string,
	factoryName string,
	DDBH map[string][]string,
) ([]types.DailyPoStatus, error) {

	// 將 map key 轉成 SQL IN (...)
	poListSQL := BuildPoListSQL(Keys(ryMap))

	sqlTemplate := `
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			DDZL.KHPO AS poNumber,
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			CASE 
				WHEN DDZL.BUYNO LIKE '%s' THEN SUBSTRING(DDZL.BUYNO, 1, 3)
				ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
			END AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
				WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,
			YWCP.Qty AS poCompletionQuantity,
			DDZL.Pairs AS poQuantity,
			'1d' AS logType,
			kfzl.kfjc AS brand,
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,
			0 AS completionQuantity,
			'sizeNumber' AS sizeNumber,
			0 AS sizeCompletionQuantity,
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
		LEFT JOIN (
			SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty 
			FROM YWCP 
			WHERE YWCP.SB = 1 
			GROUP BY YWCP.DDBH
		) YWCP ON YWCP.DDBH = DDZL.DDBH
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		WHERE DDZL.DDBH IN (%s)
		GROUP BY 
			DDZL.DDBH, DDZL.KHPO, DDZL.Article, 
			YWCP.Qty, DDZL.Pairs, kfzl.kfjc, 
			DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO;
	`

	sqlQuery := fmt.Sprintf(sqlTemplate,
		getPoTypeQuery(DDBH, "DDZL.DDBH"),
		"%PR%",
		poListSQL,
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
	}

	var poStatusData []types.DailyPoStatus

	if err := db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error; err != nil {
		return nil, err
	}

	return poStatusData, nil
}

func getShippedPoList(db *gorm.DB, startTime, endTime string, DDBH map[string][]string) ([]string, error) {

	ddbhCondition := getDDBHQuery(DDBH, "DDZL.DDBH")

	if strings.HasPrefix(strings.TrimSpace(ddbhCondition), "'") {
		ddbhCondition = "DDZL.DDBH LIKE " + ddbhCondition
	}
	ddbhCondition = strings.ReplaceAll(ddbhCondition, "( '", "( DDZL.DDBH LIKE '")

	queryString := fmt.Sprintf(`
    SELECT DISTINCT 
        LTRIM(RTRIM(DDZL.KHPO)) AS KHPO
    FROM YWCP
    LEFT JOIN DDZL ON DDZL.DDBH = YWCP.DDBH
    WHERE YWCP.sb = '3'
      AND NOT (
          DDZL.DDBH LIKE '%%%%-B%%%%'
          OR RIGHT(DDZL.DDBH, 2) = 'BG'
          OR DDZL.DDBH LIKE 'DHB%%%%'
      )
      AND ( %s )
      AND ISNULL(DDZL.KHPO, '') <> ''
      AND YWCP.EXEDATE >= ?
      AND YWCP.EXEDATE < ?
    ORDER BY KHPO`,
		ddbhCondition,
	)

	var poList []string

	err := db.Raw(
		queryString,
		startTime,
		endTime,
	).Scan(&poList).Error

	if err != nil {
		return nil, err
	}

	// 清除字串前後空白
	for i := range poList {
		poList[i] = strings.TrimSpace(poList[i])
	}

	return poList, nil
}

func getChangedKHPO(db *gorm.DB, date time.Time, gsbh string, DDBH map[string][]string, start, end time.Time) ([]string, error) {

	// 1. 為不同來源生成專屬的 DDBH 過濾條件
	// 來源 1 & 2 使用 DDZL.DDBH
	condSource12 := getDDBHQuery(DDBH, "DDZL.DDBH")
	if condSource12 != "" {
		condSource12 = " AND (DDZL.DDBH LIKE " + condSource12 + ")"
	}

	// 來源 3 使用 KCRKS.CGBH
	condSource3 := getDDBHQuery(DDBH, "KCRKS.CGBH")
	if condSource3 != "" {
		condSource3 = " AND (KCRKS.CGBH LIKE " + condSource3 + ")"
	}

	// 來源 4 使用 YWBZPOS.MEMO
	condSource4 := getDDBHQuery(DDBH, "YWBZPOS.DDBH")
	if condSource4 != "" {
		condSource4 = " AND (YWBZPOS.DDBH LIKE " + condSource4 + ")"
	}

	// 2. 組合完整的 SQL 語法
	queryString := fmt.Sprintf(`
    WITH ListKHPO AS (
        -- Nguồn 1
        SELECT DISTINCT LTRIM(RTRIM(DDZL.KHPO)) AS KHPO
        FROM YWCP
        INNER JOIN DDZL ON DDZL.DDBH = YWCP.DDBH
        WHERE 
			(
				(YWCP.EXEDATE >= @startDate AND YWCP.EXEDATE < @endDate)
				OR (YWCP.INDATE  >= @startDate AND YWCP.INDATE  < @endDate)
				OR (YWCP.REDATE  >= @startDate AND YWCP.REDATE  < @endDate)
			)
			%s -- 填入 來源 1 的條件
			AND ISNULL(DDZL.KHPO, '') <> ''

        UNION

        -- Nguồn 2
        SELECT DISTINCT LTRIM(RTRIM(DDZL.KHPO)) AS KHPO
        FROM SMDD
        INNER JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH AND SMDD.GXLB = SMDDSS.GXLB
        INNER JOIN DDZL ON DDZL.DDBH = SMDD.YSBH
        WHERE
			SMDDSS.ScanEDate >= @startDate
			AND SMDDSS.ScanEDate < @endDate
        	%s -- 填入 來源 2 的條件
        	AND ISNULL(DDZL.KHPO, '') <> ''

        UNION

        -- Nguồn 3
        SELECT DISTINCT LTRIM(RTRIM(DDZL.KHPO)) AS KHPO
        FROM KCRK
        LEFT JOIN KCRKS ON KCRK.RKNO = KCRKS.RKNO
        INNER JOIN DDZL ON DDZL.DDBH = KCRKS.CGBH
        WHERE
			KCRK.CFMDATE >= @startDate
			AND KCRK.CFMDATE < @endDate
			AND KCRK.GSBH = @gsbh
			%s -- 填入 來源 3 的條件
			AND ISNULL(DDZL.KHPO, '') <> ''

        UNION

        -- Nguồn 4: MEMO
        SELECT DISTINCT
            LTRIM(RTRIM(REPLACE(REPLACE(MEMO, CHAR(13), ''), CHAR(10), ''))) AS KHPO
        FROM YWBZPOS
        WHERE
			MEMO IS NOT NULL
			%s -- 填入 來源 4 的條件
			AND USERDATE >= @startDate
			AND USERDATE < @endDate
    )
    SELECT DISTINCT KHPO
    FROM ListKHPO
    WHERE ISNULL(KHPO, '') <> ''
    ORDER BY KHPO`,
		condSource12, // 對應 Nguồn 1 的 %s
		condSource12, // 對應 Nguồn 2 的 %s
		condSource3,  // 對應 Nguồn 3 的 %s
		condSource4,  // 對應 Nguồn 4 的 %s
	)

	params := map[string]interface{}{
		"startDate": start,
		"endDate":   end,
		"gsbh":      gsbh,
	}

	var poList []string

	// 3. 傳入問號占位符參數
	err := db.Raw(queryString, params).Scan(&poList).Error
	if err != nil {
		return nil, err
	}

	// 清除字串空白
	for i := range poList {
		poList[i] = strings.TrimSpace(poList[i])
	}

	return poList, nil
}
