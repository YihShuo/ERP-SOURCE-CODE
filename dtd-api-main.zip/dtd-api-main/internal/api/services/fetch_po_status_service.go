package services

import (
	"database/sql"
	"encoding/base64"
	"fmt"
	"io/ioutil"
	"log"
	"mime/multipart"
	"strings"
	"time"
	"unicode"
	"web-api/internal/integration/deckers"
	"web-api/internal/pkg/database"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/models/request"
	"web-api/internal/pkg/models/types"
	"web-api/internal/pkg/utils"

	"gorm.io/gorm"
)

type StageQueryParam struct {
	KHPO    string
	ARTICLE string
	DDBH    string
	GSBH    string
	DATE    string
}

type StageResult struct {
	StageCode              string `gorm:"column:stageCode"`
	CompletionQuantity     int    `gorm:"column:completionQuantity"`
	SizeNumber             string `gorm:"column:sizeNumber"`
	SizeCompletionQuantity int    `gorm:"column:sizeCompletionQuantity"`
	SizeTargetQuantity     int    `gorm:"column:sizeTargetQuantity"`
	DailyOutput            int    `gorm:"column:dailyOutput"`
}

func (s *poStatusService) GetFullFG10POList(databaseType, date string, poList []string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, err
	}

	poListSQL := BuildPoListSQL(poList)

	sqlTemplate := `
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			DDZL.KHPO AS poNumber,
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			CASE 
				WHEN DDZL.BUYNO LIKE '%s' THEN SUBSTRING(DDZL.BUYNO, 1, 3)
				ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
			END AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
				WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,
			YWCP.Qty AS poCompletionQuantity,
			DDZL.Pairs AS poQuantity,
			'1d' AS logType,
			kfzl.kfjc AS brand,
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,
			0 AS completionQuantity,
			'sizeNumber' AS sizeNumber,
			0 AS sizeCompletionQuantity,
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP
			ON YWCP.DDBH = DDZL.DDBH
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		WHERE DDZL.KHPO IN (%s)
			AND DDZL.DDZT = 'Y'
			AND NOT (
				DDZL.DDBH LIKE '%s'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE '%s'
			)
		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO;
	`

	sqlQuery := fmt.Sprintf(sqlTemplate,
		getPoTypeQuery(DDBH, "DDZL.DDBH"),
		"%PR%",    // %s #3 (PO 季節提取)
		poListSQL, // %s #5
		"%-B%",
		"DHB%",
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
	}

	// 查詢 DailyPoStatus 資料
	var poStatusData []types.DailyPoStatus
	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
	if err != nil {
		return nil, nil, err
	}

	// Cache size list from Decker
	deckerSizeList := make(map[string]string)

	rawData := []types.DailyPoStatus{}

	// Get XFDetailMap
	XFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
	if err != nil {
		return nil, nil, err
	}

	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
	for i := range poStatusData {
		value := &poStatusData[i]
		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		sizeMapKey := value.StyleNumber + "-" + value.ColorCode

		println("Processing PO:", value.PoNumber)

		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		// 獲取 Milestone 資料
		milestoneListData, err := GetFullFG10MilestoneData(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH, date)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
		}

		var rawPo = *value
		rawPo.MilestoneList = milestoneListData
		rawData = append(rawData, rawPo)

		// 如果有 Milestone 資料，才填充到 MilestoneList
		if len(milestoneListData) > 0 {
			milestoneMap := make(map[string]*types.Milestone)
			for _, ml := range milestoneListData {
				// 根據 StageCode 轉換
				switch ml.StageCode {
				case "C":
					ml.StageCode = "WIP3-1"
				case "O":
					ml.StageCode = "WIP3-3"
				case "S":
					ml.StageCode = "WIP6"
				case "A":
					ml.StageCode = "WIP8"
				}

				if milestone, exists := milestoneMap[ml.StageCode]; exists {
					milestone.CompletionQuantity += ml.CompletionQuantity
					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
				} else {
					milestoneMap[ml.StageCode] = &types.Milestone{
						StageCode:          ml.StageCode,
						CompletionQuantity: ml.CompletionQuantity,
						SizeList:           ml.SizeList,
					}
				}
			}

			var newMilestoneListData []types.Milestone
			for _, milestone := range milestoneMap {
				newMilestoneListData = append(newMilestoneListData, *milestone)
			}

			newMilestoneListData = fillMissingStages(newMilestoneListData)
			sortMilestones(newMilestoneListData)

			// for index, milestone := range newMilestoneListData {
			// 	if milestone.StageCode == "WIP3-3" {
			// 		newMilestoneListData[index].CompletionQuantity = 2000
			// 	}
			// }

			AdjustQtyByStage(newMilestoneListData)
			newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
			newMilestoneListData = fillEmptyStage(newMilestoneListData)
			value.MilestoneList = newMilestoneListData
		}

		err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(databaseType), deckerSizeList)
		if err != nil {
			return nil, nil, fmt.Errorf("error when get size list from deckers")
		}

		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
		for _, milestone := range value.MilestoneList {

			// Get last size string from size map and check if exist
			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

				// Change all size number: add last size string to the end
				for index := range milestone.SizeList {

					size := &milestone.SizeList[index]

					// Ignore empty size number
					if len(size.SizeNumber) > 0 {

						// Get last character in size number
						lastCharIndex := len(size.SizeNumber) - 1
						checkingChar := size.SizeNumber[lastCharIndex]

						// Check if it was added or not
						if !unicode.IsLetter(rune(checkingChar)) {

							// Add to the end
							size.SizeNumber += lastSizeStr
						}
					}
				}
			}

			// Add PO completion Qty = WIP8's Qty
			if milestone.StageCode == "WIP8" {
				value.PoCompletionQuantity = milestone.CompletionQuantity
			}
		}

		if value.PoCompletionQuantity == value.PoQuantity {
			value.Status = "001"
		}

		// XF Detail
		XFDetail, exist := XFDetailMap[value.DDBH]
		if exist {
			value.XFDetail = XFDetail
		} else {
			value.XFDetail = []types.XFDetail{}
		}
		for index, XFDetail := range value.XFDetail {

			// Get last size string from size map and check if exist
			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

				sizeNumber := XFDetail.SizeNumber

				// Get last character in size number
				lastCharIndex := len(sizeNumber) - 1
				checkingChar := sizeNumber[lastCharIndex]

				// Check if it was added or not
				if !unicode.IsLetter(rune(checkingChar)) {

					// Add to the end
					sizeNumber += lastSizeStr
					value.XFDetail[index].SizeNumber = sizeNumber
				}
			}
		}
	}

	result := mergeDuplicatePOs(poStatusData)
	// result := poStatusData

	TestPoStatus(result)

	return result, rawData, nil
}

func (s *poStatusService) GetPOListByDatabaseInfo(request request.PoListDb) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := database.SetupCustomDatabaseConnection(request)
	if err != nil {
		return nil, nil, err
	}

	poListSQL := BuildPoListSQL(request.PoList)

	sqlTemplate := `
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			DDZL.KHPO AS poNumber,
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			CASE 
				WHEN DDZL.BUYNO LIKE '%s' THEN SUBSTRING(DDZL.BUYNO, 1, 3)
				ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
			END AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
				WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,
			YWCP.Qty AS poCompletionQuantity,
			DDZL.Pairs AS poQuantity,
			'1d' AS logType,
			kfzl.kfjc AS brand,
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,
			0 AS completionQuantity,
			'sizeNumber' AS sizeNumber,
			0 AS sizeCompletionQuantity,
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP
			ON YWCP.DDBH = DDZL.DDBH
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		WHERE DDZL.KHPO IN (%s)
			AND DDZL.DDZT = 'Y'
			AND NOT (
				DDZL.DDBH LIKE '%s'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE '%s'
			)
		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO;
	`

	sqlQuery := fmt.Sprintf(sqlTemplate,
		getPoTypeQuery(DDBH, "DDZL.DDBH"),
		"%PR%",    // %s #3 (PO 季節提取)
		poListSQL, // %s #5
		"%-B%",
		"DHB%",
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        request.Date,
	}

	// 查詢 DailyPoStatus 資料
	var poStatusData []types.DailyPoStatus
	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
	if err != nil {
		return nil, nil, err
	}

	// Cache size list from Decker
	deckerSizeList := make(map[string]string)

	rawData := []types.DailyPoStatus{}

	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
	for i := range poStatusData {
		value := &poStatusData[i]
		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		sizeMapKey := value.StyleNumber + "-" + value.ColorCode

		println("Processing PO:", value.PoNumber)

		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		// 獲取 Milestone 資料
		milestoneListData, err := GetMilestoneData(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH, request.Date)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
		}

		var rawPo = *value
		rawPo.MilestoneList = milestoneListData
		rawData = append(rawData, rawPo)

		// 如果有 Milestone 資料，才填充到 MilestoneList
		if len(milestoneListData) > 0 {
			milestoneMap := make(map[string]*types.Milestone)
			for _, ml := range milestoneListData {
				// 根據 StageCode 轉換
				switch ml.StageCode {
				case "C":
					ml.StageCode = "WIP3-1"
				case "O":
					ml.StageCode = "WIP3-3"
				case "S":
					ml.StageCode = "WIP6"
				case "A":
					ml.StageCode = "WIP8"
				}

				if milestone, exists := milestoneMap[ml.StageCode]; exists {
					milestone.CompletionQuantity += ml.CompletionQuantity
					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
				} else {
					milestoneMap[ml.StageCode] = &types.Milestone{
						StageCode:          ml.StageCode,
						CompletionQuantity: ml.CompletionQuantity,
						SizeList:           ml.SizeList,
					}
				}
			}

			var newMilestoneListData []types.Milestone
			for _, milestone := range milestoneMap {
				newMilestoneListData = append(newMilestoneListData, *milestone)
			}

			newMilestoneListData = fillMissingStages(newMilestoneListData)
			sortMilestones(newMilestoneListData)

			// for index, milestone := range newMilestoneListData {
			// 	if milestone.StageCode == "WIP3-3" {
			// 		newMilestoneListData[index].CompletionQuantity = 2000
			// 	}
			// }

			AdjustQtyByStage(newMilestoneListData)
			newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
			newMilestoneListData = fillEmptyStage(newMilestoneListData)
			value.MilestoneList = newMilestoneListData
		}

		err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(request.DatabaseType), deckerSizeList)
		if err != nil {
			return nil, nil, fmt.Errorf("error when get size list from deckers")
		}

		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
		for _, milestone := range value.MilestoneList {

			// Get last size string from size map and check if exist
			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

				// Change all size number: add last size string to the end
				for index := range milestone.SizeList {

					size := &milestone.SizeList[index]

					// Ignore empty size number
					if len(size.SizeNumber) > 0 {

						// Get last character in size number
						lastCharIndex := len(size.SizeNumber) - 1
						checkingChar := size.SizeNumber[lastCharIndex]

						// Check if it was added or not
						if !unicode.IsLetter(rune(checkingChar)) {

							// Add to the end
							size.SizeNumber += lastSizeStr
						}
					}
				}
			}

			// Add PO completion Qty = WIP8's Qty
			if milestone.StageCode == "WIP8" {
				value.PoCompletionQuantity = milestone.CompletionQuantity
			}
		}

		if value.PoCompletionQuantity == value.PoQuantity {
			value.Status = "001"
		}
	}

	result := mergeDuplicatePOs(poStatusData)
	// result := poStatusData

	TestPoStatus(result)

	return result, rawData, nil
}

func (s *poStatusService) GetDailyPoStatusByDatabaseInfo(request request.PoListDb) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := database.SetupCustomDatabaseConnection(request)
	if err != nil {
		return nil, nil, err
	}

	sqlQuery := fmt.Sprintf(`
		WITH ListKHPO AS (
			-- Nguồn 1: Bảng YWCP với ngày xuất hoặc ngày nhập hôm nay
			SELECT DISTINCT DDZL.KHPO
			FROM YWCP 
			INNER JOIN DDZL 
			ON DDZL.DDBH = YWCP.DDBH
			WHERE 
			(
				CONVERT(DATE, YWCP.EXEDATE) = CONVERT(DATE, @date)
				OR CONVERT(DATE, YWCP.INDATE) = CONVERT(DATE, @date)
				OR CONVERT(DATE, YWCP.REDATE) = CONVERT(DATE, @date)
			)
			AND DDZL.KHPO IS NOT NULL
			AND LTRIM(RTRIM(DDZL.KHPO)) <> ''

			
			UNION
			
			-- Nguồn 2: Bảng SMDDSS với ngày quét hôm nay
			SELECT DISTINCT KHPO
			FROM SMDD 
				INNER JOIN SMDDSS on SMDDSS.DDBH = SMDD.DDBH and SMDD.GXLB = SMDDSS.GXLB
				INNER JOIN DDZL ON DDZL.DDBH = SMDD.YSBH
			WHERE CONVERT(DATE, ScanEDate) = CONVERT(DATE, @date)
			
			UNION
			
			-- Nguồn 3: Bảng KCRK + KCRKS với ngày xác nhận nhập kho hôm nay
			SELECT  distinct DDZL.KHPO
			FROM KCRK
			LEFT JOIN KCRKS ON KCRK.RKNO = KCRKS.RKNO
			INNER JOIN DDZL ON DDZL.DDBH = KCRKS.CGBH
			WHERE CONVERT(DATE, CFMDATE) = CONVERT(DATE, @date)
			AND KCRK.GSBH = @gsbh
			AND (KCRKS.CGBH LIKE %s)
		)
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			DDZL.KHPO AS poNumber, 
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			CASE 
				WHEN CHARINDEX('-', DDZL.Article) > 0 
				THEN SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1)
				ELSE DDZL.Article
			END AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			xxzl.jijie AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,  
			YWCP.Qty AS poCompletionQuantity,  
			DDZL.Pairs AS poQuantity,  
			'1d' AS logType,  
			kfzl.kfjc AS brand, 
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,  
			0 AS completionQuantity,  
			'sizeNumber' AS sizeNumber,  
			0 AS sizeCompletionQuantity,  
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL  
		INNER JOIN ListKHPO ON ListKHPO.KHPO = DDZL.KHPO 
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh  
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH  
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH  
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR  
		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP  
			ON YWCP.DDBH = DDZL.DDBH  
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
		WHERE 1=1
			AND DDZL.KHPO != ''
			AND DDZL.KHPO IS NOT NULL
			AND DDZL.DDZT = 'Y'
			AND (DDZL.DDBH LIKE %s)
			AND NOT (
				DDZL.DDBH LIKE '%s'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE '%s'
			)
		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, xxzl.jijie
		ORDER BY DDZL.KHPO;

	`, getDDBHQuery(DDBH, "KCRKS.CGBH"), getPoTypeQuery(DDBH, "DDZL.DDBH"), getDDBHQuery(DDBH, "DDZL.DDBH"), "%-B%", "DHB%")

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        request.Date,
		"gsbh":        GSBH,
	}
	// 查詢 DailyPoStatus 資料
	var poStatusData []types.DailyPoStatus

	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
	if err != nil {
		return nil, nil, err
	}

	rawData := []types.DailyPoStatus{}

	// Cache size list from Decker
	deckerSizeList := make(map[string]string)

	// Get XFDetailMap
	// XFDetailMap, err := GetXFDetailMap(db, date, databaseType)
	// if err != nil {
	// 	return nil, nil, err
	// }

	const batchSize = 100

	for start := 0; start < len(poStatusData); start += batchSize {

		end := start + batchSize
		if end > len(poStatusData) {
			end = len(poStatusData)
		}

		log.Printf("Processing PO batch: %d ~ %d\n", start, end)

		batch := poStatusData[start:end]

		for i := range batch {
			value := &batch[i]

			value.MilestoneList = []types.Milestone{}

			sizeMapKey := value.StyleNumber + "-" + value.ColorCode

			milestoneListData, err := GetMilestoneData(
				db,
				value.PoNumber,
				GSBH,
				value.StyleNumber+"-"+value.ColorCode,
				value.DDBH,
				request.Date,
			)
			if err != nil {
				return nil, nil, fmt.Errorf(
					"failed to get milestone data for PoNumber %s: %v",
					value.PoNumber,
					err,
				)
			}
			rawMilestone := []types.Milestone{}

			// 如果有 Milestone 資料，才填充到 MilestoneList
			if len(milestoneListData) > 0 {
				milestoneMap := make(map[string]*types.Milestone)
				for _, ml := range milestoneListData {
					// 根據 StageCode 轉換
					switch ml.StageCode {
					case "C":
						ml.StageCode = "WIP3-1"
					case "O":
						ml.StageCode = "WIP3-3"
					case "S":
						ml.StageCode = "WIP6"
					case "A":
						ml.StageCode = "WIP8"
					}

					rawMilestone = append(rawMilestone, ml)

					if milestone, exists := milestoneMap[ml.StageCode]; exists {
						milestone.CompletionQuantity += ml.CompletionQuantity
						milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
					} else {
						milestoneMap[ml.StageCode] = &types.Milestone{
							StageCode:          ml.StageCode,
							CompletionQuantity: ml.CompletionQuantity,
							SizeList:           ml.SizeList,
						}
					}
				}

				// Export raw data
				var rawPo = *value
				rawPo.MilestoneList = rawMilestone
				rawData = append(rawData, rawPo)

				var newMilestoneListData []types.Milestone
				for _, milestone := range milestoneMap {
					newMilestoneListData = append(newMilestoneListData, *milestone)
				}

				// Milestone handling code
				newMilestoneListData = fillMissingStages(newMilestoneListData)
				sortMilestones(newMilestoneListData)
				AdjustQtyByStage(newMilestoneListData)
				newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
				newMilestoneListData = fillEmptyStage(newMilestoneListData)
				value.MilestoneList = newMilestoneListData
			}

			err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(request.DatabaseType), deckerSizeList)
			if err != nil {
				return nil, nil, fmt.Errorf("error when get size list from deckers")
			}

			// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
			for _, milestone := range value.MilestoneList {

				// Get last size string from size map and check if exist
				if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

					// Change all size number: add last size string to the end
					for index := range milestone.SizeList {

						size := &milestone.SizeList[index]

						// Ignore empty size number
						if len(size.SizeNumber) > 0 {

							// Get last character in size number
							lastCharIndex := len(size.SizeNumber) - 1
							checkingChar := size.SizeNumber[lastCharIndex]

							// Check if it was added or not
							if !unicode.IsLetter(rune(checkingChar)) {

								// Add to the end
								size.SizeNumber += lastSizeStr
							}
						}
						size.SizeNumber = strings.TrimSpace(size.SizeNumber)
					}
				}

				// Add PO completion Qty = WIP8's Qty
				if milestone.StageCode == "WIP8" {
					value.PoCompletionQuantity = milestone.CompletionQuantity
				}
			}

			if value.PoCompletionQuantity == value.PoQuantity {
				value.Status = "001"
			}

			if value.PoCompletionQuantity == value.PoQuantity {
				value.Status = "001"
			}
		}
	}
	result := mergeDuplicatePOs(poStatusData)

	TestPoStatus(result)

	return result, rawData, nil
}

func (s *poStatusService) GetDailyPoStatusPreloadByDatabaseInfo(request request.PoListDb) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(request.DatabaseType)
	if err != nil {
		return nil, nil, err
	}

	sqlQuery := fmt.Sprintf(`
		WITH ListDDBH AS (
			SELECT DISTINCT DDBH FROM DDZL
			WHERE USERDATE = CAST(@date AS DATE)
				AND DDBH LIKE %s
		)
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			ISNULL(DDZL.KHPO, '') AS poNumber, 
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			xxzl.jijie AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,  
			YWCP.Qty AS poCompletionQuantity,  
			DDZL.Pairs AS poQuantity,  
			'1d' AS logType,  
			kfzl.kfjc AS brand, 
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,  
			0 AS completionQuantity,  
			'sizeNumber' AS sizeNumber,  
			0 AS sizeCompletionQuantity,  
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL  
		INNER JOIN ListDDBH ON ListDDBH.DDBH = DDZL.DDBH 
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh  
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH  
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH  
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR  
		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP  
			ON YWCP.DDBH = DDZL.DDBH  
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, xxzl.jijie
		ORDER BY DDZL.KHPO;

	`, "'F%'", getPoTypeQuery(DDBH, "DDZL.DDBH"))

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        request.Date,
		"gsbh":        GSBH,
	}
	// 查詢 DailyPoStatus 資料
	var poStatusData []types.DailyPoStatus
	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
	if err != nil {
		return nil, nil, err
	}

	rawData := []types.DailyPoStatus{}

	// Cache size list from Decker
	deckerSizeList := make(map[string]string)

	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
	for i := range poStatusData {
		value := &poStatusData[i]
		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		sizeMapKey := value.StyleNumber + "-" + value.ColorCode

		// 獲取 Milestone 資料
		milestoneListData, err := GetMilestoneData(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH, request.Date)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
		}

		rawMilestone := []types.Milestone{}

		// 如果有 Milestone 資料，才填充到 MilestoneList
		if len(milestoneListData) > 0 {
			milestoneMap := make(map[string]*types.Milestone)
			for _, ml := range milestoneListData {
				// 根據 StageCode 轉換
				switch ml.StageCode {
				case "C":
					ml.StageCode = "WIP3-1"
				case "O":
					ml.StageCode = "WIP3-3"
				case "S":
					ml.StageCode = "WIP6"
				case "A":
					ml.StageCode = "WIP8"
				}

				rawMilestone = append(rawMilestone, ml)

				if milestone, exists := milestoneMap[ml.StageCode]; exists {
					milestone.CompletionQuantity += ml.CompletionQuantity
					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
				} else {
					milestoneMap[ml.StageCode] = &types.Milestone{
						StageCode:          ml.StageCode,
						CompletionQuantity: ml.CompletionQuantity,
						SizeList:           ml.SizeList,
					}
				}
			}

			// Export raw data
			var rawPo = *value
			rawPo.MilestoneList = rawMilestone
			rawData = append(rawData, rawPo)

			var newMilestoneListData []types.Milestone
			for _, milestone := range milestoneMap {
				newMilestoneListData = append(newMilestoneListData, *milestone)
			}

			// Milestone handling code
			newMilestoneListData = fillMissingStages(newMilestoneListData)
			sortMilestones(newMilestoneListData)
			AdjustQtyByStage(newMilestoneListData)
			newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
			newMilestoneListData = fillEmptyStage(newMilestoneListData)
			value.MilestoneList = newMilestoneListData
		}

		err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(request.DatabaseType), deckerSizeList)
		if err != nil {
			return nil, nil, fmt.Errorf("error when get size list from deckers")
		}

		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
		for _, milestone := range value.MilestoneList {

			// Get last size string from size map and check if exist
			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

				// Change all size number: add last size string to the end
				for index := range milestone.SizeList {

					size := &milestone.SizeList[index]

					// Ignore empty size number
					if len(size.SizeNumber) > 0 {

						// Get last character in size number
						lastCharIndex := len(size.SizeNumber) - 1
						checkingChar := size.SizeNumber[lastCharIndex]

						// Check if it was added or not
						if !unicode.IsLetter(rune(checkingChar)) {

							// Add to the end
							size.SizeNumber += lastSizeStr
						}
					}
					size.SizeNumber = strings.TrimSpace(size.SizeNumber)
				}
			}

			// Add PO completion Qty = WIP8's Qty
			if milestone.StageCode == "WIP8" {
				value.PoCompletionQuantity = milestone.CompletionQuantity
			}
		}

		if value.PoCompletionQuantity == value.PoQuantity {
			value.Status = "001"
		}
	}

	result := mergeDuplicatePOs(poStatusData)

	return result, rawData, nil
}

// FG Stage value = 0 for all PO
func (s *poStatusService) GetDailyPoStatusByDDBHList(databaseType, date string, ddbhList []string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, err
	}

	poListSQL := BuildPoListSQL(ddbhList)

	sqlTemplate := `
		SELECT
			CONVERT(VARCHAR(10), @date, 23) AS date,
			DDZL.KHPO AS poNumber,
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			'002' AS status,  
			'Normal' AS statusMessage,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			CASE 
				WHEN DDZL.BUYNO LIKE '%s' THEN SUBSTRING(DDZL.BUYNO, 1, 3)
				ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
			END AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
				WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,
			YWCP.Qty AS poCompletionQuantity,
			DDZL.Pairs AS poQuantity,
			'1d' AS logType,
			kfzl.kfjc AS brand,
			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
			'stageCode' AS stageCode,
			0 AS completionQuantity,
			'sizeNumber' AS sizeNumber,
			0 AS sizeCompletionQuantity,
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS DDBH
		FROM DDZL
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP
			ON YWCP.DDBH = DDZL.DDBH
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		WHERE DDZL.DDBH IN (%s)
		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO;
	`

	sqlQuery := fmt.Sprintf(sqlTemplate,
		getPoTypeQuery(DDBH, "DDZL.DDBH"),
		"%PR%",
		poListSQL,
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
	}

	// 查詢 DailyPoStatus 資料
	var poData []types.DailyPoStatus
	err = db.Raw(sqlQuery, queryParams).Scan(&poData).Error
	if err != nil {
		return nil, nil, err
	}

	// Cache size list from Decker
	deckerSizeList := make(map[string]string)

	rawData := []types.DailyPoStatus{}

	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
	for i := range poData {
		value := &poData[i]
		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		sizeMapKey := value.StyleNumber + "-" + value.ColorCode

		println("Processing PO:", value.PoNumber)

		// 初始化 MilestoneList
		value.MilestoneList = []types.Milestone{}

		// 獲取 Milestone 資料
		milestoneListData, err := GetMilestoneDataWithOldFG(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH, date)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
		}

		var rawPo = *value
		rawPo.MilestoneList = milestoneListData
		rawData = append(rawData, rawPo)

		// 如果有 Milestone 資料，才填充到 MilestoneList
		if len(milestoneListData) > 0 {
			milestoneMap := make(map[string]*types.Milestone)
			for _, ml := range milestoneListData {
				// 根據 StageCode 轉換
				switch ml.StageCode {
				case "C":
					ml.StageCode = "WIP3-1"
				case "O":
					ml.StageCode = "WIP3-3"
				case "S":
					ml.StageCode = "WIP6"
				case "A":
					ml.StageCode = "WIP8"
				}

				if milestone, exists := milestoneMap[ml.StageCode]; exists {
					milestone.CompletionQuantity += ml.CompletionQuantity
					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
				} else {
					milestoneMap[ml.StageCode] = &types.Milestone{
						StageCode:          ml.StageCode,
						CompletionQuantity: ml.CompletionQuantity,
						SizeList:           ml.SizeList,
					}
				}
			}

			var newMilestoneListData []types.Milestone
			for _, milestone := range milestoneMap {
				newMilestoneListData = append(newMilestoneListData, *milestone)
			}

			newMilestoneListData = fillMissingStages(newMilestoneListData)
			sortMilestones(newMilestoneListData)
			AdjustQtyByStage(newMilestoneListData)
			newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
			newMilestoneListData = fillEmptyStage(newMilestoneListData)
			value.MilestoneList = newMilestoneListData
		}

		err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(databaseType), deckerSizeList)
		if err != nil {
			return nil, nil, fmt.Errorf("error when get size list from deckers")
		}

		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
		for _, milestone := range value.MilestoneList {

			// Get last size string from size map and check if exist
			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

				// Change all size number: add last size string to the end
				for index := range milestone.SizeList {

					size := &milestone.SizeList[index]

					// Ignore empty size number
					if len(size.SizeNumber) > 0 {

						// Get last character in size number
						lastCharIndex := len(size.SizeNumber) - 1
						checkingChar := size.SizeNumber[lastCharIndex]

						// Check if it was added or not
						if !unicode.IsLetter(rune(checkingChar)) {

							// Add to the end
							size.SizeNumber += lastSizeStr
						}
					}
				}
			}

			// Add PO completion Qty = FG10's Qty
			if milestone.StageCode == "FG10" {
				value.PoCompletionQuantity = milestone.CompletionQuantity
			}
		}

		if value.PoCompletionQuantity == value.PoQuantity {
			value.Status = "001"
		}
	}

	result := mergeDuplicatePOs(poData)
	// result := poData

	return result, rawData, nil
}

func (s *poStatusService) GetPoMissingShipID(databaseType string) ([]types.PoInfo, error) {
	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sqlQuery := fmt.Sprintf(`
	SELECT *
	FROM (
		SELECT
			DDZL.KHPO AS poNumber, 
			%s
			@factoryCode AS factoryCode,  
			@factoryName AS factoryName,  
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
			xxzl.XieMing AS styleName,  
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
			xxzl.jijie AS season,
			CASE 
				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN '' 
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
			END AS shipId,  
			DDZL.Pairs AS poQuantity,  
			kfzl.kfjc AS brand, 
			CONVERT(VARCHAR, DDZL.ShipDate, 23) AS confirmXFDate,
			'stageCode' AS stageCode,  
			0 AS completionQuantity,  
			'sizeNumber' AS sizeNumber,  
			0 AS sizeCompletionQuantity,  
			0 AS sizeTargetQuantity,
			DDZL.DDBH AS RY
		FROM DDZL  
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh  
		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH  
		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH  
		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR  
		LEFT JOIN (
			SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty 
			FROM YWCP 
			WHERE YWCP.SB = 1 
			GROUP BY YWCP.DDBH
		) YWCP ON YWCP.DDBH = DDZL.DDBH  
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
		WHERE 1=1
			AND DDZL.KHPO != ''
			AND DDZL.KHPO IS NOT NULL
			AND DDZL.DDZT = 'Y'
			AND (DDZL.DDBH LIKE %s)
			AND NOT (
				DDZL.DDBH LIKE '%s'
				OR RIGHT(DDZL.DDBH, 2) = 'BG'
				OR DDZL.DDBH LIKE '%s'
			)
			AND DDZL.ShipDate >= @date
			AND LTRIM(RTRIM(ISNULL(lbzls.zwsm, ''))) = ''
		GROUP BY 
			DDZL.DDBH, DDZL.KHPO, DDZL.Article, 
			YWCP.Qty, DDZL.Pairs, kfzl.kfjc, 
			DDZL.ShipDate, xxzl.XieMing, 
			lbzls.zwsm, xxzl.jijie
	) t
	WHERE t.poType = 'PO'
	ORDER BY t.poNumber;
`, getPoTypeQuery(DDBH, "DDZL.DDBH"), getDDBHQueryTypePO(DDBH, "DDZL.DDBH"), "%-B%", "DHB%")

	// Only get POs with empty ShipID in the past 6 months
	date := time.Now().AddDate(0, -6, 0).Format("2006-01-02")

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"gsbh":        GSBH,
		"date":        date,
	}

	var poStatusData []types.PoInfo
	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
	if err != nil {
		return nil, err
	}

	return poStatusData, nil
}

// func (s *poStatusService) GetDailyPoStatus(databaseType, date string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {

// 	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	sqlQuery := fmt.Sprintf(`
// 		DECLARE @start DATETIME = DATEADD(HOUR, -2, CAST(@date AS DATETIME));
// 		DECLARE @end   DATETIME = DATEADD(HOUR, 22, CAST(@date AS DATETIME));

// 		WITH ListKHPO AS (
// 			-- Nguồn 1: Bảng YWCP với ngày xuất hoặc ngày nhập hôm nay
// 			SELECT DISTINCT DDZL.KHPO
// 			FROM YWCP
// 			INNER JOIN DDZL
// 				ON DDZL.DDBH = YWCP.DDBH
// 			WHERE (
// 				YWCP.EXEDATE >= @start AND YWCP.EXEDATE < @end OR
// 				YWCP.INDATE   >= @start AND YWCP.INDATE   < @end OR
// 				YWCP.REDATE   >= @start AND YWCP.REDATE   < @end
// 			)
// 			AND DDZL.KHPO > ''

// 			UNION

// 			-- Nguồn 2: Bảng SMDDSS với ngày quét hôm nay
// 			SELECT DISTINCT KHPO
// 			FROM SMDD
// 				INNER JOIN SMDDSS on SMDDSS.DDBH = SMDD.DDBH and SMDD.GXLB = SMDDSS.GXLB
// 				INNER JOIN DDZL ON DDZL.DDBH = SMDD.YSBH
// 			WHERE CONVERT(DATE, ScanEDate) = CONVERT(DATE, @date)

// 			UNION

// 			-- Nguồn 3: Bảng KCRK + KCRKS với ngày xác nhận nhập kho hôm nay
// 			SELECT  distinct DDZL.KHPO
// 			FROM KCRK
// 			LEFT JOIN KCRKS ON KCRK.RKNO = KCRKS.RKNO
// 			INNER JOIN DDZL ON DDZL.DDBH = KCRKS.CGBH
// 			WHERE CONVERT(DATE, CFMDATE) = CONVERT(DATE, @date)
// 			AND KCRK.GSBH = @gsbh
// 			AND (KCRKS.CGBH LIKE %s)
// 		)
// 		SELECT
// 			CONVERT(VARCHAR(10), @date, 23) AS date,
// 			DDZL.KHPO AS poNumber,
// 			%s
// 			@factoryCode AS factoryCode,
// 			@factoryName AS factoryName,
// 			'002' AS status,
// 			'Normal' AS statusMessage,
// 			CASE
// 				WHEN CHARINDEX('-', DDZL.Article) > 0
// 				THEN SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1)
// 				ELSE DDZL.Article
// 			END AS styleNumber,
// 			xxzl.XieMing AS styleName,
// 			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
// 			xxzl.jijie AS season,
// 			CASE
// 				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' '
// 				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
// 			END AS shipId,
// 			YWCP.Qty AS poCompletionQuantity,
// 			DDZL.Pairs AS poQuantity,
// 			'1d' AS logType,
// 			kfzl.kfjc AS brand,
// 			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
// 			'stageCode' AS stageCode,
// 			0 AS completionQuantity,
// 			'sizeNumber' AS sizeNumber,
// 			0 AS sizeCompletionQuantity,
// 			0 AS sizeTargetQuantity,
// 			DDZL.DDBH AS DDBH
// 		FROM DDZL
// 		INNER JOIN ListKHPO ON ListKHPO.KHPO = DDZL.KHPO
// 		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
// 		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
// 		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
// 		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
// 		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP
// 			ON YWCP.DDBH = DDZL.DDBH
// 		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
// 		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
// 		WHERE 1=1
// 			AND NOT EXISTS (
// 				SELECT 1
// 				FROM po_daily_blacklist
// 				WHERE KHPO = DDZL.KHPO
// 			)
// 			AND DDZL.KHPO != ''
// 			AND DDZL.KHPO IS NOT NULL
// 			AND DDZL.DDZT = 'Y'
// 			AND (DDZL.DDBH LIKE %s)
// 			AND NOT (
// 				DDZL.DDBH LIKE '%s'
// 				OR RIGHT(DDZL.DDBH, 2) = 'BG'
// 				OR DDZL.DDBH LIKE '%s'
// 			)
// 		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, xxzl.jijie
// 		ORDER BY DDZL.KHPO;

// 	`, getDDBHQuery(DDBH, "KCRKS.CGBH"), getPoTypeQuery(DDBH, "DDZL.DDBH"), getDDBHQuery(DDBH, "DDZL.DDBH"), "%-B%", "DHB%")

// 	queryParams := map[string]interface{}{
// 		"factoryCode": factoryCode,
// 		"factoryName": factoryName,
// 		"date":        date,
// 		"gsbh":        GSBH,
// 	}
// 	// 查詢 DailyPoStatus 資料
// 	var poStatusData []types.DailyPoStatus

// 	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	rawData := []types.DailyPoStatus{}

// 	// Get XFDetailMap
// 	XFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	// Cache size list from Decker
// 	deckerSizeList := make(map[string]string)

// 	const batchSize = 100

// 	for start := 0; start < len(poStatusData); start += batchSize {

// 		end := start + batchSize
// 		if end > len(poStatusData) {
// 			end = len(poStatusData)
// 		}

// 		log.Printf("Processing PO batch: %d ~ %d\n", start, end)

// 		batch := poStatusData[start:end]

// 		for i := range batch {
// 			value := &batch[i]

// 			value.MilestoneList = []types.Milestone{}

// 			sizeMapKey := value.StyleNumber + "-" + value.ColorCode

// 			milestoneListData, err := GetMilestoneData(
// 				db,
// 				value.PoNumber,
// 				GSBH,
// 				value.StyleNumber+"-"+value.ColorCode,
// 				value.DDBH,
// 				date,
// 			)
// 			if err != nil {
// 				return nil, nil, fmt.Errorf(
// 					"failed to get milestone data for PoNumber %s: %v",
// 					value.PoNumber,
// 					err,
// 				)
// 			}
// 			rawMilestone := []types.Milestone{}

// 			// 如果有 Milestone 資料，才填充到 MilestoneList
// 			if len(milestoneListData) > 0 {
// 				milestoneMap := make(map[string]*types.Milestone)
// 				for _, ml := range milestoneListData {
// 					// 根據 StageCode 轉換
// 					switch ml.StageCode {
// 					case "C":
// 						ml.StageCode = "WIP3-1"
// 					case "O":
// 						ml.StageCode = "WIP3-3"
// 					case "S":
// 						ml.StageCode = "WIP6"
// 					case "A":
// 						ml.StageCode = "WIP8"
// 					}

// 					rawMilestone = append(rawMilestone, ml)

// 					if milestone, exists := milestoneMap[ml.StageCode]; exists {
// 						milestone.CompletionQuantity += ml.CompletionQuantity
// 						milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
// 					} else {
// 						milestoneMap[ml.StageCode] = &types.Milestone{
// 							StageCode:          ml.StageCode,
// 							CompletionQuantity: ml.CompletionQuantity,
// 							SizeList:           ml.SizeList,
// 						}
// 					}
// 				}

// 				// Export raw data
// 				var rawPo = *value
// 				rawPo.MilestoneList = rawMilestone
// 				rawData = append(rawData, rawPo)

// 				var newMilestoneListData []types.Milestone
// 				for _, milestone := range milestoneMap {
// 					newMilestoneListData = append(newMilestoneListData, *milestone)
// 				}

// 				// Milestone handling code
// 				newMilestoneListData = fillMissingStages(newMilestoneListData)
// 				sortMilestones(newMilestoneListData)
// 				AdjustQtyByStage(newMilestoneListData)
// 				newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
// 				newMilestoneListData = fillEmptyStage(newMilestoneListData)
// 				value.MilestoneList = newMilestoneListData
// 			}

// 			err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(databaseType), deckerSizeList)
// 			if err != nil {
// 				return nil, nil, fmt.Errorf("error when get size list from deckers: %v", err)
// 			}

// 			// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
// 			for _, milestone := range value.MilestoneList {

// 				// Get last size string from size map and check if exist
// 				if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 					// Change all size number: add last size string to the end
// 					for index := range milestone.SizeList {

// 						size := &milestone.SizeList[index]

// 						// Ignore empty size number
// 						if len(size.SizeNumber) > 0 {

// 							// Get last character in size number
// 							lastCharIndex := len(size.SizeNumber) - 1
// 							checkingChar := size.SizeNumber[lastCharIndex]

// 							// Check if it was added or not
// 							if !unicode.IsLetter(rune(checkingChar)) {

// 								// Add to the end
// 								size.SizeNumber += lastSizeStr
// 							}
// 						}
// 						size.SizeNumber = strings.TrimSpace(size.SizeNumber)
// 					}
// 				}

// 				// Add PO completion Qty = WIP8's Qty
// 				if milestone.StageCode == "WIP8" {
// 					value.PoCompletionQuantity = milestone.CompletionQuantity
// 				}
// 			}

// 			if value.PoCompletionQuantity == value.PoQuantity {
// 				value.Status = "001"
// 			}

// 			// XF Detail
// 			XFDetail, exist := XFDetailMap[value.DDBH]
// 			if exist {
// 				value.XFDetail = XFDetail
// 			} else {
// 				value.XFDetail = []types.XFDetail{}
// 			}
// 			for index, XFDetail := range value.XFDetail {

// 				// Get last size string from size map and check if exist
// 				if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 					sizeNumber := XFDetail.SizeNumber

// 					// Get last character in size number
// 					lastCharIndex := len(sizeNumber) - 1
// 					checkingChar := sizeNumber[lastCharIndex]

// 					// Check if it was added or not
// 					if !unicode.IsLetter(rune(checkingChar)) {

// 						// Add to the end
// 						sizeNumber += lastSizeStr
// 						value.XFDetail[index].SizeNumber = sizeNumber
// 					}
// 				}
// 			}
// 		}
// 	}
// 	result := mergeDuplicatePOs(poStatusData)

// 	TestPoStatus(result)

// 	return result, rawData, nil
// }

func (s *poStatusService) GetDailyPoStatus(databaseType, dateStr string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {
	// 1. 初始化資料庫與相關設定參數（為了給 getTodayChangedKHPO 使用）
	db, _, _, GSBH, DDBH_TypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, fmt.Errorf("setup database failed: %w", err)
	}

	// 2. 將字串日期轉換為 time.Time（getTodayChangedKHPO 需要 time 型態）
	start, err := time.Parse("2006-01-02", dateStr)
	if err != nil {
		return nil, nil, fmt.Errorf("invalid date format: %w", err)
	}

	// 保持優化後的 24 小時區間
	end := start.Add(22 * time.Hour)

	// 3. 步驟一：撈取今天有變動的所有 KHPO 清單
	poList, err := getChangedKHPO(db, start, GSBH, DDBH_TypeMap, start, end)
	if err != nil {
		return nil, nil, fmt.Errorf("get today changed KHPO failed: %w", err)
	}

	// 4. 防禦機制：如果今天完全沒有變動的 PO，直接回傳空結果，避免後續進去撈空資料
	if len(poList) == 0 {
		return []types.DailyPoStatus{}, []types.DailyPoStatus{}, nil
	}

	// 5. 步驟二：依據得到的 poList 查詢詳細狀態（符合 want 的三個參數）
	result1, rowData, err := s.GetDailyPoStatusByPOList(databaseType, dateStr, poList)
	if err != nil {
		return nil, nil, fmt.Errorf("get daily po status by PO list failed: %w", err)
	}

	return result1, rowData, nil
}

func (s *poStatusService) GetNightExportPo(databaseType, dateStr string) ([]types.DailyPoStatus, []types.DailyPoStatus, error) {
	// 1. 初始化資料庫與相關設定參數（為了給 getTodayChangedKHPO 使用）
	db, _, _, GSBH, DDBH_TypeMap, err := setupDatabase(databaseType)
	if err != nil {
		return nil, nil, fmt.Errorf("setup database failed: %w", err)
	}

	// 2. 將字串日期轉換為 time.Time（getTodayChangedKHPO 需要 time 型態）
	parsedDate, err := time.Parse("2006-01-02", dateStr)
	if err != nil {
		return nil, nil, fmt.Errorf("invalid date format: %w", err)
	}

	start := parsedDate.Add(22 * time.Hour)
	end := start.Add(2 * time.Hour)

	// 3. 步驟一：撈取今天有變動的所有 KHPO 清單
	poList, err := getChangedKHPO(db, parsedDate, GSBH, DDBH_TypeMap, start, end)
	if err != nil {
		return nil, nil, fmt.Errorf("get today changed KHPO failed: %w", err)
	}

	// 4. 防禦機制：如果今天完全沒有變動的 PO，直接回傳空結果，避免後續進去撈空資料
	if len(poList) == 0 {
		return []types.DailyPoStatus{}, []types.DailyPoStatus{}, nil
	}

	// 5. 步驟二：依據得到的 poList 查詢詳細狀態（符合 want 的三個參數）
	result, rowData, err := s.GetDailyPoStatusByPOList(databaseType, dateStr, poList)
	if err != nil {
		return nil, nil, fmt.Errorf("get daily po status by PO list failed: %w", err)
	}

	return result, rowData, nil
}

func buildMilestones(milestoneListData []types.Milestone) ([]types.Milestone, []types.Milestone) {
	milestoneMap := make(map[string]*types.Milestone)
	rawMilestone := []types.Milestone{}

	for _, ml := range milestoneListData {

		switch ml.StageCode {
		case "C":
			ml.StageCode = "WIP3-1"
		case "O":
			ml.StageCode = "WIP3-3"
		case "S":
			ml.StageCode = "WIP6"
		case "A":
			ml.StageCode = "WIP8"
		}

		rawMilestone = append(rawMilestone, ml)

		if m, ok := milestoneMap[ml.StageCode]; ok {
			m.CompletionQuantity += ml.CompletionQuantity
			m.SizeList = append(m.SizeList, ml.SizeList...)
		} else {
			milestoneMap[ml.StageCode] = &types.Milestone{
				StageCode:          ml.StageCode,
				CompletionQuantity: ml.CompletionQuantity,
				SizeList:           ml.SizeList,
			}
		}
	}

	var result []types.Milestone
	for _, v := range milestoneMap {
		result = append(result, *v)
	}

	return result, rawMilestone
}

func GetMilestoneDataWithOldFG(db *gorm.DB, khpo, GSBH, article, DDBH, DATE string) ([]types.Milestone, error) {

	params := StageQueryParam{
		KHPO:    khpo,
		ARTICLE: article,
		DDBH:    DDBH,
		GSBH:    GSBH,
		DATE:    DATE,
	}

	rows, err := queryAllStagesWithOldFG(db, params)
	if err != nil {
		return nil, err
	}

	var milestones []types.Milestone
	for _, row := range rows {
		// 解構 StageResult 成變數
		stageCode := row.StageCode
		sizeNumber := row.SizeNumber
		sizeCompletionQuantity := row.SizeCompletionQuantity
		sizeTargetQuantity := row.SizeTargetQuantity
		dailyOutput := row.DailyOutput

		// 保護數據不超過目標
		if sizeCompletionQuantity > sizeTargetQuantity {
			sizeCompletionQuantity = sizeTargetQuantity
		}

		found := false
		for i := range milestones {
			if milestones[i].StageCode == stageCode {
				milestones[i].SizeList = append(milestones[i].SizeList, types.Size{
					SizeNumber:             strings.TrimSpace(sizeNumber),
					SizeCompletionQuantity: sizeCompletionQuantity,
					SizeTargetQuantity:     sizeTargetQuantity,
					DailyOutput:            dailyOutput,
				})
				milestones[i].CompletionQuantity += sizeCompletionQuantity
				found = true
				break
			}
		}

		if !found {
			milestones = append(milestones, types.Milestone{
				StageCode:          stageCode,
				CompletionQuantity: sizeCompletionQuantity,
				SizeList: []types.Size{
					{
						SizeNumber:             strings.TrimSpace(sizeNumber),
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				},
			})
		}
	}

	return milestones, nil
}

func GetPreloadMilestoneData(db *gorm.DB, khpo, GSBH, article, DDBH, date string) ([]types.Milestone, error) {

	params := StageQueryParam{
		KHPO:    khpo,
		ARTICLE: article,
		DDBH:    DDBH,
		GSBH:    GSBH,
		DATE:    date,
	}

	rows, err := queryAllStagesPreload(db, params)
	if err != nil {
		return nil, err
	}

	var milestones []types.Milestone

	for _, row := range rows {

		stageCode := row.StageCode
		sizeNumber := strings.TrimSpace(row.SizeNumber)

		sizeCompletionQuantity := row.SizeCompletionQuantity
		sizeTargetQuantity := row.SizeTargetQuantity
		dailyOutput := row.DailyOutput

		// 保護不超過目標
		if sizeCompletionQuantity > sizeTargetQuantity {
			sizeCompletionQuantity = sizeTargetQuantity
		}

		found := false

		for i := range milestones {
			if milestones[i].StageCode == stageCode {

				milestones[i].SizeList = append(
					milestones[i].SizeList,
					types.Size{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				)

				milestones[i].CompletionQuantity += sizeCompletionQuantity

				found = true
				break
			}
		}

		if !found {
			milestones = append(milestones, types.Milestone{
				StageCode:          stageCode,
				CompletionQuantity: sizeCompletionQuantity,
				SizeList: []types.Size{
					{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				},
			})
		}
	}

	return milestones, nil
}

func GetMilestoneData(db *gorm.DB, khpo, GSBH, article, DDBH, date string) ([]types.Milestone, error) {

	params := StageQueryParam{
		KHPO:    khpo,
		ARTICLE: article,
		DDBH:    DDBH,
		GSBH:    GSBH,
		DATE:    date,
	}

	rows, err := queryAllStages(db, params)
	if err != nil {
		return nil, err
	}

	var milestones []types.Milestone

	for _, row := range rows {

		stageCode := row.StageCode
		sizeNumber := strings.TrimSpace(row.SizeNumber)

		sizeCompletionQuantity := row.SizeCompletionQuantity
		sizeTargetQuantity := row.SizeTargetQuantity
		dailyOutput := row.DailyOutput

		// 保護不超過目標
		if sizeCompletionQuantity > sizeTargetQuantity {
			sizeCompletionQuantity = sizeTargetQuantity
		}

		found := false

		for i := range milestones {
			if milestones[i].StageCode == stageCode {

				milestones[i].SizeList = append(
					milestones[i].SizeList,
					types.Size{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				)

				milestones[i].CompletionQuantity += sizeCompletionQuantity

				found = true
				break
			}
		}

		if !found {
			milestones = append(milestones, types.Milestone{
				StageCode:          stageCode,
				CompletionQuantity: sizeCompletionQuantity,
				SizeList: []types.Size{
					{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				},
			})
		}
	}

	return milestones, nil
}

func GetAllSpecialSplitPoMilestoneData(db *gorm.DB, khpo, GSBH, article, DDBH, date string) ([]types.Milestone, error) {

	params := StageQueryParam{
		KHPO:    khpo,
		ARTICLE: article,
		DDBH:    DDBH,
		GSBH:    GSBH,
		DATE:    date,
	}

	rows, err := queryAllStagesSpecial(db, params)
	if err != nil {
		return nil, err
	}

	var milestones []types.Milestone

	for _, row := range rows {

		stageCode := row.StageCode
		sizeNumber := strings.TrimSpace(row.SizeNumber)

		sizeCompletionQuantity := row.SizeCompletionQuantity
		sizeTargetQuantity := row.SizeTargetQuantity
		dailyOutput := row.DailyOutput

		// 保護不超過目標
		if sizeCompletionQuantity > sizeTargetQuantity {
			sizeCompletionQuantity = sizeTargetQuantity
		}

		found := false

		for i := range milestones {
			if milestones[i].StageCode == stageCode {

				milestones[i].SizeList = append(
					milestones[i].SizeList,
					types.Size{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				)

				milestones[i].CompletionQuantity += sizeCompletionQuantity

				found = true
				break
			}
		}

		if !found {
			milestones = append(milestones, types.Milestone{
				StageCode:          stageCode,
				CompletionQuantity: sizeCompletionQuantity,
				SizeList: []types.Size{
					{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				},
			})
		}
	}

	return milestones, nil
}

func GetFullFG10MilestoneData(db *gorm.DB, khpo, GSBH, article, DDBH, date string) ([]types.Milestone, error) {

	params := StageQueryParam{
		KHPO:    khpo,
		ARTICLE: article,
		DDBH:    DDBH,
		GSBH:    GSBH,
		DATE:    date,
	}

	rows, err := queryAllStagesFullFG10(db, params)
	if err != nil {
		return nil, err
	}

	var milestones []types.Milestone

	for _, row := range rows {

		stageCode := row.StageCode
		sizeNumber := strings.TrimSpace(row.SizeNumber)

		sizeCompletionQuantity := row.SizeCompletionQuantity
		sizeTargetQuantity := row.SizeTargetQuantity
		dailyOutput := row.DailyOutput

		// 保護不超過目標
		if sizeCompletionQuantity > sizeTargetQuantity {
			sizeCompletionQuantity = sizeTargetQuantity
		}

		found := false

		for i := range milestones {
			if milestones[i].StageCode == stageCode {

				milestones[i].SizeList = append(
					milestones[i].SizeList,
					types.Size{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				)

				milestones[i].CompletionQuantity += sizeCompletionQuantity

				found = true
				break
			}
		}

		if !found {
			milestones = append(milestones, types.Milestone{
				StageCode:          stageCode,
				CompletionQuantity: sizeCompletionQuantity,
				SizeList: []types.Size{
					{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
						DailyOutput:            dailyOutput,
					},
				},
			})
		}
	}

	return milestones, nil
}

func GetXFDetailMap(db *gorm.DB, poStatusData []types.DailyPoStatus, date string, databaseType string) (map[string][]types.XFDetail, error) {

	// DB query
	XFQueryResult, err := queryXFDetail(db, poStatusData, date, databaseType)
	if err != nil {
		return nil, err
	}
	XFDetailMap := map[string][]types.XFDetail{}

	for _, XFRow := range XFQueryResult {
		// 修正點 1：在迴圈內部重新宣告同名局部變數，切斷記憶體位址共用的危機
		XFRow := XFRow

		// Each DDBH/RYNO will have a list of XFDetail
		XFDetailList, exist := XFDetailMap[XFRow.RYNO]

		// Init new SizeDetail
		XFSizeDetail := types.XFSizeDetail{
			XFTime:          XFRow.GetXFTime(),
			XFQuantity:      XFRow.Quantity,
			TruckNumber:     XFRow.TruckNumber,
			ContainerNumber: XFRow.ContainerNumber,
		}

		// Init new XFDetail
		XFDetail := types.XFDetail{
			SizeNumber:      XFRow.SizeNumber,
			TotalXFQuantity: XFRow.Quantity,
			Detail:          []types.XFSizeDetail{XFSizeDetail},
		}

		if exist {
			// 修正點 2：此時的 &XFRow.SizeNumber 指向的就是上面獨立的局部記憶體，絕對安全
			if index := containXFSizeNumber(XFDetailList, &XFRow.SizeNumber); index >= 0 {
				XFSizeDetailList := XFDetailList[index].Detail
				XFSizeDetailList = append(XFSizeDetailList, XFSizeDetail)

				// Append new SizeDetail to SizeDetailList
				XFDetailList[index].Detail = XFSizeDetailList

				// Recalculate TotalXFQuantity
				XFDetailList[index].TotalXFQuantity += XFSizeDetail.XFQuantity
			} else {
				XFDetailList = append(XFDetailList, XFDetail)
			}
			// Append to result map
			XFDetailMap[XFRow.RYNO] = XFDetailList
		} else {
			XFDetailList := []types.XFDetail{XFDetail}
			// Append to result map
			XFDetailMap[XFRow.RYNO] = XFDetailList
		}
	}
	return XFDetailMap, nil
}

// Check if size number is exist in list or not
// Return index if exist | return -1 if not
func containXFSizeNumber(XFDetailList []types.XFDetail, sizeNumber *string) int {
	for index, XFDetail := range XFDetailList {
		if XFDetail.SizeNumber == *sizeNumber {
			return index
		}
	}
	return -1
}

func GetMilestoneDataCancelPo(db *gorm.DB, khpo, GSBH, article, DDBH, date string) ([]types.Milestone, error) {

	params := StageQueryParam{
		KHPO:    khpo,
		ARTICLE: article,
		DDBH:    DDBH,
		GSBH:    GSBH,
		DATE:    date,
	}

	rows, err := queryStagesCancelPo(db, params)
	if err != nil {
		return nil, err
	}

	var milestones []types.Milestone
	for _, row := range rows {
		// 解構 StageResult 成變數
		stageCode := row.StageCode
		sizeNumber := row.SizeNumber
		sizeCompletionQuantity := row.SizeCompletionQuantity
		sizeTargetQuantity := row.SizeTargetQuantity

		// 保護數據不超過目標
		if sizeCompletionQuantity > sizeTargetQuantity {
			sizeCompletionQuantity = sizeTargetQuantity
		}

		found := false
		for i := range milestones {
			if milestones[i].StageCode == stageCode {
				milestones[i].SizeList = append(milestones[i].SizeList, types.Size{
					SizeNumber:             strings.TrimSpace(sizeNumber),
					SizeCompletionQuantity: sizeCompletionQuantity,
					SizeTargetQuantity:     sizeTargetQuantity,
				})
				milestones[i].CompletionQuantity += sizeCompletionQuantity
				found = true
				break
			}
		}

		if !found {
			milestones = append(milestones, types.Milestone{
				StageCode:          stageCode,
				CompletionQuantity: sizeCompletionQuantity,
				SizeList: []types.Size{
					{
						SizeNumber:             strings.TrimSpace(sizeNumber),
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
					},
				},
			})
		}
	}

	return milestones, nil
}

func ExtractUniqueDDBH(rawData []types.DailyPoStatus) []string {
	uniqueMap := make(map[string]struct{})
	result := make([]string, 0)

	for _, item := range rawData {
		ddbh := item.DDBH
		if ddbh == "" {
			continue
		}

		if _, exists := uniqueMap[ddbh]; exists == false {
			uniqueMap[ddbh] = struct{}{}
			result = append(result, ddbh)
		}
	}

	return result
}

func queryXFDetail(db *gorm.DB, poStatusData []types.DailyPoStatus, date string, databaseType string) ([]types.XFDetailQuery, error) {

	truckTable := ""
	switch databaseType {
	case "A":
		truckTable = "[ALPR_DB].[dbo].[ALPR_Records]"
	case "B":
		truckTable = "[ALPR_DB_CONT].[ALPR_DB].[dbo].[ALPR_Records]"
	case "C":
		return []types.XFDetailQuery{}, nil
	}

	ddbhList := ExtractUniqueDDBH(poStatusData)
	if len(ddbhList) == 0 {
		return []types.XFDetailQuery{}, nil
	}

	// 1. 改成只抽取「單一精準的目標 KHPO」
	targetKHPO := ""
	for _, entry := range poStatusData {
		if entry.PoNumber != "" {
			targetKHPO = entry.PoNumber
			break // 既然這批資料只有唯一值，拿到第一個非空的就可以直接收工了
		}
	}

	// 如果整批資料完全沒有 KHPO，可以直接返回空
	if targetKHPO == "" {
		return []types.XFDetailQuery{}, nil
	}

	poListSQL := BuildPoListSQL(ddbhList)

	query := `
    IF OBJECT_ID('tempdb..#Ex_Data') IS NOT NULL DROP TABLE #Ex_Data;
    IF OBJECT_ID('tempdb..#Ex_Size') IS NOT NULL DROP TABLE #Ex_Size;
    IF OBJECT_ID('tempdb..#DDZL_MATCH') IS NOT NULL DROP TABLE #DDZL_MATCH;
    IF OBJECT_ID('tempdb..#ORDER_MATCH') IS NOT NULL DROP TABLE #ORDER_MATCH;
    IF OBJECT_ID('tempdb..#FINAL_DATA') IS NOT NULL DROP TABLE #FINAL_DATA;

    /* STEP 1 */
    SELECT 
        r.outtime,
        r.Plate_Id,
        r.CON_NO,
        i.RYNO,
        i.SIZE_RUN,
        x.Barcode
    INTO #Ex_Data
    FROM ` + truckTable + ` r
    CROSS APPLY (
        SELECT 
            T.c.value('.', 'VARCHAR(100)') AS Barcode
        FROM (
            SELECT CAST(
                '<x>' + REPLACE(r.Packinglist_Barcode, ';', '</x><x>') + '</x>' 
                AS XML
            ) AS XmlData
        ) A
        CROSS APPLY XmlData.nodes('/x') T(c)
    ) x
    JOIN INVOICE_D i
        ON x.Barcode COLLATE DATABASE_DEFAULT = i.INV_NO COLLATE DATABASE_DEFAULT
    WHERE i.RYNO IN (%s);

    CREATE INDEX IX_Ex_Data_RYNO ON #Ex_Data(RYNO);
    CREATE INDEX IX_Ex_Data_CON_NO ON #Ex_Data(CON_NO);

    /* STEP 2 */
    SELECT
        e.outtime,
        e.Plate_Id,
        e.CON_NO,
        e.RYNO,
        e.SIZE_RUN,
        CASE 
            WHEN CHARINDEX('-', e.SIZE_RUN) > 0 
            THEN CAST(LEFT(e.SIZE_RUN, CHARINDEX('-', e.SIZE_RUN) - 1) AS FLOAT)
        END AS SIZE_START,
        CASE 
            WHEN CHARINDEX('-', e.SIZE_RUN) > 0 
            THEN CAST(SUBSTRING(
                e.SIZE_RUN,
                CHARINDEX('-', e.SIZE_RUN) + 1,
                LEN(e.SIZE_RUN)
            ) AS FLOAT)
        END AS SIZE_END
    INTO #Ex_Size
    FROM #Ex_Data e;

    CREATE INDEX IX_Ex_Size_RYNO ON #Ex_Size(RYNO);

    /* STEP 3 */
    SELECT
        e.outtime,
        e.Plate_Id,
        e.CON_NO,
        e.RYNO,
        d.CC
    INTO #DDZL_MATCH
    FROM #Ex_Size e
    JOIN ddzls d
        ON d.ddbh = e.RYNO
    AND d.CC >= e.SIZE_START
    AND d.CC <= e.SIZE_END;

    CREATE INDEX IX_DDZL_MATCH ON #DDZL_MATCH(RYNO, CC);

    /* STEP 4 */
    SELECT
        m.outtime,
        m.Plate_Id,
        m.CON_NO,
        m.RYNO,
        m.CC,
        o.XH,
        o.Qty,
        LTRIM(RTRIM(REPLACE(REPLACE(o.MEMO, CHAR(13), ''), CHAR(10), ''))) AS CleanMemo
    INTO #ORDER_MATCH
    FROM #DDZL_MATCH m
    JOIN YWBZPOS o
        ON o.DDBH = m.RYNO
        AND o.DDCC = m.CC
    /* 加入 YWCP 作為純過濾器，確保這箱確實屬於這個貨櫃 */
	JOIN YWCP y
		ON y.DDBH = o.DDBH
		AND y.XH = o.XH
		AND y.SB = 3
		AND REPLACE(y.BIEN_SO,'-','') COLLATE DATABASE_DEFAULT
			= m.Plate_Id COLLATE DATABASE_DEFAULT
		AND y.CON_NO COLLATE DATABASE_DEFAULT
			= m.CON_NO COLLATE DATABASE_DEFAULT
		AND CAST(y.EXEDATE AS DATE)
			= CAST(m.outtime AS DATE)
    WHERE 
        (ISNULL(o.MEMO, '') = '') 
        OR 
        (SUBSTRING(LTRIM(RTRIM(REPLACE(REPLACE(o.MEMO, CHAR(13), ''), CHAR(10), ''))), 1, 9) = '%s'); 

    CREATE INDEX IX_ORDER_MATCH ON #ORDER_MATCH(RYNO, CC, XH, CON_NO);

    /* STEP 5 */
    SELECT
        o.outtime,
        o.RYNO COLLATE DATABASE_DEFAULT AS RYNO,
        o.CON_NO COLLATE DATABASE_DEFAULT AS containerNumber,
        o.CC,
        o.Qty,
        o.CleanMemo COLLATE DATABASE_DEFAULT AS MEMO,
        -- 直接使用 ALPR 原始辨識結果，不再從 YWCP 抓車牌
        ISNULL(o.Plate_Id, 'UNKNOWN') COLLATE DATABASE_DEFAULT AS truckNumber
    INTO #FINAL_DATA
    FROM #ORDER_MATCH o;

    /* FINAL：最終輸出 */
    SELECT
        outtime AS XFTime,
        RYNO,
        containerNumber,
        CC AS sizeNumber,
        truckNumber,
        MEMO, 
        SUM(Qty) AS Quantity
    FROM #FINAL_DATA
    GROUP BY
        outtime,
        RYNO,
        containerNumber,
        CC,
        truckNumber,
        MEMO
    ORDER BY
        RYNO,
        CC;
    `

	// 這裡 fmt.Sprintf 帶入 poListSQL 與單一目標字串 targetKHPO
	sqlQuery := fmt.Sprintf(query, poListSQL, targetKHPO)

	var results []types.XFDetailQuery
	err := db.Raw(sqlQuery).Scan(&results).Error
	return results, err
}

func ExtractUniqueKHPO(poStatusData []types.DailyPoStatus) []string {
	keys := make(map[string]bool)
	var list []string
	for _, entry := range poStatusData {
		khpo := entry.PoNumber // 這裡依據你 Struct 裡面真正的欄位名調整
		if khpo != "" {
			if _, value := keys[khpo]; !value {
				keys[khpo] = true
				list = append(list, khpo)
			}
		}
	}
	return list
}
func queryAllStages(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	var allResults []StageResult

	rm, err := queryRMStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, rm...)

	wip, err := queryWIPStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, wip...)

	fg, err := queryFGStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, fg...)

	return allResults, nil
}

func queryAllStagesPreload(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	var allResults []StageResult

	rm, err := queryRMStagePreload(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, rm...)

	// wip, err := queryWIPStage(db, p)
	// if err != nil {
	// 	return nil, err
	// }
	// allResults = append(allResults, wip...)

	// fg, err := queryFGStage(db, p)
	// if err != nil {
	// 	return nil, err
	// }
	// allResults = append(allResults, fg...)

	return allResults, nil
}

func queryAllStagesSpecial(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	var allResults []StageResult

	rm, err := queryRMStageSpecial(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, rm...)

	wip, err := queryWIPStageSpecial(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, wip...)

	fg, err := queryFGStageSpecial(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, fg...)

	return allResults, nil
}

func queryAllStagesFullFG10(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	var allResults []StageResult

	rm, err := queryRMStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, rm...)

	wip, err := queryWIPStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, wip...)

	fg, err := queryFullFG10FGStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, fg...)

	return allResults, nil
}

func queryStagesCancelPo(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	var allResults []StageResult

	rm, err := queryCancelRMStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, rm...)

	return allResults, nil
}

func queryRMStage(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	var query string

	query = `
		DECLARE @orderCode VARCHAR(20) = @DDBH;

		;WITH Require AS (
			SELECT
				ZLBH,
				CLBH,
				SUM(clsl) AS clsl
			FROM cgzlss
			WHERE ZLBH = @orderCode
			GROUP BY ZLBH, CLBH
		),

		Preparation AS (
			SELECT
				CGBH,
				CLBH,
				SUM(qty) AS qty
			FROM kcrks
			WHERE CGBH = @orderCode
			GROUP BY CGBH, CLBH
		),

		PreparationStatus AS (
			SELECT
				@orderCode AS DDBH,
				CASE
					WHEN SUM(ISNULL(req.clsl, 0) - ISNULL(prep.qty, 0)) <= 0
						THEN 'finish'
					ELSE 'preparation'
				END AS OrderStatus
			FROM Require req
			FULL OUTER JOIN Preparation prep
				ON req.CLBH = prep.CLBH
		),

		StageResultCTE AS (
			SELECT
				0 AS completionQuantity,
				DDZLs.cc AS sizeNumber,
				CASE
					WHEN ps.OrderStatus = 'preparation'
						THEN 0
					ELSE SUM(DDZLs.Quantity)
				END AS sizeCompletionQuantity,
				SUM(DDZLs.Quantity) AS sizeTargetQuantity
			FROM ddzl
			LEFT JOIN ddzls
				ON ddzls.DDBH = ddzl.DDBH
			LEFT JOIN PreparationStatus ps
				ON ddzl.DDBH = ps.DDBH
			WHERE ddzl.DDBH = @orderCode
			GROUP BY
				DDZLs.cc,
				ddzl.KHPO,
				ddzl.ARTICLE,
				ps.OrderStatus
		)

		SELECT 'RM0-1' AS stageCode, *
		FROM StageResultCTE

		UNION ALL

		SELECT 'RM0-3' AS stageCode, *
		FROM StageResultCTE;
`
	var results []StageResult

	err := db.Raw(
		query,
		sql.Named("DDBH", p.DDBH),
	).Scan(&results).Error

	return results, err
}

func queryCancelRMStage(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	var query string

	if strings.HasPrefix(p.DDBH, "F") {

		query = `
		DECLARE @orderCode VARCHAR(20) = @DDBH;

		;WITH StageResultCTE AS (
			SELECT
				0 AS completionQuantity,
				DDZLs.cc AS sizeNumber,
				0 AS sizeCompletionQuantity,
				SUM(DDZLs.Quantity) AS sizeTargetQuantity
			FROM ddzl
			LEFT JOIN ddzls ON ddzls.DDBH = ddzl.DDBH
			WHERE ddzl.DDBH = @orderCode
			GROUP BY DDZLs.cc, ddzl.KHPO, ddzl.ARTICLE
		)

		SELECT 'RM0-1' AS stageCode, * 
		FROM StageResultCTE

		UNION ALL

		SELECT 'RM0-3' AS stageCode, * 
		FROM StageResultCTE;
		`

	} else {

		query = `
		DECLARE @orderCode VARCHAR(20) = @DDBH;

		WITH StageResultCTE AS (
			SELECT
				0 AS completionQuantity,
				DDZLs.cc AS sizeNumber,
				0 AS sizeCompletionQuantity,
				SUM(DDZLs.Quantity) AS sizeTargetQuantity
			FROM ddzl
			LEFT JOIN ddzls
				ON ddzls.DDBH = ddzl.DDBH
			WHERE ddzl.DDBH = @orderCode
			GROUP BY
				DDZLs.cc,
				ddzl.KHPO,
				ddzl.ARTICLE
		)

		SELECT 'RM0-1' AS stageCode, *
		FROM StageResultCTE

		UNION ALL

		SELECT 'RM0-3' AS stageCode, *
		FROM StageResultCTE;
		`
	}

	var results []StageResult

	err := db.Raw(
		query,
		sql.Named("DDBH", p.DDBH),
	).Scan(&results).Error

	return results, err
}

func queryRMStagePreload(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	query := `
        ;WITH StageResultCTE AS (
            SELECT
                0 AS completionQuantity,
                DDZLs.cc AS sizeNumber,
                0 AS sizeCompletionQuantity,
                SUM(DDZLs.Quantity) AS sizeTargetQuantity
            FROM ddzl
            LEFT JOIN ddzls ON ddzls.DDBH = ddzl.DDBH
            WHERE ddzl.DDBH = @DDBH
            GROUP BY DDZLs.cc, ddzl.KHPO, ddzl.ARTICLE
        )

        SELECT 'RM0-1' AS stageCode, * FROM StageResultCTE

        UNION ALL

        SELECT 'RM0-3' AS stageCode, * FROM StageResultCTE;
    `

	var results []StageResult
	// 使用參數化查詢，防止 SQL Injection
	err := db.Raw(query, sql.Named("DDBH", p.DDBH)).Scan(&results).Error

	return results, err
}

func queryRMStageSpecial(
	db *gorm.DB,
	p StageQueryParam,
) ([]StageResult, error) {

	query := `
	DECLARE @orderCode VARCHAR(20) = @DDBH;
	DECLARE @khpo VARCHAR(50) = @KHPO;

	WITH TargetSizeQty AS (
		SELECT 
			YWBZPOS.DDCC AS sizeNumber,
			SUM(YWBZPOS.Qty * YWBZPOS.CTS) AS targetQuantity
		FROM YWBZPOS
		WHERE YWBZPOS.DDBH = @orderCode
			AND (@khpo = '' OR YWBZPOS.MEMO LIKE @khpo + '%')
		GROUP BY YWBZPOS.DDCC
	),

	-- 備料需求
	Require AS (
		SELECT ZLBH, CLBH, SUM(clsl) AS clsl
		FROM cgzlss
		WHERE ZLBH = @orderCode
		GROUP BY ZLBH, CLBH
	),

	-- 入庫
	Preparation AS (
		SELECT CGBH, CLBH, SUM(qty) AS qty
		FROM kcrks
		WHERE CGBH = @orderCode
		GROUP BY CGBH, CLBH
	),

	-- 備料狀態
	PreparationStatus AS (
		SELECT
			@orderCode AS DDBH,
			CASE
				WHEN SUM(ISNULL(req.clsl, 0) - ISNULL(prep.qty, 0)) <= 0
					THEN 'finish'
				ELSE 'preparation'
			END AS OrderStatus
		FROM Require req
		FULL OUTER JOIN Preparation prep
			ON req.CLBH = prep.CLBH
	),

	-- Result（改用 TargetSizeQty）
	Result AS (
		SELECT
			0 AS completionQuantity,
			tq.sizeNumber,
			CASE
				WHEN ps.OrderStatus = 'preparation'
					THEN 0
				ELSE tq.targetQuantity
			END AS sizeCompletionQuantity,
			tq.targetQuantity AS sizeTargetQuantity
		FROM TargetSizeQty tq
		LEFT JOIN PreparationStatus ps
			ON 1 = 1
	)

	SELECT 'RM0-1' AS stageCode, * FROM Result
	UNION ALL
	SELECT 'RM0-3' AS stageCode, * FROM Result;
	`

	var results []StageResult

	err := db.Raw(query,
		sql.Named("DDBH", p.DDBH),
		sql.Named("KHPO", p.KHPO),
	).Scan(&results).Error

	return results, err
}

func queryWIPStage(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {

	// 先判斷是否子單
	isSubOrder := false
	if len(p.DDBH) > 0 {
		lastChar := p.DDBH[len(p.DDBH)-1]
		if lastChar >= 'A' && lastChar <= 'Z' {
			isSubOrder = true
		}
	}

	var query string

	// =========================
	// 子單
	// =========================
	if isSubOrder {

		query = `
		-- Đưa các phép tính lặp lại ra biến tĩnh để Engine không phải tính lại ở mỗi dòng JOIN
		DECLARE @ParentDDBH VARCHAR(50) = LEFT(@DDBH, LEN(@DDBH)-1);
		DECLARE @FromDate DATE = CAST(@date AS DATE);
		DECLARE @ToDate DATE = DATEADD(DAY, 1, @FromDate);

		;WITH StageCodes AS (
			-- Dùng VALUES tạo bảng tĩnh nhanh hơn nhiều so với dùng UNION ALL nhiều lần
			SELECT stageCode FROM (VALUES ('C'), ('A'), ('O'), ('S')) AS t(stageCode)
		),

		-- 1. CHỐT CHẶN (PREDICATE PUSHDOWN)
		-- Tìm trước TẤT CẢ các mã CODEBAR thuộc về Order hiện tại (@DDBH) và Order cha (@ParentDDBH)
		CodebarMapping AS (
			SELECT 
				d.YSBH AS TargetDDBH,
				s.GXLB AS stageCode,
				s.XXCC AS sizeNumber,
				s.CODEBAR,
				s.Qty
			FROM SMDD d
			JOIN SMDDSS s ON d.DDBH = s.DDBH AND d.GXLB = s.GXLB
			WHERE d.YSBH IN (@DDBH, @ParentDDBH)
		),

		-- 2. GỘP QUÉT BẢNG (SCAN ONCE)
		-- Thay vì quét SMZL/SMZLOld 2 lần ở 2 CTE khác nhau, ta chỉ quét 1 lần duy nhất 
		-- cho những CODEBAR đã được lọc ở trên.
		AllScans AS (
			SELECT smno, CODEBAR, CTS FROM SMZL 
			WHERE EXISTS (SELECT 1 FROM CodebarMapping cm WHERE cm.CODEBAR = SMZL.CODEBAR)
			UNION ALL -- Dùng UNION ALL (nhanh) thay vì UNION (chậm do phải distinct)
			SELECT smno, CODEBAR, CTS FROM SMZLOld 
			WHERE EXISTS (SELECT 1 FROM CodebarMapping cm WHERE cm.CODEBAR = SMZLOld.CODEBAR)
		),

		-- Xử lý mô phỏng lại lệnh UNION gốc của bạn (loại bỏ trùng lặp nếu có ở cả bảng mới/cũ)
		-- Việc Group By trên tập dữ liệu đã bị lọc nhỏ ở AllScans nhanh hơn gấp ngàn lần so với UNION cả bảng lớn.
		DistinctScans AS (
			SELECT smno, CODEBAR, CTS 
			FROM AllScans 
			GROUP BY smno, CODEBAR, CTS
		),

		-- 3. TÍNH TỔNG HOÀN THÀNH CHUNG (Cho cả Parent và Current)
		AggregatedScans AS (
			SELECT 
				cm.TargetDDBH,
				cm.stageCode,
				cm.sizeNumber,
				SUM(sl.CTS * cm.Qty) AS totalCompletedQty
			FROM CodebarMapping cm
			JOIN DistinctScans sl ON cm.CODEBAR = sl.CODEBAR
			GROUP BY cm.TargetDDBH, cm.stageCode, cm.sizeNumber
		),

		-- 4. TÁCH LOGIC CHECK PARENT (Chỉ lấy của @ParentDDBH)
		ParentCompletionCheck AS (
			SELECT 
				ac.stageCode,
				ac.sizeNumber,
				CASE WHEN ac.totalCompletedQty >= d.Quantity THEN 1 ELSE 0 END AS isComplete
			FROM AggregatedScans ac
			JOIN ddzls d ON d.DDBH = ac.TargetDDBH AND d.CC = ac.sizeNumber
			JOIN DDZL z ON z.DDBH = ac.TargetDDBH AND z.DDZT = 'S' -- Lọc trạng thái 'S' của Parent như query gốc
			WHERE ac.TargetDDBH = @ParentDDBH
		),

		-- 5. DAILY OUTPUT (Chỉ chọc vào SMZL cho @DDBH hiện tại)
		DailyStageOutput AS (
			SELECT 
				cm.stageCode,
				cm.sizeNumber,
				SUM(sl.CTS * cm.Qty) AS dailyOutputQty
			FROM CodebarMapping cm
			JOIN SMZL sl ON cm.CODEBAR = sl.CODEBAR
			WHERE cm.TargetDDBH = @DDBH
			AND sl.ScanDate >= @FromDate 
			AND sl.ScanDate < @ToDate
			GROUP BY cm.stageCode, cm.sizeNumber
		)

		-- MAIN QUERY
		SELECT 
			SC.stageCode,
			0 AS completionQuantity,
			COALESCE(DSO.dailyOutputQty, 0) AS dailyOutput,
			D.CC AS sizeNumber,
			CASE 
				WHEN PCC.isComplete = 1 THEN D.Quantity
				ELSE COALESCE(SCComp.totalCompletedQty, 0)
			END AS sizeCompletionQuantity,
			D.Quantity AS sizeTargetQuantity
		FROM ddzl Z
		JOIN ddzls D ON Z.DDBH = D.DDBH
		CROSS JOIN StageCodes SC

		-- Join lấy số lượng hoàn thành của Order hiện tại
		LEFT JOIN AggregatedScans SCComp
			ON SCComp.TargetDDBH = Z.DDBH 
		AND SCComp.stageCode = SC.stageCode
		AND SCComp.sizeNumber = D.CC

		-- Join lấy kết quả check của Parent Order
		LEFT JOIN ParentCompletionCheck PCC
			ON PCC.stageCode = SC.stageCode
		AND PCC.sizeNumber = D.CC

		-- Join lấy số lượng hàng ngày
		LEFT JOIN DailyStageOutput DSO
			ON DSO.stageCode = SC.stageCode
		AND DSO.sizeNumber = D.CC

		WHERE Z.DDBH = @DDBH
		ORDER BY SC.stageCode, D.CC;
		`

	} else {

		// =========================
		// 母單：
		// =========================
		query = `
		DECLARE @FromDate DATE = CAST(@date AS DATE);
        DECLARE @ToDate DATE = DATEADD(DAY, 1, @FromDate);

        ;WITH StageCodes AS (
            -- Dùng VALUES tạo bảng tĩnh nhanh hơn nhiều so với dùng UNION ALL nhiều lần
            SELECT stageCode FROM (VALUES ('C'), ('A'), ('O'), ('S')) AS t(stageCode)
        ),

        -- 1. CHỐT CHẶN (PREDICATE PUSHDOWN)
        -- Tìm trước TẤT CẢ các mã CODEBAR thuộc về Order hiện tại (@DDBH)
        CodebarMapping AS (
            SELECT 
                d.YSBH AS TargetDDBH,
                s.GXLB AS stageCode,
                s.XXCC AS sizeNumber,
                s.CODEBAR,
                s.Qty
            FROM SMDD d
            JOIN SMDDSS s ON d.DDBH = s.DDBH AND d.GXLB = s.GXLB
            WHERE d.YSBH = @DDBH -- Đã loại bỏ @ParentDDBH
        ),

        -- 2. GỘP QUÉT BẢNG (SCAN ONCE)
        -- Quét 1 lần duy nhất cho những CODEBAR đã được lọc ở trên
        AllScans AS (
            SELECT smno, CODEBAR, CTS FROM SMZL 
            WHERE EXISTS (SELECT 1 FROM CodebarMapping cm WHERE cm.CODEBAR = SMZL.CODEBAR)
            UNION ALL 
            SELECT smno, CODEBAR, CTS FROM SMZLOld 
            WHERE EXISTS (SELECT 1 FROM CodebarMapping cm WHERE cm.CODEBAR = SMZLOld.CODEBAR)
        ),

        -- Xử lý loại bỏ trùng lặp nếu có ở cả bảng mới/cũ
        DistinctScans AS (
            SELECT smno, CODEBAR, CTS 
            FROM AllScans 
            GROUP BY smno, CODEBAR, CTS
        ),

        -- 3. TÍNH TỔNG HOÀN THÀNH (Cho Order hiện tại)
        AggregatedScans AS (
            SELECT 
                cm.TargetDDBH,
                cm.stageCode,
                cm.sizeNumber,
                SUM(sl.CTS * cm.Qty) AS totalCompletedQty
            FROM CodebarMapping cm
            JOIN DistinctScans sl ON cm.CODEBAR = sl.CODEBAR
            GROUP BY cm.TargetDDBH, cm.stageCode, cm.sizeNumber
        ),

        -- 4. DAILY OUTPUT (Lấy sản lượng trong ngày từ bảng SMZL)
        DailyStageOutput AS (
            SELECT 
                cm.stageCode,
                cm.sizeNumber,
                SUM(sl.CTS * cm.Qty) AS dailyOutputQty
            FROM CodebarMapping cm
            JOIN SMZL sl ON cm.CODEBAR = sl.CODEBAR
            WHERE cm.TargetDDBH = @DDBH
            AND sl.ScanDate >= @FromDate 
            AND sl.ScanDate < @ToDate
            GROUP BY cm.stageCode, cm.sizeNumber
        )

        -- MAIN QUERY
        SELECT 
            SC.stageCode,
            0 AS completionQuantity,
            COALESCE(DSO.dailyOutputQty, 0) AS dailyOutput,
            D.CC AS sizeNumber,
            COALESCE(SCComp.totalCompletedQty, 0) AS sizeCompletionQuantity, -- Lấy trực tiếp, không check Parent nữa
            D.Quantity AS sizeTargetQuantity
        FROM ddzl Z
        JOIN ddzls D ON Z.DDBH = D.DDBH
        CROSS JOIN StageCodes SC

        -- Join lấy số lượng hoàn thành của Order hiện tại
        LEFT JOIN AggregatedScans SCComp
            ON SCComp.TargetDDBH = Z.DDBH 
           AND SCComp.stageCode = SC.stageCode
           AND SCComp.sizeNumber = D.CC

        -- Join lấy số lượng hàng ngày
        LEFT JOIN DailyStageOutput DSO
            ON DSO.stageCode = SC.stageCode
           AND DSO.sizeNumber = D.CC

        WHERE Z.DDBH = @DDBH
        ORDER BY SC.stageCode, D.CC;
		`
	}

	var results []StageResult
	err := db.Raw(query,
		sql.Named("DDBH", p.DDBH),
		sql.Named("date", p.DATE),
	).Scan(&results).Error

	return results, err
}

func queryWIPStageSpecial(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {

	query := `
		;WITH StageCodes AS (
			-- Dùng VALUES tạo bảng tĩnh nhanh hơn nhiều so với dùng UNION ALL nhiều lần
			SELECT stageCode FROM (VALUES ('C'), ('A'), ('O'), ('S')) AS t(stageCode)
		),

		TargetSizeQty AS (
			SELECT 
				YWBZPOS.DDCC AS sizeNumber,
				SUM(YWBZPOS.Qty * YWBZPOS.CTS) AS targetQuantity
			FROM YWBZPOS
			WHERE YWBZPOS.DDBH = @ddbh
				AND (@khpo = '' OR YWBZPOS.MEMO LIKE @khpo + '%')
			GROUP BY YWBZPOS.DDCC
		)

		-- MAIN QUERY
		SELECT 
			SC.stageCode,
			0 AS completionQuantity,
			0 AS dailyOutput,
			tg.sizeNumber AS sizeNumber,
			0 AS sizeCompletionQuantity, -- Lấy trực tiếp, không check Parent nữa
			tg.targetQuantity AS sizeTargetQuantity
		FROM TargetSizeQty tg
		CROSS JOIN StageCodes SC

		ORDER BY SC.stageCode, tg.sizeNumber;
		`

	var results []StageResult
	err := db.Raw(query,
		sql.Named("ddbh", p.DDBH),
		sql.Named("khpo", p.KHPO),
	).Scan(&results).Error

	return results, err
}

func queryFGStageSpecial(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {

	query := `

	DECLARE @orderNumber VARCHAR(20) = @DDBH;
	DECLARE @khpo VARCHAR(50) = @KHPO;

	WITH TargetSizeQty AS (

		SELECT 
			YWBZPOS.DDCC AS sizeNumber,
			SUM(YWBZPOS.Qty * YWBZPOS.CTS) AS targetQuantity
		FROM YWBZPOS
		WHERE YWBZPOS.DDBH = @orderNumber
			AND (
				YWBZPOS.MEMO LIKE @khpo + '%'
				OR YWBZPOS.MEMO IS NULL
				OR LTRIM(RTRIM(YWBZPOS.MEMO)) = ''
			)
		GROUP BY YWBZPOS.DDCC
	),

	-- =====================================================
	-- FG10
	-- =====================================================

	FG10Data AS (

		-- YWCP
		SELECT 
			YWBZPOS.DDCC AS sizeNumber,
			SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS

		INNER JOIN YWCP 
			ON YWBZPOS.DDBH = YWCP.DDBH 
			AND YWBZPOS.XH = YWCP.XH

		WHERE YWBZPOS.DDBH = @orderNumber
			AND (
				YWBZPOS.MEMO LIKE @khpo + '%'
				OR YWBZPOS.MEMO IS NULL
				OR LTRIM(RTRIM(YWBZPOS.MEMO)) = ''
			)
			AND YWCP.SB IN (1,2,3,4,5)

		GROUP BY YWBZPOS.DDCC

		UNION ALL

		-- YWCPOld
		SELECT 
			YWBZPOS.DDCC AS sizeNumber,
			SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS

		LEFT JOIN YWCPOld 
			ON YWBZPOS.DDBH = YWCPOld.DDBH 
			AND YWBZPOS.XH = YWCPOld.XH

		WHERE YWBZPOS.DDBH = @orderNumber
			AND (
				YWBZPOS.MEMO LIKE @khpo + '%'
				OR YWBZPOS.MEMO IS NULL
				OR LTRIM(RTRIM(YWBZPOS.MEMO)) = ''
			)
			AND YWCPOld.SB = 3

		GROUP BY YWBZPOS.DDCC
	),

	-- =====================================================
	-- FG14
	-- =====================================================

	FG14Data AS (

		-- YWCP
		SELECT 
			YWBZPOS.DDCC AS sizeNumber,
			SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS

		LEFT JOIN YWCP 
			ON YWBZPOS.DDBH = YWCP.DDBH 
			AND YWBZPOS.XH = YWCP.XH

		WHERE YWBZPOS.DDBH = @orderNumber
			AND (
				YWBZPOS.MEMO LIKE @khpo + '%'
				OR YWBZPOS.MEMO IS NULL
				OR LTRIM(RTRIM(YWBZPOS.MEMO)) = ''
			)
			AND YWCP.SB = 3
			AND CONVERT(date, YWCP.EXEDate) <= @date

		GROUP BY YWBZPOS.DDCC

		UNION ALL

		-- YWCPOld
		SELECT 
			YWBZPOS.DDCC AS sizeNumber,
			SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS

		LEFT JOIN YWCPOld 
			ON YWBZPOS.DDBH = YWCPOld.DDBH 
			AND YWBZPOS.XH = YWCPOld.XH

		WHERE YWBZPOS.DDBH = @orderNumber
			AND (
				YWBZPOS.MEMO LIKE @khpo + '%'
				OR YWBZPOS.MEMO IS NULL
				OR LTRIM(RTRIM(YWBZPOS.MEMO)) = ''
			)
			AND YWCPOld.SB = 3

		GROUP BY YWBZPOS.DDCC
	),

	-- =====================================================
	-- FG10 聚合
	-- =====================================================

	FG10Agg AS (

		SELECT 
			sizeNumber,
			SUM(qty) AS sizeCompletionQuantity
		FROM FG10Data
		GROUP BY sizeNumber
	),

	-- =====================================================
	-- FG14 聚合
	-- =====================================================

	FG14Agg AS (

		SELECT 
			sizeNumber,
			SUM(qty) AS sizeCompletionQuantity
		FROM FG14Data
		GROUP BY sizeNumber
	)

	-- =====================================================
	-- 最終輸出
	-- =====================================================

	SELECT 
		'FG10' AS stageCode,
		0 AS completionQuantity,
		tq.sizeNumber,
		ISNULL(a.sizeCompletionQuantity, 0) AS sizeCompletionQuantity,
		tq.targetQuantity AS sizeTargetQuantity
	FROM TargetSizeQty tq
	LEFT JOIN FG10Agg a 
		ON a.sizeNumber = tq.sizeNumber

	UNION ALL

	SELECT 
		'FG14' AS stageCode,
		0 AS completionQuantity,
		tq.sizeNumber,
		ISNULL(b.sizeCompletionQuantity, 0) AS sizeCompletionQuantity,
		tq.targetQuantity AS sizeTargetQuantity
	FROM TargetSizeQty tq
	LEFT JOIN FG14Agg b 
		ON b.sizeNumber = tq.sizeNumber;
	`

	var results []StageResult

	err := db.Raw(
		query,
		sql.Named("DDBH", p.DDBH),
		sql.Named("date", p.DATE),
		sql.Named("KHPO", p.KHPO),
	).Scan(&results).Error

	return results, err
}

func queryFullFG10FGStage(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	query := `
		WITH TargetSizeQty AS (
			SELECT 
				ddzls.CC AS sizeNumber, 
				SUM(ddzls.Quantity) AS targetQuantity
			FROM ddzls
			INNER JOIN ddzl 
				ON ddzls.DDBH = ddzl.DDBH
			WHERE ddzl.DDBH = @DDBH
			GROUP BY ddzls.CC
		),

		-- FG14 真實完成數
		FG14Data AS (
			SELECT 
				YWBZPOS.DDCC AS sizeNumber,
				SUM(YWBZPOS.Qty) AS qty
			FROM YWBZPOS

			LEFT JOIN ddzl 
				ON YWBZPOS.DDBH = ddzl.DDBH

			LEFT JOIN YWCP 
				ON YWBZPOS.DDBH = YWCP.DDBH 
			AND YWBZPOS.XH = YWCP.XH

			WHERE ddzl.DDBH = @DDBH
				AND YWCP.SB = 3

			GROUP BY YWBZPOS.DDCC
		)

		-- FG10（直接滿量）
		SELECT 
			'FG10' AS stageCode,
			0 AS completionQuantity,
			tq.sizeNumber,
			tq.targetQuantity AS sizeCompletionQuantity,
			tq.targetQuantity AS sizeTargetQuantity
		FROM TargetSizeQty tq

		UNION ALL

		-- FG14（真實數據）
		SELECT 
			'FG14' AS stageCode,
			0 AS completionQuantity,
			tq.sizeNumber,
			ISNULL(fg.qty, 0) AS sizeCompletionQuantity,
			tq.targetQuantity AS sizeTargetQuantity
		FROM TargetSizeQty tq
		LEFT JOIN FG14Data fg
			ON fg.sizeNumber = tq.sizeNumber

		ORDER BY stageCode, sizeNumber;
`
	var results []StageResult
	err := db.Raw(query,
		sql.Named("date", p.DATE),
		sql.Named("DDBH", p.DDBH),
	).Scan(&results).Error
	return results, err
}

func queryFGStage(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	query := `

	DECLARE @orderNumber VARCHAR(20) = @DDBH;

	WITH TargetSizeQty AS (
		SELECT ddzls.CC AS sizeNumber, SUM(ddzls.Quantity) AS targetQuantity
		FROM ddzls
		INNER JOIN ddzl ON ddzls.DDBH = ddzl.DDBH
		WHERE ddzl.DDBH = @orderNumber
		GROUP BY ddzls.CC
	),
	
	-- FG10 來源：YWCP (1,2,3,4,5) + YWCPOld (3)
	FG10Data AS (
		SELECT 
			YWBZPOS.DDCC AS sizeNumber,
			SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS
		LEFT JOIN ddzl 
			ON YWBZPOS.DDBH = ddzl.DDBH
		INNER JOIN YWCP 
			ON YWBZPOS.DDBH = YWCP.DDBH 
		AND YWBZPOS.XH = YWCP.XH
		WHERE ddzl.DDBH = @orderNumber
		AND YWCP.SB IN (1,2,3,4,5)
		GROUP BY YWBZPOS.DDCC
	
		UNION ALL
	
		SELECT YWBZPOS.DDCC AS sizeNumber, SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS
		LEFT JOIN YWCPOld ON YWBZPOS.DDBH = YWCPOld.DDBH AND YWBZPOS.XH = YWCPOld.XH
		LEFT JOIN ddzl ON YWBZPOS.DDBH = ddzl.DDBH
		WHERE ddzl.DDBH = @orderNumber
			AND YWCPOld.SB = 3
		GROUP BY YWBZPOS.DDCC
	),
	
	-- FG14 來源：YWCP (3) + YWCPOld (3)
	FG14Data AS (
		SELECT YWBZPOS.DDCC AS sizeNumber, SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS
		LEFT JOIN YWCP ON YWBZPOS.DDBH = YWCP.DDBH AND YWBZPOS.XH = YWCP.XH
		LEFT JOIN ddzl ON YWBZPOS.DDBH = ddzl.DDBH
		WHERE ddzl.DDBH = @orderNumber
			AND YWCP.SB = 3
		GROUP BY YWBZPOS.DDCC
	
		UNION ALL
	
		SELECT YWBZPOS.DDCC AS sizeNumber, SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS
		LEFT JOIN YWCPOld ON YWBZPOS.DDBH = YWCPOld.DDBH AND YWBZPOS.XH = YWCPOld.XH
		LEFT JOIN ddzl ON YWBZPOS.DDBH = ddzl.DDBH
		WHERE ddzl.DDBH = @orderNumber
			AND YWCPOld.SB = 3
		GROUP BY YWBZPOS.DDCC
	),
	
	-- 聚合每個 stage 資料（FG10 / FG14）
	FG10Agg AS (
		SELECT fd.sizeNumber, SUM(fd.qty) AS sizeCompletionQuantity
		FROM FG10Data fd
		GROUP BY fd.sizeNumber
	),
	FG14Agg AS (
		SELECT fd.sizeNumber, SUM(fd.qty) AS sizeCompletionQuantity
		FROM FG14Data fd
		GROUP BY fd.sizeNumber
	)
	
	-- 最終合併輸出（兩個 stage 各自一列）
	SELECT 
		'FG10' AS stageCode,
		0 AS completionQuantity,
		tq.sizeNumber,
		ISNULL(a.sizeCompletionQuantity, 0) AS sizeCompletionQuantity,
		tq.targetQuantity AS sizeTargetQuantity
	FROM TargetSizeQty tq
	LEFT JOIN FG10Agg a 
		ON a.sizeNumber = tq.sizeNumber
	
	UNION ALL
	
	SELECT 
		'FG14' AS stageCode,
		0 AS completionQuantity,
		tq.sizeNumber,
		ISNULL(b.sizeCompletionQuantity, 0) AS sizeCompletionQuantity,
		tq.targetQuantity AS sizeTargetQuantity
	FROM TargetSizeQty tq
	LEFT JOIN FG14Agg b 
		ON b.sizeNumber = tq.sizeNumber;
    `

	var results []StageResult
	err := db.Raw(query,
		sql.Named("DDBH", p.DDBH),
		sql.Named("date", p.DATE),
	).Scan(&results).Error
	return results, err
}

// SELECT
//         YWBZPOS.DDCC AS sizeNumber,
//         YWCP.SB,
//         YWCP.EXEDate,
//         YWCP.DDBH,
//         YWCP.XH,
//         YWBZPOS.Qty
//     FROM YWBZPOS
//     LEFT JOIN ddzl
//         ON YWBZPOS.DDBH = ddzl.DDBH
//     LEFT JOIN YWCP
//         ON YWBZPOS.DDBH = YWCP.DDBH
//        AND YWBZPOS.XH = YWCP.XH
//     WHERE ddzl.DDBH = @orderNumber and (YWCP.SB IN (1,2,3,4,5) OR (YWCP.SB IS NULL and YWCP.XH is NULL))

func BuildPoListSQL(poList []string) string {
	quoted := make([]string, len(poList))
	for i, po := range poList {
		quoted[i] = fmt.Sprintf("'%s'", po)
	}
	return strings.Join(quoted, ",")
}

func GetMilestoneListInitialData(db *gorm.DB, khpo, GSBH, article, DDBH string) ([]types.Milestone, error) {

	sqlQuery := `
		DECLARE @Result TABLE (
			stageCode NVARCHAR(10),
			completionQuantity INT,
			sizeNumber NVARCHAR(50),
			sizeCompletionQuantity INT,
			sizeTargetQuantity INT
		);

		WITH StageCodes AS (
			SELECT 'C' AS stageCode UNION ALL
			SELECT 'A' UNION ALL
			SELECT 'O' UNION ALL
			SELECT 'S'
		)
		INSERT INTO @Result
		SELECT
			SC.stageCode AS stageCode,
			0 AS completionQuantity,
			D.CC AS sizeNumber,
			ISNULL(SUM(S.OKCTS), 0) AS sizeCompletionQuantity,
			D.Quantity AS sizeTargetQuantity
		FROM ddzl Z
		CROSS JOIN StageCodes SC
		LEFT JOIN smdd M ON M.ysbh = Z.ddbh AND M.gxlb = SC.stageCode
		LEFT JOIN (
			SELECT DDBH, GXLB, SUM(QTY * OKCTS) AS OKCTS, XXCC
			FROM smddss
			GROUP BY DDBH, GXLB, XXCC
		) S ON S.ddbh = M.ddbh AND S.GXLB = SC.stageCode
		LEFT JOIN DDZLs D ON Z.DDBH = D.DDBH AND S.XXCC = D.CC
		WHERE Z.KHPO = @khpo
			AND Z.ARTICLE = @article
			AND Z.DDBH = @DDBH
		GROUP BY Z.ddbh, Z.KHPO, D.CC, SC.stageCode, D.Quantity;

		INSERT INTO @Result
		SELECT
			'RM0-3' AS stageCode,
			0 AS completionQuantity,
			DDZLs.cc AS sizeNumber,
			SUM(DDZLs.Quantity) AS sizeCompletionQuantity,
			SUM(DDZLs.Quantity) AS sizeTargetQuantity
		FROM ddzl
		LEFT JOIN ddzls ON ddzls.DDBH = ddzl.DDBH
		WHERE DDZL.KHPO = @khpo
			AND DDZL.ARTICLE = @article
			AND DDZL.DDBH = @DDBH
		GROUP BY DDZLs.cc, DDZL.KHPO, DDZL.ARTICLE;

		-- UNION ALL được thực hiện bên ngoài IF ... ELSE

		INSERT INTO @Result
		SELECT
			'FG10' AS stageCode,
			0 AS completionQuantity,
			sizeNumber,
			sizeCompletionQuantity,
			(SELECT SUM(Quantity)
				FROM ddzls
				LEFT JOIN ddzl ON ddzl.DDBH = ddzls.DDBH
				WHERE DDZL.KHPO = @khpo
				AND DDZL.ARTICLE = @article
				AND DDZL.DDBH = @DDBH
				AND cc = YWBZPOS.sizeNumber) AS sizeTargetQuantity
		FROM (
			SELECT YWBZPOS.DDCC AS sizeNumber,
				SUM(YWBZPOS.Qty) AS sizeCompletionQuantity
			FROM YWBZPOS
			LEFT JOIN YWCP ON YWCP.DDBH = YWBZPOS.DDBH
						AND YWCP.XH = YWBZPOS.XH
			LEFT JOIN DDZL ON YWBZPOS.DDBH = DDZL.DDBH
			LEFT JOIN DDZLs ON YWBZPOS.DDBH = DDZLs.DDBH
						AND YWBZPOS.DDCC = DDZLs.CC
			WHERE DDZL.GSBH = @GSBH
				AND SB = 1
				AND DDZL.KHPO = @khpo
				AND DDZL.ARTICLE = @article
				AND DDZL.DDBH = @DDBH
			GROUP BY YWBZPOS.DDCC
		) YWBZPOS;

		INSERT INTO @Result
		SELECT
			'FG14' AS stageCode,
			0 AS completionQuantity,
			sizeNumber,
			sizeCompletionQuantity,
			(SELECT SUM(Quantity)
				FROM ddzls
				LEFT JOIN ddzl ON ddzl.DDBH = ddzls.DDBH
				WHERE DDZL.KHPO = @khpo
				AND DDZL.ARTICLE = @article
				AND DDZL.DDBH = @DDBH
				AND cc = YWBZPOS.sizeNumber) AS sizeTargetQuantity
		FROM (
			SELECT YWBZPOS.DDCC AS sizeNumber,
				SUM(YWBZPOS.Qty) AS sizeCompletionQuantity
			FROM YWBZPOS
			LEFT JOIN YWCP ON YWCP.DDBH = YWBZPOS.DDBH
						AND YWCP.XH = YWBZPOS.XH
			LEFT JOIN DDZL ON YWBZPOS.DDBH = DDZL.DDBH
			LEFT JOIN DDZLs ON YWBZPOS.DDBH = DDZLs.DDBH
						AND YWBZPOS.DDCC = DDZLs.CC
			WHERE DDZL.GSBH = @GSBH
				AND SB = 3
				AND DDZL.KHPO = @khpo
				AND DDZL.ARTICLE = @article
				AND DDZL.DDBH = @DDBH
			GROUP BY YWBZPOS.DDCC
		) YWBZPOS;

		-- Xuất kết quả
		SELECT * FROM @Result ORDER BY sizeNumber;

	`

	rows, err := db.Raw(sqlQuery, sql.Named("khpo", khpo), sql.Named("GSBH", GSBH), sql.Named("article", article), sql.Named("DDBH", DDBH)).Rows()
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var milestones []types.Milestone
	for rows.Next() {
		var stageCode string
		var completionQuantity int // This will hold the sum for each milestone
		var sizeNumber string
		var sizeCompletionQuantity int
		var sizeTargetQuantity int

		if err := rows.Scan(&stageCode, &completionQuantity, &sizeNumber, &sizeCompletionQuantity, &sizeTargetQuantity); err != nil {
			log.Printf("Error scanning row: %v", err)
			continue
		}

		if sizeCompletionQuantity > sizeTargetQuantity {
			sizeCompletionQuantity = sizeTargetQuantity
		}

		found := false
		for i := range milestones {
			if milestones[i].StageCode == stageCode {

				// Add size details to the existing milestone
				milestones[i].SizeList = append(milestones[i].SizeList, types.Size{
					SizeNumber:             sizeNumber,
					SizeCompletionQuantity: sizeCompletionQuantity,
					SizeTargetQuantity:     sizeTargetQuantity,
				})

				// Update completionQuantity by summing up SizeCompletionQuantity
				milestones[i].CompletionQuantity += sizeCompletionQuantity
				found = true
				break
			}
		}

		if !found {
			// Create a new milestone and add the first size detail
			milestones = append(milestones, types.Milestone{
				StageCode:          stageCode,
				CompletionQuantity: sizeCompletionQuantity, // Initialize with the first size's completion quantity
				SizeList: []types.Size{
					{
						SizeNumber:             sizeNumber,
						SizeCompletionQuantity: sizeCompletionQuantity,
						SizeTargetQuantity:     sizeTargetQuantity,
					},
				},
			})
		}
	}

	// log.Printf("Milestone data: %v", milestones) // 打印查詢到的 Milestone 資料

	return milestones, nil
}
func (s *poStatusService) ExportPoReport(
	orders []types.DailyPoStatus,
) []types.POExcelReport {

	reports := make([]types.POExcelReport, 0, len(orders))

	for _, po := range orders {

		XFDetail, err := flattenXFDetail(po.XFDetail)
		if err != nil {
			log.Printf("failed to flattenXFDetail po %s: %v\n", po.PoNumber, err)
		}

		// -----------------------------
		// Init report
		// -----------------------------
		poReport := types.POExcelReport{
			Date:      po.Date,
			KHPO:      po.PoNumber,
			DDBH:      po.DDBH,
			StyleNo:   po.StyleNumber,
			ColorCode: po.ColorCode,
			ShipID:    po.ShipID,
			Qty:       po.PoQuantity,
			Status:    "Unstarted",

			RM01:  0,
			RM03:  0,
			WIP31: 0,
			WIP33: 0,
			WIP6:  0,
			WIP8:  0,
			FG10:  0,
			FG14:  0,

			WIP31Output: 0,
			WIP33Output: 0,
			WIP6Output:  0,
			WIP8Output:  0,
			XFDetail:    XFDetail,
		}

		// -----------------------------
		// Collect milestone data
		// -----------------------------
		for _, m := range po.MilestoneList {

			// 先加總 sizeList 的 dailyOutput
			stageDailyOutput := 0
			for _, s := range m.SizeList {
				stageDailyOutput += s.DailyOutput
			}

			// 累積「完成數量 + 當日產量」
			if m.CompletionQuantity > 0 {
				switch m.StageCode {

				case "RM0-1":
					poReport.RM01 += m.CompletionQuantity
					// RM 不算 WIP output（通常）

				case "RM0-3":
					poReport.RM03 += m.CompletionQuantity

				case "WIP3-1":
					poReport.WIP31 += m.CompletionQuantity
					poReport.WIP31Output += stageDailyOutput

				case "WIP3-3":
					poReport.WIP33 += m.CompletionQuantity
					poReport.WIP33Output += stageDailyOutput

				case "WIP6":
					poReport.WIP6 += m.CompletionQuantity
					poReport.WIP6Output += stageDailyOutput

				case "WIP8":
					poReport.WIP8 += m.CompletionQuantity
					poReport.WIP8Output += stageDailyOutput

				case "FG10":
					poReport.FG10 += m.CompletionQuantity
					// 通常 FG 不列入 WIP output

				case "FG14":
					poReport.FG14 += m.CompletionQuantity
				}
			}
		}
		// -----------------------------
		// Determine final status
		//    (business priority)
		// -----------------------------
		switch {
		case poReport.FG14 >= po.PoQuantity:
			poReport.Status = "Shipped"

		case poReport.FG10 >= po.PoQuantity:
			poReport.Status = "Finished"

		case poReport.WIP31 > 0 ||
			poReport.WIP33 > 0 ||
			poReport.WIP6 > 0 ||
			poReport.WIP8 > 0:
			poReport.Status = "In production"

		case poReport.RM01 > 0 || poReport.RM03 > 0:
			poReport.Status = "Material Preparation"

		default:
			poReport.Status = "Unstarted"
		}
		reports = append(reports, poReport)
	}

	return reports
}

// FlattenXFDetail chuyển đổi XFDetail thành danh sách XFDetailQuery
func flattenXFDetail(XFDetailList []types.XFDetail) ([]types.XFDetailQuery, error) {
	var queries []types.XFDetailQuery

	// Format ISO-8601 (tương đương với time.RFC3339) để parse chuỗi đầu vào
	timeLayout := "2006-01-02T15:04:05-07:00"

	for _, XFDetail := range XFDetailList {
		for _, d := range XFDetail.Detail {
			// Parse string thành time.Time
			parsedTime, err := time.Parse(timeLayout, d.XFTime)
			if err != nil {
				return nil, fmt.Errorf("không thể parse thời gian '%s': %v", d.XFTime, err)
			}

			// Tạo object XFDetailQuery và map dữ liệu tương ứng
			query := types.XFDetailQuery{
				XFTime:          parsedTime,
				SizeNumber:      XFDetail.SizeNumber,
				TruckNumber:     d.TruckNumber,
				ContainerNumber: d.ContainerNumber,
				Quantity:        d.XFQuantity,
			}

			queries = append(queries, query)
		}
	}

	return queries, nil
}

func (s *poStatusService) ExportCancelPoReport(
	orders []types.DailyPoStatus,
) []types.POExcelReport {

	reports := make([]types.POExcelReport, 0, len(orders))

	for _, po := range orders {

		// -----------------------------
		// Init report
		// -----------------------------
		poReport := types.POExcelReport{
			Date:      po.Date,
			KHPO:      po.PoNumber,
			DDBH:      po.DDBH,
			StyleNo:   po.StyleNumber,
			ColorCode: po.ColorCode,
			ShipID:    po.ShipID,
			Qty:       po.PoQuantity,
			Status:    "Unstarted",

			RM01:  0,
			RM03:  0,
			WIP31: 0,
			WIP33: 0,
			WIP6:  0,
			WIP8:  0,
			FG10:  0,
			FG14:  0,

			WIP31Output: 0,
			WIP33Output: 0,
			WIP6Output:  0,
			WIP8Output:  0,
		}

		// -----------------------------
		// Collect milestone data
		// -----------------------------
		for _, m := range po.MilestoneList {

			// 先加總 sizeList 的 dailyOutput
			stageDailyOutput := 0
			for _, s := range m.SizeList {
				stageDailyOutput += s.DailyOutput
			}

			// 累積「完成數量 + 當日產量」
			if m.CompletionQuantity > 0 {
				switch m.StageCode {

				case "RM0-1":
					poReport.RM01 += m.CompletionQuantity
					// RM 不算 WIP output（通常）

				case "RM0-3":
					poReport.RM03 += m.CompletionQuantity

				case "WIP3-1":
					poReport.WIP31 += m.CompletionQuantity
					poReport.WIP31Output += stageDailyOutput

				case "WIP3-3":
					poReport.WIP33 += m.CompletionQuantity
					poReport.WIP33Output += stageDailyOutput

				case "WIP6":
					poReport.WIP6 += m.CompletionQuantity
					poReport.WIP6Output += stageDailyOutput

				case "WIP8":
					poReport.WIP8 += m.CompletionQuantity
					poReport.WIP8Output += stageDailyOutput

				case "FG10":
					poReport.FG10 += m.CompletionQuantity
					// 通常 FG 不列入 WIP output

				case "FG14":
					poReport.FG14 += m.CompletionQuantity
				}
			}
		}
		// -----------------------------
		// Determine final status
		//    (business priority)
		// -----------------------------
		poReport.Status = "Cancelled"
		reports = append(reports, poReport)
	}

	return reports
}

func getPoMap(data []types.ExcelData) map[string][]string {
	result := make(map[string][]string)
	result["A"] = []string{}
	result["B"] = []string{}
	result["C"] = []string{}

	for _, row := range data {
		switch row.Factory {
		case "FT-YS":
			result["A"] = append(result["A"], row.PoNumber)
		case "FT-VNTB":
			result["B"] = append(result["B"], row.PoNumber)
		case "FT-IDNYQ":
			result["C"] = append(result["C"], row.PoNumber)
		}
	}

	return result
}

func (s *poStatusService) GetExcelPoMap(file *multipart.FileHeader, date string) (map[string]string, error) {
	// Open file to read
	openedFile, err := file.Open()
	if err != nil {
		return nil, fmt.Errorf("cannot open file: %v", err)
	}
	defer openedFile.Close()

	// Read table and put into result slice
	excelData, err := utils.ParseExcelFile(openedFile)
	if err != nil {
		return nil, fmt.Errorf("cannot read file: %v", err)
	}

	// get Po List from excel result
	poMap := getPoMap(excelData)

	dbSet := []string{"A", "B", "C"}
	result := map[string]string{}

	for _, databaseType := range dbSet {

		basePoList := poMap[databaseType]

		// Get data from po list of db type
		data, _, err := PoStatusService.GetDailyPoStatusByPOList(databaseType, date, basePoList)
		if err != nil {
			return nil, fmt.Errorf("failed to get POdata: %v", err)
		}

		// Send data to deckers
		// token := jwt.GetJWT(databaseType)
		// DeckersPostServiceInstance.PostDailyPoStatus(databaseType, data, token)

		// Prepare excel export
		report := PoStatusService.ExportPoReport(data)

		// Check the PO is deleted in database
		for _, poStatus := range basePoList {
			if !Contains(data, poStatus) {
				report = append(report, types.POExcelReport{
					Date:   date,
					KHPO:   poStatus,
					Status: "Deleted",
				})
			}
		}

		// Create excel report
		filename := getFilename(databaseType, date, "Po Status")
		err = utils.WriteStructsToExcel(filename, "Po Status", report)
		if err != nil {
			log.Println("cannot export excel file: " + err.Error())
		}

		// Read exported file
		fileData, err := ioutil.ReadFile(filename)
		if err != nil {
			return nil, fmt.Errorf("cannot read file: %v", err)
		}

		// Delete file after read to avoid data overload
		// utils.DeleteFile(filename)

		// Encode to base64 for passing it to JSON
		encoded := base64.StdEncoding.EncodeToString(fileData)

		switch databaseType {
		case "A":
			result["FT-YS"] = encoded
		case "B":
			result["FT-VNTB"] = encoded
		case "C":
			result["FT-IDNYQ"] = encoded
		}
	}

	return result, nil
}

func getFilename(databaseType, date, filetype string) string {
	dbFactory := ""
	switch databaseType {
	case "A":
		dbFactory = "YS"
	case "B":
		dbFactory = "TB"
	case "C":
		dbFactory = "YQ"
	}
	return "po-report/" + date + "-" + filetype + "-" + dbFactory + ".xlsx"
}

func Contains(slice []types.DailyPoStatus, str string) bool {
	for _, item := range slice {
		if item.PoNumber == str {
			return true
		}
	}
	return false
}
