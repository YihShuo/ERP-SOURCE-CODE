package services

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
	"web-api/internal/api/repo"
	"web-api/internal/integration/deckers"
	"web-api/internal/pkg/config"
	"web-api/internal/pkg/models/response"
	"web-api/internal/pkg/models/types"
	"web-api/internal/pkg/utils"

	"github.com/google/uuid"
)

type deckersPostService struct {
	*BaseService
}

var DeckersPostServiceInstance = &deckersPostService{}

type Item struct {
	Index  int      `json:"index"`
	PoList []string `json:"po_list"`
}

// PostDeckerOutputsFG posts the FG data in chunks to the API
func (s *deckersPostService) PostDeckerOutputsFG(deckerOutputsFG []types.DeckerOutputsFG, databaseType, oauthToken string) {
	baseURL := config.GetConfig().DeckersServer.PostData
	grouped := groupByStageCode(deckerOutputsFG)
	var responseBuilder strings.Builder
	apiEndpoint := fmt.Sprintf("%s/dtd/outputs?type=FG", baseURL)

	safeBodySize := 400_000

	for stageCode, group := range grouped {
		mailBody := ""

		marshalFunc := func(item types.DeckerOutputsFG) ([]byte, error) {
			return json.Marshal(item)
		}

		postRequestFunc := func(requestBody []byte) (string, error) {
			return sendRequest(apiEndpoint, oauthToken, requestBody)
		}

		// 內部會自動處理封箱與容量控管
		if _, err := processChunk(
			group,
			safeBodySize,
			marshalFunc,
			postRequestFunc,
			&mailBody, "", databaseType,
		); err != nil {
			log.Printf("Error processing StageCode %s: %v", stageCode, err)
		}

		responseBuilder.WriteString(fmt.Sprintf("StageCode %s:\n%s\n", stageCode, mailBody))
	}

	if err := utils.MailSenderInstance.SendEmail(databaseType, "FG", responseBuilder.String()); err != nil {
		log.Printf("Failed to send email: %v", err)
	}
}

// PostDailyPoStatus posts the daily PO status in chunks to the API
func (s *deckersPostService) PostDailyPoStatus(databaseType string, dailyPoStatus []types.DailyPoStatus, oauthToken, UserID string) {
	if len(dailyPoStatus) == 0 {
		return
	}

	baseURL := config.GetConfig().DeckersServer.PostData
	apiEndpoint := fmt.Sprintf("%s/dtd/daily-po-status", baseURL)

	// 定義轉檔與發送邏輯
	marshalFunc := func(item types.DailyPoStatus) ([]byte, error) {
		return json.Marshal(item)
	}

	postRequestFunc := func(requestBody []byte) (string, error) {
		return sendRequest(apiEndpoint, oauthToken, requestBody)
	}

	mailBody := ""
	// 透過 processChunk，內部會自動處理裝箱、失敗跳過與 HTML 郵件組裝
	poReturnMap, err := processChunk(dailyPoStatus, 80000, marshalFunc, postRequestFunc, &mailBody, UserID, databaseType)

	if err != nil {
		log.Printf("注意：處理過程中發生部分錯誤: %v", err)
		// 記錄錯誤 Log，但不中斷，讓成功的批次能繼續更新 ReturnID
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "PostDailyPoStatus",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "部分處理失敗: " + err.Error(),
		}
		_ = repo.LogRepositoryInstance.SavePoLog(databaseType, poLog)
	}

	// 不管有無錯誤，都嘗試更新已成功發送的 Return ID
	if len(poReturnMap) > 0 {
		if err := PoReportService.UpdateReportWithReturnId(databaseType, poReturnMap, dailyPoStatus[0].Date); err != nil {
			log.Printf("fail to update return id: %v", err)
		} else {
			log.Println("save return ID completed")
		}
	}

	// 發送 HTML 郵件
	if mailBody != "" {
		// 確保信件結構完整
		fullHTML := "<html><body>" + mailBody + "</body></html>"
		if err := utils.MailSenderInstance.SendEmailHTML(databaseType, "PostDailyPoStatus 報告", fullHTML); err != nil {
			log.Printf("Failed to send email: %v", err)
		}
	}
}

func (s *deckersPostService) WriteReturnFile(databaseType string, dailyPoStatus []types.DailyPoStatus) {
	step := 20

	chunks := splitSlice(dailyPoStatus, step)

	// Khởi tạo map với key là string, value là slice of string
	data := []Item{}

	for index, chunk := range chunks {

		var poList []string
		for _, po := range chunk {
			poList = append(poList, po.PoNumber)
		}
		data = append(data, Item{
			Index:  index,
			PoList: poList,
		})
	}

	if len(dailyPoStatus) > 0 {
		// Mở file để ghi
		file, err := os.Create(databaseType + "_" + dailyPoStatus[0].Date + "_return-data.json")
		if err != nil {
			fmt.Println("Lỗi khi tạo file return-data:", err)
			return
		}
		defer file.Close()

		// Ghi dữ liệu dưới dạng JSON vào file
		encoder := json.NewEncoder(file)
		encoder.SetIndent("", "    ") // Định dạng đẹp
		err = encoder.Encode(data)
		if err != nil {
			fmt.Println("Lỗi khi ghi file return-data:", err)
		}
	}
}

// PostDeckerOutputWIP posts WIP data in chunks to the API
func (s *deckersPostService) PostDeckerOutputWIP(databaseType string, deckerOutputs []types.DeckerOutput, oauthToken string) {
	if len(deckerOutputs) == 0 {
		return
	}
	baseURL := config.GetConfig().DeckersServer.PostData
	apiEndpoint := fmt.Sprintf("%s/dtd/outputs?type=WIP", baseURL)
	mailBody := ""
	marshalFunc := func(item types.DeckerOutput) ([]byte, error) { return json.Marshal(item) }
	postRequestFunc := func(requestBody []byte) (string, error) { return sendRequest(apiEndpoint, oauthToken, requestBody) }

	wipReturnMap, err := processChunk(deckerOutputs, 150000, marshalFunc, postRequestFunc, &mailBody, "", databaseType)
	if err != nil {
		log.Printf("Error processing WIP: %v", err)
	}

	if err := WIPReportServiceInstance.UpdateWIPReturnId(databaseType, wipReturnMap); err != nil {
		log.Printf("error when update WIP return ID: %v", err)
	}
}

// PostTQCOutput posts TQC data in chunks to the Deckers's API
func (s *deckersPostService) PostTQCOutput(databaseType string, tqcPayload []types.TqcOutputPayload, oauthToken string) {
	baseURL := config.GetConfig().DeckersServer.PostData
	apiEndpoint := fmt.Sprintf("%s/qc/tqc", baseURL)

	mailBody := ""
	marshalFunc := func(item types.TqcOutputPayload) ([]byte, error) { return json.Marshal(item) }
	postRequestFunc := func(requestBody []byte) (string, error) { return sendRequest(apiEndpoint, oauthToken, requestBody) }

	if _, err := processChunk(tqcPayload, 150000, marshalFunc, postRequestFunc, &mailBody, "", databaseType); err != nil {
		log.Printf("Error processing TQC: %v", err)
	}

	if err := utils.MailSenderInstance.SendEmail(databaseType, "TQC Data", mailBody); err != nil {
		log.Printf("Error sending email: %v", err)
	}
}

// PostTQCOutput posts TQC data in chunks to the Deckers's API
func (s *deckersPostService) PostRQCOutput(databaseType string, rqcPayload []types.RqcResult, oauthToken string) {
	baseURL := config.GetConfig().DeckersServer.PostData
	apiEndpoint := fmt.Sprintf("%s/qc/rqc", baseURL)

	mailBody := ""
	marshalFunc := func(item types.RqcResult) ([]byte, error) { return json.Marshal(item) }
	postRequestFunc := func(requestBody []byte) (string, error) { return sendRequest(apiEndpoint, oauthToken, requestBody) }

	if _, err := processChunk(rqcPayload, 150000, marshalFunc, postRequestFunc, &mailBody, "", databaseType); err != nil {
		log.Printf("Error processing RQC: %v", err)
	}

	if err := utils.MailSenderInstance.SendEmail(databaseType, "RQC Data", mailBody); err != nil {
		log.Printf("Error sending email: %v", err)
	}
}

// PostTQCOutput posts TQC data in chunks to the Deckers's API
func (s *deckersPostService) PostBgradeOutput(databaseType string, bgradePayload []types.BgradeInventory, oauthToken string) (map[string]string, error) {
	baseURL := config.GetConfig().DeckersServer.PostData
	apiEndpoint := fmt.Sprintf("%s/qc/b-grade-inventory", baseURL)

	mailBody := ""
	marshalFunc := func(item types.BgradeInventory) ([]byte, error) { return json.Marshal(item) }
	postRequestFunc := func(requestBody []byte) (string, error) { return sendRequest(apiEndpoint, oauthToken, requestBody) }

	returnIdMap, err := processChunk(bgradePayload, 150000, marshalFunc, postRequestFunc, &mailBody, "", databaseType)
	if err != nil {
		log.Printf("Error processing B-Grade: %v", err)
	}

	if err := utils.MailSenderInstance.SendEmail(databaseType, "B-Grade Data", mailBody); err != nil {
		log.Printf("Error sending email: %v", err)
	}

	return returnIdMap, err
}

func (s *deckersPostService) PostRepacking(
	databaseType string,
	repackingList []types.RepackingResult,
	oauthToken string,
) (map[string]string, error) {

	baseURL := config.GetConfig().DeckersServer.PostData
	apiEndpoint := fmt.Sprintf("%s/qc/repacking", baseURL)

	marshalFunc := func(item types.RepackingResult) ([]byte, error) {
		return json.Marshal(item)
	}

	postRequestFunc := func(requestBody []byte) (string, error) {
		return sendRequest(apiEndpoint, oauthToken, requestBody)
	}

	var mailBody string

	// 執行送資料
	returnMap, processErr := processSingleData(
		repackingList,
		marshalFunc,
		postRequestFunc,
		&mailBody,
	)

	if processErr != nil {
		log.Printf("error occuring when sending repacking data: %v\n", processErr)
	}

	// 不論成功或失敗都寄信
	htmlBody := "<html><body>" + mailBody + "</body></html>"

	if err := utils.MailSenderInstance.SendEmailHTML(
		databaseType,
		"Repacking Data",
		htmlBody,
	); err != nil {
		log.Printf("Error sending email: %v", err)
		return returnMap, err
	}

	// 把 process 的錯誤回傳給 Controller
	if processErr != nil {
		return returnMap, processErr
	}

	return returnMap, nil
}

func processSingleData[T any](
	data []T,
	marshalFunc func(item T) ([]byte, error),
	postRequestFunc func(requestBody []byte) (string, error),
	mailBody *string,
) (map[string]string, error) {

	poReturnIdMap := make(map[string]string)
	var errBody, sucBody string
	var hasError bool

	// 內部輔助：自動辨識型別並提取關鍵識別碼 (如 PO, StageCode)
	autoExtractKey := func(item any) string {
		switch obj := item.(type) {
		case types.DailyPoStatus:
			return obj.PoNumber
		default:
			return ""
		}
	}

	for _, item := range data {
		// Marshal ra request body dưới dạng 1 object đơn
		reqBody, err := marshalFunc(item)
		if err != nil {
			hasError = true
			key := autoExtractKey(item)
			errBody += fmt.Sprintf(`<p style="color:red;"><b>[Marshal 失敗]</b> Item: %s | 錯誤: %s</p>`, key, err.Error())
			continue
		}

		// Gọi API luôn cho object này
		log.Printf("Sending Repacking Request: %s\n", string(reqBody))
		_, returnID, err := sendWithRetryRepacking(reqBody, postRequestFunc, 3)

		// Lấy key từ code bên ngoài giống như logic cũ
		key := extractKeyFromItem(item)

		if err != nil {
			hasError = true
			failKey := autoExtractKey(item)
			if failKey == "" {
				failKey = key // Fallback nếu autoExtractKey không lấy được
			}
			errBody += fmt.Sprintf(`<p style="color:red;"><b>[發送失敗]</b> Item: %s | 錯誤: %s</p>`, failKey, err.Error())
			continue
		}

		// Ghi nhận thành công
		sucBody += "<p>[成功] Item: " + key + " | ReturnID: " + returnID + "</p>"
		if key != "" {
			poReturnIdMap[key] = returnID
		}

		// Tuỳ chọn: Thêm delay nhỏ để tránh làm quá tải API do bắn 1-1 liên tục (rate limit)
		time.Sleep(50 * time.Millisecond)
	}

	// 最終郵件內容組裝
	if errBody != "" {
		*mailBody = "<h2>錯誤清單</h2>" + errBody + "<hr><h2>成功記錄</h2>" + sucBody
	} else {
		*mailBody = sucBody
	}

	var finalErr error
	if hasError {
		finalErr = fmt.Errorf("部分資料發送失敗 (Có lỗi khi gửi một số item)")
	}
	return poReturnIdMap, finalErr
}

// PostDeckerOutputsRM posts RM data to the API
func (s *deckersPostService) PostDeckerOutputsRM(deckerOutputsRM []types.DeckerOutputsRM, databaseType, oauthToken string) {
	baseURL := config.GetConfig().DeckersServer.PostData // 确保获取配置的 baseURL
	apiEndpoint := fmt.Sprintf("%s/dtd/outputs?type=RM", baseURL)

	step := 400
	maxBodySize := 500_000
	chunks := splitSlice(deckerOutputsRM, step)
	log.Printf("RM Lenth: %v\n", len(deckerOutputsRM))

	mailBody := ""
	marshalFunc := func(item types.DeckerOutputsRM) ([]byte, error) {
		return json.Marshal(item)
	}

	postRequestFunc := func(requestBody []byte) (string, error) {
		return sendRequest(apiEndpoint, oauthToken, requestBody)
	}

	for _, chunk := range chunks {

		if _, err := processChunk(chunk, maxBodySize, marshalFunc, postRequestFunc, &mailBody, "", databaseType); err != nil {
			log.Printf("Error processing chunk: %v", err)
		}
	}

	if err := utils.MailSenderInstance.SendEmail(databaseType, "RM Stage", mailBody); err != nil {
		log.Printf("Error sending email: %v", err)
	}
}

// Helper function to group by StageCode
func groupByStageCode(deckerOutputs []types.DeckerOutputsFG) map[string][]types.DeckerOutputsFG {
	grouped := make(map[string][]types.DeckerOutputsFG)
	for _, item := range deckerOutputs {
		grouped[item.StageCode] = append(grouped[item.StageCode], item)
	}
	return grouped
}

// Helper function to send HTTP POST request
func sendRequest(url, oauthToken string, body []byte) (string, error) {
	client := &http.Client{}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(body))
	if err != nil {
		return "", fmt.Errorf("failed to create request: %v", err)
	}
	req.Header.Set("Authorization", "Bearer "+oauthToken)
	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("failed to send request: %v", err)
	}
	defer resp.Body.Close()

	responseBody, err := io.ReadAll(resp.Body) // Use io.ReadAll instead of ioutil.ReadAll
	if err != nil {
		return "", fmt.Errorf("failed to read response: %v", err)
	}

	return string(responseBody), nil
}

func extractRetID(jsonStr string) (string, error) {
	var resp response.DeckerResponse
	err := json.Unmarshal([]byte(jsonStr), &resp)
	if err != nil {
		return "", err
	}
	return resp.RetID, nil
}

// Helper function to process each chunk of data

func splitSlice[T any](items []T, step int) [][]T {
	var chunks [][]T
	for i := 0; i < len(items); i += step {
		end := i + step
		if end > len(items) {
			end = len(items)
		}
		chunks = append(chunks, items[i:end])
	}
	return chunks
}

func parseAnyToStruct(data any, out interface{}) error {
	bytes, err := json.Marshal(data)
	if err != nil {
		return err
	}
	return json.Unmarshal(bytes, out)
}

func processChunk[T any](
	chunk []T,
	safeBodySize int,
	marshalFunc func(item T) ([]byte, error),
	postRequestFunc func(requestBody []byte) (string, error),
	mailBody *string, userID, databaseType string,
) (map[string]string, error) {

	date := ""
	postId := ""
	if poList, isDailyPo := any(chunk).([]types.DailyPoStatus); isDailyPo {
		if len(poList) > 0 {
			date = poList[0].Date
		}
		id, err := uuid.NewRandom()
		if err != nil {
			fmt.Println("Lỗi khi tạo UUID:", err)
			postId = utils.GenerateRandomString(16)
		} else {
			postId = id.String()
		}
	}

	poReturnIdMap := make(map[string]string)
	var requestBody []byte
	var currentBatchKeys []string
	var currentBatchItems []T
	var errBody, sucBody string
	var hasError bool

	// 內部輔助：自動辨識型別並提取關鍵識別碼 (如 PO, StageCode)
	autoExtractKey := func(item any) string {
		switch obj := any(item).(type) { // Ép về any() trước khi switch
		case types.DailyPoStatus:
			return obj.PoNumber
		default:
			return ""
		}
	}

	// 內部輔助：格式化錯誤列表
	formatFailedItems := func(items []T) string {
		var keys []string
		for _, item := range items {
			if key := autoExtractKey(item); key != "" {
				keys = append(keys, key)
			}
		}
		return strings.Join(keys, ", ")
	}

	batch := 0

	for _, item := range chunk {
		subStream, err := marshalFunc(item)
		if err != nil {
			continue
		}

		// 容量控管與發送
		if len(requestBody)+len(subStream) > safeBodySize && len(requestBody) > 0 {

			_, returnID, err := sendWithRetry(requestBody, postRequestFunc, 3)
			batch++
			if err != nil {
				hasError = true
				errBody += fmt.Sprintf(`<p style="color:red;"><b>[失敗批次]</b> Items: %s | 錯誤: %s</p>`, formatFailedItems(currentBatchItems), err.Error())
				requestBody, currentBatchKeys, currentBatchItems = []byte{}, []string{}, []T{}
				savePoPayload(requestBody, databaseType, returnID, date, userID, postId, batch)
				continue
			} else {
				savePoPayload(requestBody, databaseType, returnID, date, userID, postId, batch)
			}

			sucBody += "<p>[成功] ReturnID: " + returnID + "</p>"
			for _, k := range currentBatchKeys {
				poReturnIdMap[k] = returnID
			}
			requestBody, currentBatchKeys, currentBatchItems = []byte{}, []string{}, []T{}
			time.Sleep(500 * time.Millisecond) // 流控
		}

		requestBody, _ = appendStream(requestBody, subStream)
		currentBatchItems = append(currentBatchItems, item)
		if key := extractKeyFromItem(item); key != "" {
			currentBatchKeys = append(currentBatchKeys, key)
		}
	}

	// 處理最後剩下的資料
	if len(requestBody) > 0 {
		_, returnID, err := sendWithRetry(requestBody, postRequestFunc, 3)
		batch++
		if err != nil {
			hasError = true
			errBody += fmt.Sprintf(`<p style="color:red;"><b>[最後一批失敗]</b> Items: %s | 錯誤: %s</p>`, formatFailedItems(currentBatchItems), err.Error())
		} else {
			sucBody += "<p>[成功] 最後一批 ReturnID: " + returnID + "</p>"
			for _, k := range currentBatchKeys {
				poReturnIdMap[k] = returnID
			}
		}
		savePoPayload(requestBody, databaseType, returnID, date, userID, postId, batch)
	}

	// 最終郵件內容組裝
	if errBody != "" {
		*mailBody = "<h2>錯誤清單</h2>" + errBody + "<hr><h2>成功記錄</h2>" + sucBody
	} else {
		*mailBody = sucBody
	}

	var finalErr error
	if hasError {
		finalErr = fmt.Errorf("部分批次發送失敗")
	}
	return poReturnIdMap, finalErr
}

func savePoPayload(requestBody []byte, databaseType, returnID, date, userID, postId string, batch int) {
	if postId == "" {
		return
	}
	err := PoPayloadService.InsertPoPayload(string(requestBody), databaseType, returnID, date, userID, postId, batch)
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "PostDailyPo",
			LogDate:  time.Now(),
			Source:   "-",
			Env:      config.GetEnvironment(),
			Message:  "InsertPoPayload: " + err.Error(),
		}
		_ = repo.LogRepositoryInstance.SavePoLog(databaseType, poLog)
	}
}

func appendStream(requestBody []byte, itemStream []byte) ([]byte, error) {
	var subOutput []interface{}
	var item interface{}

	err := json.Unmarshal(itemStream, &item)
	if err != nil {
		log.Printf("Error when unmarshal item: %v\n", err)
		return requestBody, err
	}

	if len(requestBody) <= 0 {
		subOutput = append(subOutput, item)
	} else {
		err = json.Unmarshal(requestBody, &subOutput)
		if err != nil {
			log.Printf("Error when unmarshal output: %v\n", err)
			return requestBody, err
		}

		subOutput = append(subOutput, item)
	}
	return json.Marshal(subOutput)
}

// 輔助：提取 PO Number (用於失敗時紀錄)
func extractPoNumber(item any) string {
	switch obj := item.(type) {
	case types.DailyPoStatus:
		return obj.PoNumber
	case types.RepackingResult:
		return obj.PoNumber
	case types.DeckerOutput, types.TqcOutputPayload, types.RqcResult, types.BgradeInventory:
		// 若其他型別無 PO Number，返回空字串，郵件將跳過不顯示
		return ""
	}
	return ""
}

// 輔助：提取 Key (用於更新 ReturnID)
func extractKeyFromItem(item any) string {
	switch obj := item.(type) {
	// DailyPO
	case types.DailyPoStatus:
		return strings.Join([]string{obj.PoNumber, obj.StyleNumber, obj.ColorCode, obj.ShipID}, "_")

	// WIP
	case types.DeckerOutput:
		return strings.Join([]string{obj.StartTime, obj.EndTime, obj.ProductionLineNumber, obj.FactoryWorkOrderNumber, obj.SizeNumber}, "__")

	// Repacking
	case types.RepackingResult:
		return strings.Join([]string{obj.PoNumber, obj.StyleNumber, obj.ColorCode, obj.ShipID}, "_")
	case types.RepackingResultExcel:
		return strings.Join([]string{obj.PoNumber, obj.StyleNumber, obj.ColorCode, obj.ShipID}, "_")

	// B-Grade
	case types.BgradeInventory:
		return strings.Join([]string{obj.StyleNumber, obj.ColorCode}, "_")
	case types.BgradeInventoryExcel:
		return strings.Join([]string{obj.StyleNumber, obj.ColorCode}, "_")
	}

	return ""
}

func sendWithRetry(requestBody []byte, postReq func([]byte) (string, error), maxRetries int) (string, string, error) {
	var lastErr error

	for attempt := 1; attempt <= maxRetries; attempt++ {
		// 1. 發送請求
		respStr, err := postReq(requestBody)
		if err != nil {
			lastErr = fmt.Errorf("HTTP 網路請求失敗: %v", err)
			log.Printf("第 %d 次嘗試失敗: %v\n", attempt, lastErr)
			time.Sleep(time.Second * time.Duration(attempt))
			continue
		}

		// 2. 解析回應 JSON
		var apiResp deckers.DeckerResponse
		if unmarshalErr := json.Unmarshal([]byte(respStr), &apiResp); unmarshalErr != nil {
			lastErr = fmt.Errorf("無法解析 JSON 回傳值: %v, 回傳內容: %s", unmarshalErr, respStr)
			log.Printf("第 %d 次嘗試失敗: %v\n", attempt, lastErr)
			time.Sleep(time.Second * time.Duration(attempt))
			continue
		}

		// 3. 核心邏輯：判斷 retCode
		if apiResp.RetCode == 0 {
			return respStr, apiResp.RetID, nil // 成功
		}

		return "", "", fmt.Errorf("API_REJECTED|retCode:%d|msg:%s", apiResp.RetCode, apiResp.RetMsg)
	}

	return "", "", fmt.Errorf("達到最大重試次數 (%d)。最後錯誤: %v", maxRetries, lastErr)
}

func sendWithRetryRepacking(requestBody []byte, postReq func([]byte) (string, error), maxRetries int) (string, string, error) {
	var lastErr error

	for attempt := 1; attempt <= maxRetries; attempt++ {
		// 1. 發送請求
		respStr, err := postReq(requestBody)
		if err != nil {
			lastErr = fmt.Errorf("HTTP 網路請求失敗: %v", err)
			log.Printf("第 %d 次嘗試失敗: %v\n", attempt, lastErr)
			time.Sleep(time.Second * time.Duration(attempt))
			continue
		}

		// 2. 解析回應 JSON
		var apiResp deckers.DeckersRepackingResponse
		if unmarshalErr := json.Unmarshal([]byte(respStr), &apiResp); unmarshalErr != nil {
			lastErr = fmt.Errorf("無法解析 JSON 回傳值: %v, 回傳內容: %s", unmarshalErr, respStr)
			log.Printf("第 %d 次嘗試失敗: %v\n", attempt, lastErr)
			time.Sleep(time.Second * time.Duration(attempt))
			continue
		}

		// 3. 核心邏輯：判斷 retCode
		if apiResp.Status == http.StatusOK {
			return respStr, apiResp.ReportId, nil // 成功
		}

		return "", "", fmt.Errorf("API_REJECTED|retCode:%d|msg:%s", apiResp.Status, apiResp.Message)
	}

	return "", "", fmt.Errorf("達到最大重試次數 (%d)。最後錯誤: %v", maxRetries, lastErr)
}
