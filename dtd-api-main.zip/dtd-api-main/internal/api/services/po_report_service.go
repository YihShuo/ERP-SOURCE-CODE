package services

import (
	"fmt"
	"log"
	"strings"
	"time"
	"web-api/internal/api/repo"
	"web-api/internal/pkg/models/types"
	"web-api/internal/pkg/utils"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type poReportService struct{}

var PoReportService = &poReportService{}

// Khai báo struct tạm để hứng dữ liệu trả về từ mệnh đề OUTPUT
type mergedOutput struct {
	ID        uint      `gorm:"column:id"`
	Date      time.Time `gorm:"column:report_date"`
	KHPO      string    `gorm:"column:khpo"`
	StyleNo   string    `gorm:"column:style_no"`
	ColorCode string    `gorm:"column:color_code"`
	ShipID    string    `gorm:"column:ship_id"`
}

func (s *poReportService) SavePOExcelReports(
	databaseType string,
	inputs []types.POExcelReport,
	isResent bool,
	userID string,
) (map[string]uint, error) {

	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	idMap := make(map[string]uint)

	if len(inputs) == 0 {
		return idMap, nil
	}

	// Map trung gian để dò lại DDBH từ bộ khóa của DB
	dbKeyToDDBH := make(map[string]string)

	// 1. Lọc trùng (Giữ lại bản ghi cuối)
	reportMap := make(map[string]types.POSaveReport)
	keyOrder := make([]string, 0, len(inputs))

	for _, input := range inputs {
		formatedDate, err := time.Parse("2006-01-02", input.Date)
		if err != nil {
			log.Printf("Skip KHPO %s vì lỗi parse ngày: %v", input.KHPO, err)
			continue
		}

		poSaveReport := input.ParseExcelToSave()
		poSaveReport.Date = formatedDate

		// Tạo khóa DB để nhớ DDBH tương ứng
		dbKey := input.Date + "_" + input.KHPO + "_" + input.StyleNo + "_" + input.ColorCode + "_" + input.ShipID
		// Lưu lại DDBH (giả sử DDBH là kiểu string)
		dbKeyToDDBH[dbKey] = input.DDBH

		// Key lúc lọc trùng theo ý bạn: Date_DDBH
		key := input.Date + "_" + input.DDBH

		if _, exists := reportMap[key]; !exists {
			keyOrder = append(keyOrder, key)
		}
		reportMap[key] = poSaveReport
	}

	reports := make([]types.POSaveReport, 0, len(reportMap))
	for _, key := range keyOrder {
		reports = append(reports, reportMap[key])
	}

	if len(reports) == 0 {
		return idMap, nil
	}

	// 2. Mở Transaction
	tx := db.Begin()
	if tx.Error != nil {
		return nil, tx.Error
	}

	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
		}
	}()

	// 3. Xử lý Batching và gọi Raw MERGE
	batchSize := 80

	for i := 0; i < len(reports); i += batchSize {
		end := i + batchSize
		if end > len(reports) {
			end = len(reports)
		}

		batch := reports[i:end]

		var valueStrings []string
		var valueArgs []interface{}

		for _, r := range batch {
			valueStrings = append(valueStrings, "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")

			valueArgs = append(valueArgs,
				r.Date, r.KHPO, r.StyleNo, r.ColorCode, r.ShipID,
				r.Status, r.Qty, r.RM01, r.RM03, r.WIP31,
				r.WIP33, r.WIP6, r.WIP8, r.FG10, r.FG14,
				r.WIP31Output, r.WIP33Output, r.WIP6Output, r.WIP8Output,
				isResent, userID,
			)
		}

		stmt := fmt.Sprintf(`
			DECLARE @merge_output TABLE (
				id BIGINT,
				report_date DATE,
				khpo VARCHAR(50),
				style_no VARCHAR(50),
				color_code VARCHAR(50),
				ship_id VARCHAR(50)
			);

			MERGE INTO po_daily AS target
			USING (VALUES %s) AS source (
				report_date, khpo, style_no, color_code, ship_id,
				status, quantity, rm01, rm03, wip31, wip33, wip6, wip8, fg10, fg14, wip31output, wip33output, wip6output, wip8output, dashboard_resent, USERID
			)
			ON target.report_date = source.report_date
			AND target.khpo = source.khpo
			AND target.style_no = source.style_no
			AND target.color_code = source.color_code
			AND target.ship_id = source.ship_id

			WHEN MATCHED THEN
				UPDATE SET
					target.status = source.status,
					target.quantity = source.quantity,
					target.rm01 = source.rm01,
					target.rm03 = source.rm03,
					target.wip31 = source.wip31,
					target.wip33 = source.wip33,
					target.wip6 = source.wip6,
					target.wip8 = source.wip8,
					target.fg10 = source.fg10,
					target.fg14 = source.fg14,
					target.UserDate = GETDATE(),
					target.wip31output = source.wip31output,
					target.wip33output = source.wip33output,
					target.wip6output = source.wip6output,
					target.wip8output = source.wip8output,
					target.dashboard_resent = source.dashboard_resent,
					target.USERID = source.USERID

			WHEN NOT MATCHED THEN
				INSERT (
					report_date, khpo, style_no, color_code, ship_id,
					status, quantity, rm01, rm03, wip31, wip33, wip6, wip8,
					fg10, fg14, wip31output, wip33output, wip6output, wip8output, dashboard_resent, USERID
				)
				VALUES (
					source.report_date, source.khpo, source.style_no, source.color_code, source.ship_id,
					source.status, source.quantity, source.rm01, source.rm03, source.wip31,
					source.wip33, source.wip6, source.wip8, source.fg10, source.fg14,
					source.wip31output, source.wip33output, source.wip6output, source.wip8output,
					source.dashboard_resent, source.USERID
				)

			OUTPUT 
				INSERTED.id,
				INSERTED.report_date,
				INSERTED.khpo,
				INSERTED.style_no,
				INSERTED.color_code,
				INSERTED.ship_id
			INTO @merge_output;

			SELECT * FROM @merge_output;
		`, strings.Join(valueStrings, ","))

		var results []mergedOutput

		if err := tx.Raw(stmt, valueArgs...).Scan(&results).Error; err != nil {
			tx.Rollback()
			return nil, fmt.Errorf("lỗi khi chạy MERGE batch %d: %v", i, err)
		}

		// 4. Lấy DDBH từ map trung gian và tạo kết quả
		for _, res := range results {
			dateStr := res.Date.Format("2006-01-02")

			// Tạo lại khóa DB để tìm DDBH
			dbKey := dateStr + "_" + res.KHPO + "_" + res.StyleNo + "_" + res.ColorCode + "_" + res.ShipID

			// Lấy DDBH ra và gán ID
			if ddbh, ok := dbKeyToDDBH[dbKey]; ok {
				finalKey := dateStr + "_" + ddbh
				idMap[finalKey] = res.ID
			}
		}

		for _, po := range batch {
			dateStr := po.Date.Format("2006-01-02")

			// Tạo lại khóa DB để tìm DDBH
			dbKey := dateStr + "_" + po.KHPO + "_" + po.StyleNo + "_" + po.ColorCode + "_" + po.ShipID

			// Lấy DDBH ra và gán ID
			if ddbh, ok := dbKeyToDDBH[dbKey]; ok {
				finalKey := dateStr + "_" + ddbh
				poDailyID := idMap[finalKey]
				err = repo.PoReportRepository.SaveXFDetail(databaseType, po.XFDetail, poDailyID)
				if err != nil {
					log.Println("failed to SaveXFDetail: " + err.Error())
				}
			}

		}
	}

	if err := tx.Commit().Error; err != nil {
		return nil, err
	}

	return idMap, nil
}

func (s *poReportService) SaveRawPOReports(databaseType string, inputs []types.POExcelReport, idMap map[string]uint) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	if len(inputs) == 0 {
		return nil
	}

	// 1. Lọc và chuẩn bị mảng dữ liệu hợp lệ trước khi thao tác với DB
	var validReports []types.RawPOSaveReport

	for _, input := range inputs {
		key := input.Date + "_" + input.DDBH

		// Chỉ lấy những dòng map được ID từ bước trước
		if id, exist := idMap[key]; exist {
			poSaveReport := input.ParseExcelToRawSave()
			poSaveReport.Date = input.Date
			poSaveReport.CombineID = id

			validReports = append(validReports, poSaveReport)
		}
	}

	// Nếu không có dữ liệu hợp lệ thì thoát luôn, đỡ mở transaction tốn tài nguyên
	if len(validReports) == 0 {
		return nil
	}

	// 2. Mở Transaction và Insert theo batch 100
	return db.Transaction(func(tx *gorm.DB) error {
		// Dùng OnConflict DoNothing để bỏ qua các bản ghi bị trùng lặp (nếu có)
		err := tx.Clauses(clause.OnConflict{DoNothing: true}).
			CreateInBatches(&validReports, 100).Error

		if err != nil {
			log.Printf("Lỗi khi save batch raw reports: %v", err)
			return err // Trả về lỗi để GORM tự động Rollback
		}

		return nil // Trả về nil để GORM tự động Commit
	})
}

func (s *poReportService) RemovePOInDatabase(databaseType string, thresholdDay int) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	thresholdDate := time.Now().AddDate(0, 0, -thresholdDay)

	if err := db.
		Where("report_date < ?", thresholdDate.Format("2006-01-02")).
		Delete(&types.POSaveReport{}).Error; err != nil {
		return fmt.Errorf("error remove po_daily: %w", err)
	}

	if err := db.
		Where("report_date < ?", thresholdDate.Format("2006-01-02")).
		Delete(&types.RawPOSaveReport{}).Error; err != nil {
		return fmt.Errorf("error remove po_daily: %w", err)
	}

	return nil
}

func (pr *poReportService) GetReport(khpo, startDate, endDate, factory string) ([]types.POExcelReport, error) {

	databaseType, err := utils.GetDatabaseTypeByFactory(factory)
	if err != nil {
		return nil, err
	}

	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
	SELECT 
		id, 
		CONVERT(VARCHAR, report_date, 23) AS report_date,
		khpo, 
		style_no, 
		color_code, 
		ship_id, 
		status, 
		quantity, 
		return_id,
		rm01, rm03, wip31, wip33, wip6, wip8, fg10, fg14, wip31output, wip33output, wip6output, wip8output
	FROM 
		po_daily
	WHERE 
		1=1
`

	var args []interface{}

	if khpo != "" {
		query += " AND khpo LIKE ?"
		args = append(args, "%"+khpo+"%")
	}
	if startDate != "" {
		start, err := time.Parse("2006-01-02", startDate)
		if err != nil {
			return nil, fmt.Errorf("startDate không hợp lệ: %w", err)
		}
		query += " AND report_date >= ?"
		args = append(args, start)
	}
	if endDate != "" {
		end, err := time.Parse("2006-01-02", endDate)
		if err != nil {
			return nil, fmt.Errorf("endDate không hợp lệ: %w", err)
		}
		query += " AND report_date <= ?"
		args = append(args, end)
	}

	query += " ORDER BY khpo, report_date"

	var result []types.POExcelReport

	err = db.Raw(query, args...).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	// finalResult, err := fillMissingDates(result, startDate, endDate)
	// if err != nil {
	// 	return nil, err
	// }

	return result, nil

}

func (pr *poReportService) GetRawReport(khpo, startDate, endDate, factory string) ([]types.RawPOSaveReport, error) {
	databaseType, err := utils.GetDatabaseTypeByFactory(factory)
	if err != nil {
		return nil, err
	}

	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	query := `
	SELECT 
		R.id,
		R.combine_id,
		CONVERT(VARCHAR, R.report_date, 23) AS report_date,
		R.khpo, 
		R.ddbh,
		R.style_no, 
		R.color_code, 
		R.ship_id, 
		R.status, 
		R.quantity, 
		R.rm01, R.rm03, R.wip31, R.wip33, R.wip6, R.wip8, R.fg10, R.fg14
	FROM 
		po_daily P INNER JOIN po_daily_raw R ON P.id = R.combine_id
	WHERE 
		1=1
`

	var args []interface{}

	if khpo != "" {
		query += " AND P.khpo LIKE ?"
		args = append(args, "%"+khpo+"%")
	}
	if startDate != "" {
		start, err := time.Parse("2006-01-02", startDate)
		if err != nil {
			return nil, fmt.Errorf("startDate không hợp lệ: %w", err)
		}
		query += " AND P.report_date >= ?"
		args = append(args, start)
	}
	if endDate != "" {
		end, err := time.Parse("2006-01-02", endDate)
		if err != nil {
			return nil, fmt.Errorf("endDate không hợp lệ: %w", err)
		}
		query += " AND P.report_date <= ?"
		args = append(args, end)
	}

	query += " ORDER BY R.khpo, R.report_date"

	var result []types.RawPOSaveReport

	err = db.Raw(query, args...).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (pr *poReportService) MapReport(rawData []types.RawPOSaveReport, data []types.POExcelReport) []types.POExcelReport {

	dataMap := make(map[string][]types.RawPOSaveReport, len(data))

	for _, rawRow := range rawData {
		key := rawRow.Date + "_" + rawRow.KHPO + "_" + rawRow.StyleNo + "_" + rawRow.ColorCode + "_" + rawRow.ShipID

		if subList, exist := dataMap[key]; exist {
			subList = append(subList, rawRow)
			dataMap[key] = subList
		} else {
			newSubList := []types.RawPOSaveReport{rawRow}
			dataMap[key] = newSubList
		}
	}

	for index, dataRow := range data {
		key := dataRow.Date + "_" + dataRow.KHPO + "_" + dataRow.StyleNo + "_" + dataRow.ColorCode + "_" + dataRow.ShipID
		dataRow.RawPo = dataMap[key]
		data[index] = dataRow
	}

	return data
}

func (s *poReportService) UpdateReportWithReturnId(databaseType string, poReturnMap map[string]string, date string) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	for key, returnID := range poReturnMap {

		keyParams := strings.Split(key, "_")
		if len(keyParams) != 4 {
			return fmt.Errorf("key of ReturnID map does not contain 4 elements (KHPO, StyleNumber, ColorCode, ShipID)")
		}
		poNumber := keyParams[0]
		styleNumber := keyParams[1]
		colorCode := keyParams[2]
		shipId := keyParams[3]

		err := db.
			Model(&types.POSaveReport{}).
			Where("khpo = ?", poNumber).
			Where("style_no = ?", styleNumber).
			Where("color_code = ?", colorCode).
			Where("ship_id = ?", shipId).
			Where("report_date = ?", date).
			Update("return_id", returnID).Error

		if err != nil {
			log.Println("error update return ID at " + key + ": " + err.Error())
			return err
		}
	}

	return nil
}

func (s *poReportService) GetFGReportWithReturnID(databaseType string) ([]types.FGReport, error) {

	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	sql := `
		WITH FG AS (
			SELECT
				? AS Factory_Code,
				? AS Factory_Name,
				` + getPoTypeQuery(DDBH, "Y.DDBH") + `
				D.KHPO,
				CASE
					WHEN CHARINDEX('-', D.ARTICLE) > 0
						THEN SUBSTRING(D.ARTICLE, 1, CHARINDEX('-', D.ARTICLE) - 1)
					ELSE D.ARTICLE
				END AS style_number,
				CASE
					WHEN CHARINDEX('-', D.ARTICLE) > 0
						THEN SUBSTRING(D.ARTICLE, CHARINDEX('-', D.ARTICLE) + 1, LEN(D.ARTICLE))
					ELSE NULL
				END AS color_code,
				CASE
					WHEN CHARINDEX(' ', L.zwsm) <= 1 THEN ' '
					ELSE SUBSTRING(L.zwsm, 1, CHARINDEX(' ', L.zwsm) - 1)
				END AS ship_id,
				Y.DDBH,
				D.Dest,
				D.Pairs,

				-- FG10: tổng Qty cho SB 1,2,3,4
				SUM(CASE 
						WHEN Y.SB IN ('1','2','3','4') 
						THEN Y.Qty 
						ELSE 0 
					END) AS FG10_Qty,

				-- FG14: chỉ SB = 3
				SUM(CASE 
						WHEN Y.SB = '3'
						THEN Y.Qty
						ELSE 0
					END) AS FG14_Qty

			FROM YWCP AS Y
			LEFT JOIN DDZL AS D ON D.DDBH = Y.DDBH
			LEFT JOIN lbzls AS L ON L.lbdh = D.Dest AND L.lb = '13'
			WHERE
				Y.SB IN ('1', '2', '3', '4')   -- lọc tổng thể
				AND D.DDZT = 'Y'
				AND D.GSBH = ?
			GROUP BY
				Y.DDBH, D.KHPO, D.Pairs, D.Dest, D.ARTICLE, L.zwsm
		),

		DTD AS (
			SELECT *
			FROM (
				SELECT *,
					ROW_NUMBER() OVER (
						PARTITION BY khpo, style_no, color_code, ship_id
						ORDER BY report_date DESC
					) AS rn
				FROM po_daily
			) AS t
			WHERE rn = 1)

		SELECT
			FG.factory_code,
			FG.factory_name,
			FG.poType AS po_type,
			FG.KHPO,
			FG.DDBH,
			FG.style_number,
			FG.color_code,
			FG.ship_id,
			SUM(FG.Pairs) AS po_quantity,
			SUM(FG.FG10_Qty) AS factory_warehouse_fg10,
			DTD.fg10 as dtd_tracking_fg10,
			SUM(FG.FG14_Qty) AS factory_warehouse_fg14,
			DTD.fg14 as dtd_tracking_fg14,
			DTD.return_id
		FROM FG
		INNER JOIN DTD
			ON DTD.KHPO = FG.KHPO
				AND DTD.style_no = FG.style_number
				AND DTD.color_code = FG.color_code
				AND DTD.ship_id = FG.ship_id
		GROUP BY
			FG.factory_code,
			FG.factory_name,
			FG.poType,
			FG.KHPO,
			FG.DDBH,
			FG.style_number,
			FG.color_code,
			FG.ship_id,
			DTD.return_id,
			DTD.fg10,
			DTD.fg14
		ORDER BY
			FG.KHPO, FG.style_number, FG.color_code, FG.ship_id;
	`
	args := []interface{}{
		factoryCode,
		factoryName,
		GSBH,
	}

	var result []types.FGReport

	err = db.Raw(sql, args...).Scan(&result).Error
	if err != nil {
		return nil, err
	}

	return result, nil
}

func (pr *poReportService) GetDashboardResentPo(khpo, startDate, endDate, factory string) ([]types.POExcelReport, error) {

	databaseType, err := utils.GetDatabaseTypeByFactory(factory)
	if err != nil {
		return nil, err
	}

	result, err := repo.PoReportRepository.GetDashboardResentPo(khpo, startDate, endDate, databaseType)
	if err != nil {
		return nil, err
	}

	return result, nil
}
