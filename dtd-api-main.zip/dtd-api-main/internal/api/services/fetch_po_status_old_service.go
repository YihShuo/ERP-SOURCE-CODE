package services

import (
	"database/sql"
	"fmt"
	"strings"
	"web-api/internal/pkg/models/types"

	"gorm.io/gorm"
)

func (s *poStatusService) GetDailyPoStatusByStyleNameColorCodeList(databaseType, date string, styleNameColorCodeList []string) ([]types.DailyPoStatus, error) {
	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}

	tx := db.Begin()
	defer tx.Rollback()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
			panic(r)
		}
	}()

	poList := make([]string, 0)
	for _, item := range styleNameColorCodeList {
		parts := strings.Split(item, "-")
		if len(parts) != 2 {
			continue
		}
		styleNumber := parts[0]
		colorCode := parts[1]

		var poNumbers []string
		sql := `
			SELECT DISTINCT KHPO 
			FROM DDZL 
			WHERE CHARINDEX('-', Article) > 0
			AND LTRIM(RTRIM(SUBSTRING(Article, 1, CHARINDEX('-', Article) - 1))) = ?
			AND LTRIM(RTRIM(SUBSTRING(Article, CHARINDEX('-', Article) + 1, LEN(Article)))) = ?
			AND DDZT = 'Y'
			AND KHPO IS NOT NULL
			AND LTRIM(RTRIM(KHPO)) <> ''`
		if err := tx.Raw(sql, styleNumber, colorCode).Scan(&poNumbers).Error; err != nil {
			return nil, err
		}
		poList = append(poList, poNumbers...)
	}

	unique := make(map[string]struct{})
	newPOList := make([]string, 0)
	for _, po := range poList {
		po = strings.TrimSpace(po)
		if po == "" {
			continue
		}
		if _, exists := unique[po]; !exists {
			unique[po] = struct{}{}
			newPOList = append(newPOList, po)
		}
	}
	poList = newPOList
	// log.Println("poList", poList)
	if err := tx.Exec(`CREATE TABLE #TempPOList (KHPO NVARCHAR(50), StyleNumber NVARCHAR(50), ColorCode NVARCHAR(50))`).Error; err != nil {
		return nil, fmt.Errorf("failed to create temp table: %v", err)
	}

	for _, po := range poList {
		for _, item := range styleNameColorCodeList {
			parts := strings.Split(item, "-")
			if len(parts) != 2 {
				continue
			}
			styleNumber := strings.TrimSpace(parts[0])
			colorCode := strings.TrimSpace(parts[1])
			insertSQL := `INSERT INTO #TempPOList (KHPO, StyleNumber, ColorCode) VALUES (?, ?, ?)`
			if err := tx.Exec(insertSQL, po, styleNumber, colorCode).Error; err != nil {
				return nil, fmt.Errorf("failed to insert into temp table: %v", err)
			}
		}
	}

	poListSQL := BuildPoListSQL(poList)

	sqlTemplate := `
	SELECT
		CONVERT(VARCHAR(10), @date, 23) AS date,
		DDZL.KHPO AS poNumber,
		%s  
		@factoryCode AS factoryCode,  
		@factoryName AS factoryName,  
		'002' AS status,  
		'Normal' AS statusMessage,  
		SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,  
		xxzl.XieMing AS styleName,  
		SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,  
		CASE 
			WHEN DDZL.BUYNO LIKE '%s' THEN SUBSTRING(DDZL.BUYNO, 1, 3)
			ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
		END AS season,
		CASE 
			WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
			WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
			ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
		END AS shipId,
		YWCP.Qty AS poCompletionQuantity,
		DDZL.Pairs AS poQuantity,
		'1d' AS logType,
		kfzl.kfjc AS brand,
		CONVERT(VARCHAR, DDZL.ShipDate, 23) AS confirmXFDate,
		'stageCode' AS stageCode,
		0 AS completionQuantity,
		'sizeNumber' AS sizeNumber,
		0 AS sizeCompletionQuantity,
		0 AS sizeTargetQuantity,
		DDZL.DDBH AS DDBH

	FROM DDZL

	INNER JOIN #TempPOList tmp 
		ON DDZL.KHPO COLLATE Chinese_Taiwan_Stroke_CI_AS = tmp.KHPO
		AND SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) COLLATE Chinese_Taiwan_Stroke_CI_AS = tmp.StyleNumber
		AND SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) COLLATE Chinese_Taiwan_Stroke_CI_AS = tmp.ColorCode

	LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
	LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
	LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
	LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
	LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing AND xxzl.SheHao = DDZL.SheHao
	LEFT JOIN (
		SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty 
		FROM YWCP 
		WHERE YWCP.SB = 1 
		GROUP BY YWCP.DDBH
	) YWCP ON YWCP.DDBH = DDZL.DDBH
	LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'

	WHERE
		DDZL.KHPO IN (%s)
		AND DDZL.DDZT = 'Y'
		AND NOT (
			DDZL.DDBH LIKE '%s' 
			OR RIGHT(DDZL.DDBH, 2) = 'BG'
			OR DDZL.DDBH LIKE '%s'
		)

	GROUP BY 
		DDZL.DDBH, DDZL.KHPO, DDZL.Article, 
		YWCP.Qty, DDZL.Pairs, 
		kfzl.kfjc, DDZL.ShipDate, 
		xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO
`

	sqlQuery := fmt.Sprintf(sqlTemplate,
		getPoTypeQuery(DDBH, "DDZL.DDBH"),
		"%PR%",    // %s #3 (PO 季節提取)
		poListSQL, // %s #5
		"%-B%",
		"DHB%",
	)

	queryParams := map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"date":        date,
	}

	var poStatusData []types.DailyPoStatus
	err = tx.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
	if err != nil {
		return nil, err
	}
	tx.Commit()

	for i := range poStatusData {
		value := &poStatusData[i]
		value.MilestoneList = []types.Milestone{}
		sizeMapKey := value.StyleNumber + "-" + value.ColorCode
		milestoneListData, err := GetMilestoneData(db, value.PoNumber, GSBH, sizeMapKey, value.DDBH, date)
		if err != nil {
			return nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
		}
		if len(milestoneListData) > 0 {
			merged := mergeMilestones(milestoneListData)
			merged = fillMissingStages(merged)
			sortMilestones(merged)
			resolveConflictingData(merged)
			value.MilestoneList = merged
		}
		value.PoCompletionQuantity = updatePoCompletionQuantity(value.MilestoneList, value.PoCompletionQuantity)
		value.Status = updatePoStatus(value.PoQuantity, value.PoCompletionQuantity)
	}

	newPoStatusData := mergeDuplicatePOs(poStatusData)
	summaries := calculateInventoryAndGroupByPoType(newPoStatusData)

	err = exportInventorySummaryExcel(summaries, "inventory_summary.xlsx")
	if err != nil {
		fmt.Println("Excel export failed:", err)
	} else {
		fmt.Println("Excel export done!")
	}

	return newPoStatusData, nil
}
func queryOldFGStage(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	query := `
	WITH TargetSizeQty AS (
		SELECT ddzls.CC AS sizeNumber, SUM(ddzls.Quantity) AS targetQuantity
		FROM ddzls
		INNER JOIN ddzl ON ddzls.DDBH = ddzl.DDBH
		WHERE ddzl.KHPO = @khpo
		  AND ddzl.ARTICLE = @article
		  AND ddzl.DDBH = @DDBH
		GROUP BY ddzls.CC
	),

	-- FG10 來源：YWCP (1,2,3,4,5) + YWCPOld (3)
	FG10Data AS (
		SELECT 
			YWBZPOS.DDCC AS sizeNumber,
			SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS
		LEFT JOIN ddzl 
			ON YWBZPOS.DDBH = ddzl.DDBH
		INNER JOIN YWCP 
			ON YWBZPOS.DDBH = YWCP.DDBH 
		WHERE ddzl.DDBH = @orderNumber
		AND YWCP.SB IN (1,2,3,4,5)
		GROUP BY YWBZPOS.DDCC

		UNION ALL

		SELECT YWBZPOS.DDCC AS sizeNumber, SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS
		LEFT JOIN YWCPOld ON YWBZPOS.DDBH = YWCPOld.DDBH AND YWBZPOS.XH = YWCPOld.XH
		LEFT JOIN ddzl ON YWBZPOS.DDBH = ddzl.DDBH
		WHERE ddzl.GSBH = @gsbh
		  AND ddzl.KHPO = @khpo
		  AND ddzl.ARTICLE = @article
		  AND ddzl.DDBH = @DDBH
		  AND YWCPOld.SB = 3
		GROUP BY YWBZPOS.DDCC
	),

	-- FG14 來源：YWCP (3) + YWCPOld (3)
	FG14Data AS (
		SELECT YWBZPOS.DDCC AS sizeNumber, SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS
		LEFT JOIN YWCP ON YWBZPOS.DDBH = YWCP.DDBH AND YWBZPOS.XH = YWCP.XH
		LEFT JOIN ddzl ON YWBZPOS.DDBH = ddzl.DDBH
		WHERE ddzl.GSBH = @gsbh
		  AND ddzl.KHPO = @khpo
		  AND ddzl.ARTICLE = @article
		  AND ddzl.DDBH = @DDBH
		  AND YWCP.SB = 3
		  AND CONVERT(date, YWCP.EXEDate) <= @date
		GROUP BY YWBZPOS.DDCC

		UNION ALL

		SELECT YWBZPOS.DDCC AS sizeNumber, SUM(YWBZPOS.Qty) AS qty
		FROM YWBZPOS
		LEFT JOIN YWCPOld ON YWBZPOS.DDBH = YWCPOld.DDBH AND YWBZPOS.XH = YWCPOld.XH
		LEFT JOIN ddzl ON YWBZPOS.DDBH = ddzl.DDBH
		WHERE ddzl.GSBH = @gsbh
		  AND ddzl.KHPO = @khpo
		  AND ddzl.ARTICLE = @article
		  AND ddzl.DDBH = @DDBH
		  AND YWCPOld.SB = 3
		GROUP BY YWBZPOS.DDCC
	),

	-- 聚合每個 stage 資料（FG10 / FG14）
	FG10Agg AS (
		SELECT fd.sizeNumber, SUM(fd.qty) AS sizeCompletionQuantity
		FROM FG10Data fd
		GROUP BY fd.sizeNumber
	),
	FG14Agg AS (
		SELECT fd.sizeNumber, SUM(fd.qty) AS sizeCompletionQuantity
		FROM FG14Data fd
		GROUP BY fd.sizeNumber
	)

	-- 最終合併輸出（兩個 stage 各自一列）
	SELECT 'FG10' AS stageCode, 0 AS completionQuantity, a.sizeNumber,
	       ISNULL(a.sizeCompletionQuantity, 0) AS sizeCompletionQuantity,
	       ISNULL(tq.targetQuantity, 0) AS sizeTargetQuantity
	FROM FG10Agg a
	LEFT JOIN TargetSizeQty tq ON a.sizeNumber = tq.sizeNumber

	UNION ALL

	SELECT 'FG14' AS stageCode, 0 AS completionQuantity, b.sizeNumber,
	       ISNULL(b.sizeCompletionQuantity, 0) AS sizeCompletionQuantity,
	       ISNULL(tq.targetQuantity, 0) AS sizeTargetQuantity
	FROM FG14Agg b
	LEFT JOIN TargetSizeQty tq ON b.sizeNumber = tq.sizeNumber
	;
	`

	var results []StageResult
	err := db.Raw(query,
		sql.Named("khpo", p.KHPO),
		sql.Named("date", p.DATE),
		sql.Named("article", p.ARTICLE),
		sql.Named("DDBH", p.DDBH),
		sql.Named("gsbh", p.GSBH),
	).Scan(&results).Error
	return results, err
}
func queryAllStagesWithOldFG(db *gorm.DB, p StageQueryParam) ([]StageResult, error) {
	var allResults []StageResult

	rm, err := queryRMStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, rm...)

	wip, err := queryWIPStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, wip...)

	fg, err := queryOldFGStage(db, p)
	if err != nil {
		return nil, err
	}
	allResults = append(allResults, fg...)

	return allResults, nil
}

// func (s *poStatusService) GetDailyPoStatusCancelByRyList(databaseType, date string, ddbhMap map[string]types.CancelPoInfo) ([]types.DailyPoStatus, error) {

// 	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
// 	if err != nil {
// 		return nil, err
// 	}

// 	poListSQL := BuildPoListSQL(Keys(ddbhMap))

// 	sqlTemplate := `
// 		SELECT
// 			CONVERT(VARCHAR(10), @date, 23) AS date,
// 			DDZL.KHPO AS poNumber,
// 			%s
// 			@factoryCode AS factoryCode,
// 			@factoryName AS factoryName,
// 			'002' AS status,
// 			'Normal' AS statusMessage,
// 			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
// 			xxzl.XieMing AS styleName,
// 			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
// 			CASE
// 				WHEN DDZL.BUYNO LIKE '%s' THEN SUBSTRING(DDZL.BUYNO, 1, 3)
// 				ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
// 			END AS season,
// 			CASE
// 				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
// 				WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' '
// 				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
// 			END AS shipId,
// 			YWCP.Qty AS poCompletionQuantity,
// 			DDZL.Pairs AS poQuantity,
// 			'1d' AS logType,
// 			kfzl.kfjc AS brand,
// 			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
// 			'stageCode' AS stageCode,
// 			0 AS completionQuantity,
// 			'sizeNumber' AS sizeNumber,
// 			0 AS sizeCompletionQuantity,
// 			0 AS sizeTargetQuantity,
// 			DDZL.DDBH AS DDBH
// 		FROM DDZL
// 		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
// 		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
// 		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
// 		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
// 		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
// 		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP
// 			ON YWCP.DDBH = DDZL.DDBH
// 		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
// 		WHERE DDZL.DDBH IN (%s)
// 		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO;
// 	`

// 	sqlQuery := fmt.Sprintf(sqlTemplate,
// 		getPoTypeQuery(DDBH, "DDZL.DDBH"),
// 		"%PR%",
// 		poListSQL,
// 	)

// 	queryParams := map[string]interface{}{
// 		"factoryCode": factoryCode,
// 		"factoryName": factoryName,
// 		"date":        date,
// 	}

// 	// 查詢 DailyPoStatus 資料
// 	var poStatusData []types.DailyPoStatus
// 	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
// 	if err != nil {
// 		return nil, err
// 	}

// 	// Cache size list from Decker
// 	deckerSizeList := make(map[string]string)

// 	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
// 	for i := range poStatusData {

// 		value := &poStatusData[i]

// 		// 初始化 MilestoneList
// 		value.MilestoneList = []types.Milestone{}

// 		sizeMapKey := value.StyleNumber + "-" + value.ColorCode

// 		println("Processing PO: ", value.DDBH, value.PoNumber)

// 		// 初始化 MilestoneList
// 		value.MilestoneList = []types.Milestone{}

// 		// 獲取 Milestone 資料
// 		milestoneListData, err := GetMilestoneDataWithoutFGStage(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH)
// 		if err != nil {
// 			return nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
// 		}

// 		// 如果有 Milestone 資料，才填充到 MilestoneList
// 		if len(milestoneListData) > 0 {
// 			milestoneMap := make(map[string]*types.Milestone)
// 			for _, ml := range milestoneListData {
// 				// 根據 StageCode 轉換
// 				switch ml.StageCode {
// 				case "C":
// 					ml.StageCode = "WIP3-1"
// 				case "O":
// 					ml.StageCode = "WIP3-3"
// 				case "S":
// 					ml.StageCode = "WIP6"
// 				case "A":
// 					ml.StageCode = "WIP8"
// 				}

// 				if milestone, exists := milestoneMap[ml.StageCode]; exists {
// 					milestone.CompletionQuantity += ml.CompletionQuantity
// 					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
// 				} else {
// 					milestoneMap[ml.StageCode] = &types.Milestone{
// 						StageCode:          ml.StageCode,
// 						CompletionQuantity: ml.CompletionQuantity,
// 						SizeList:           ml.SizeList,
// 					}
// 				}
// 			}

// 			var newMilestoneListData []types.Milestone
// 			for _, milestone := range milestoneMap {
// 				newMilestoneListData = append(newMilestoneListData, *milestone)
// 			}

// 			newMilestoneListData = fillMissingStages(newMilestoneListData)
// 			sortMilestones(newMilestoneListData)
// 			AdjustQtyByStage(newMilestoneListData)
// 			newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
// 			newMilestoneListData = fillEmptyStage(newMilestoneListData)
// 			value.MilestoneList = newMilestoneListData
// 		}

// 		err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(databaseType), deckerSizeList)
// 		if err != nil {
// 			return nil, fmt.Errorf("error when get size list from deckers")
// 		}

// 		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
// 		for _, milestone := range value.MilestoneList {

// 			// Get last size string from size map and check if exist
// 			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 				// Change all size number: add last size string to the end
// 				for index := range milestone.SizeList {

// 					size := &milestone.SizeList[index]

// 					// Ignore empty size number
// 					if len(size.SizeNumber) > 0 {

// 						// Get last character in size number
// 						lastCharIndex := len(size.SizeNumber) - 1
// 						checkingChar := size.SizeNumber[lastCharIndex]

// 						// Check if it was added or not
// 						if !unicode.IsLetter(rune(checkingChar)) {

// 							// Add to the end
// 							size.SizeNumber += lastSizeStr
// 						}
// 					}
// 				}
// 			}

// 			// Add PO completion Qty = WIP8's Qty
// 			if milestone.StageCode == "WIP8" {
// 				value.PoCompletionQuantity = milestone.CompletionQuantity
// 			}
// 		}

// 		if value.PoCompletionQuantity == value.PoQuantity {
// 			value.Status = "001"
// 		}

// 		// Replace new KHPO with old KHPO
// 		if oldPoInfo, exist := ddbhMap[value.DDBH]; exist {
// 			value.PoNumber = oldPoInfo.PoNumber
// 			value.ShipID = oldPoInfo.ShipId
// 		}

// 	}

// 	return poStatusData, nil
// }
