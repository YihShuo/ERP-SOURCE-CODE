package services

import (
	"fmt"
	"time"
	"web-api/internal/pkg/models/types"
)

type outputsFGService struct {
	*BaseService
}

var OutputsFGService = &outputsFGService{}

func (s *outputsFGService) GetDeckerOutputsFG(databaseType, date string) ([]types.DeckerOutputsFG, error) {

	db, factoryCode, factoryName, GSBH, _, err := setupDatabase(databaseType)
	if err != nil {
		return nil, fmt.Errorf("failed to setup database connection: %v", err)
	}

	dateTimeFormat := "2006-01-02 15:04:05"
	parsedTime, err := time.Parse(dateTimeFormat, date)
	if err != nil {
		parsedTime, err = time.Parse("2006-01-02", date)
		if err != nil {
			return nil, fmt.Errorf("error parsing time: %v", err)
		}
	}

	// Subtract 1 hour
	modifiedTime := parsedTime.Add(-time.Hour)
	modifiedHour := modifiedTime.Format("15")
	offset := "+07:00"
	modifiedFormatter := "2006-01-02T15:04:05" + offset
	startTime := modifiedTime.Add(time.Hour*7 + time.Minute*30).Format(modifiedFormatter)
	endTime := modifiedTime.Add(time.Hour*16 + time.Minute*59 + time.Second*59).Format(modifiedFormatter)

	// SQL query to get data

	sqlGetDatas := `
	SELECT '' AS startTime, 
		'' AS endTime, 
		@factoryCode AS factoryCode, 
		@factoryName AS factoryName, 
		YWCP.SB AS stageCode, 
		DDZL.KHPO AS poNumber, 
		'PO' AS poType, 
		SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber, 
		xxzl.XieMing AS styleName, 
		SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode, 
		CASE 
			WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
			WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
			ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
		END AS shipId, 
		YWBZPOS.DDCC AS sizeNumber, 
		SUM(YWCP.Qty) AS output, 
		'1d' AS logType, 
		kfzl.kfjc AS brand 
	FROM YWCP 
			LEFT JOIN DDZL ON DDZL.DDBH = YWCP.DDBH 
			LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh 
			LEFT JOIN YWBZPOS ON YWCP.DDBH = YWBZPOS.DDBH AND YWCP.XH = YWBZPOS.XH 
			LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
			LEFT JOIN xxzl ON DDZL.XieXing = xxzl.XieXing AND DDZL.SheHao = xxzl.SheHao 
	WHERE CONVERT(VARCHAR, YWCP.INDATE, 23) = CONVERT(DATE, @date)
	AND DDZL.GSBH = @GSBH 
	AND SB = 1 
	GROUP BY YWCP.SB, DDZL.KHPO, DDZL.DDGB, xxzl.XieMing, DDZL.KHPO, DDZL.Pairs, kfzl.kfjc, DDZL.ARTICLE, DDZL.DDBH, 
			YWBZPOS.DDCC, lbzls.zwsm 
	UNION ALL 
	SELECT '' AS startTime, 
		'' AS endTime, 
		@factoryCode AS factoryCode, 
		@factoryName AS factoryName, 
		YWCP.SB AS stageCode, 
		DDZL.KHPO AS poNumber, 
		'PO' AS poType, 
		SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber, 
		xxzl.XieMing AS styleName, 
		SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode, 
		CASE 
			WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' ' 
			WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' ' 
			ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) 
		END AS shipId, 
		YWBZPOS.DDCC AS sizeNumber, 
		SUM(YWCP.Qty) AS output, 
		'1d' AS logType, 
		kfzl.kfjc AS brand 
	FROM YWCP 
			LEFT JOIN DDZL ON DDZL.DDBH = YWCP.DDBH 
			LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh 
			LEFT JOIN YWBZPOS ON YWCP.DDBH = YWBZPOS.DDBH AND YWCP.XH = YWBZPOS.XH 
			LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13' 
			LEFT JOIN xxzl ON DDZL.XieXing = xxzl.XieXing AND DDZL.SheHao = xxzl.SheHao 
	WHERE CONVERT(VARCHAR, YWCP.EXEDATE, 23) = CONVERT(DATE, @date)
	AND DDZL.GSBH = @GSBH 
	AND SB = 3 
	GROUP BY YWCP.SB, DDZL.KHPO, DDZL.DDGB, xxzl.XieMing, DDZL.KHPO, DDZL.Pairs, kfzl.kfjc, DDZL.ARTICLE, DDZL.DDBH, 
			YWBZPOS.DDCC, lbzls.zwsm;
	`

	// Create query parameters map
	params := map[string]interface{}{
		"modifiedHour": modifiedHour,
		"factoryCode":  factoryCode,
		"factoryName":  factoryName,
		"GSBH":         GSBH,
		"date":         date,
	}

	// 獲取FG資料
	var results []types.DeckerOutputsFG
	err = db.Raw(sqlGetDatas, params).Scan(&results).Error
	if err != nil {
		fmt.Println("error:", err)
	}

	// Process results (add startTime, endTime, and modify stageCode)
	for i := range results {
		results[i].StartTime = startTime
		results[i].EndTime = endTime

		switch results[i].StageCode {
		case "1":
			results[i].StageCode = "FG10"
		case "3":
			results[i].StageCode = "FG14"
		}
	}

	return results, nil
}
