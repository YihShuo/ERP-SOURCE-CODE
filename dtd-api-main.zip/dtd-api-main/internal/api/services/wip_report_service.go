package services

import (
	"fmt"
	"log"
	"strings"
	"time"
	"web-api/internal/pkg/models/types"

	"gorm.io/gorm"
)

type WIPReportService struct{}

var WIPReportServiceInstance WIPReportService

func (w *WIPReportService) SaveWIPHourlyReport(databaseType string, wipList []types.DeckerOutput) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	return db.Transaction(func(tx *gorm.DB) error {
		for _, wip := range wipList {

			if err := tx.Create(&wip).Error; err != nil {
				key := strings.Join([]string{wip.StartTime, wip.EndTime, wip.ProductionLineNumber, wip.FactoryWorkOrderNumber, wip.SizeNumber}, "__")
				log.Printf("Overwriting %s caused by: %v\n", key, err)

				condition := types.DeckerOutput{
					StartTime:              wip.StartTime,
					EndTime:                wip.EndTime,
					FactoryWorkOrderNumber: wip.FactoryWorkOrderNumber,
					SizeNumber:             wip.SizeNumber,
					ProductionLineNumber:   wip.ProductionLineNumber,
				}

				err = tx.Where(&condition).Delete(&types.DeckerOutput{}).Error
				if err != nil {
					log.Printf("error when delete WIP to overwrite report: %v\n", err)
					continue
				} else {
					log.Printf("%v was deleted\n", key)
				}
				err = tx.Create(&wip).Error
				if err != nil {
					log.Printf("Ignore %s caused by: %v\n", key, err)
					continue
				} else {
					log.Printf("Overwriting %s success\n", key)
				}
			}
		}
		return nil // luôn commit
	})
}

func (w *WIPReportService) UpdateWIPReturnId(databaseType string, wipReturnMap map[string]string) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	for key, returnID := range wipReturnMap {

		keyParams := strings.Split(key, "__")
		if len(keyParams) != 5 {
			return fmt.Errorf("key of ReturnID map does not contain 5 elements (StartTime, EndTime, ProductionLineNumber, FactoryWorkOrderNumber, SizeNumber)")
		}

		condition := types.DeckerOutput{
			StartTime:              keyParams[0],
			EndTime:                keyParams[1],
			ProductionLineNumber:   keyParams[2],
			FactoryWorkOrderNumber: keyParams[3],
			SizeNumber:             keyParams[4],
		}

		err := db.Model(&condition).Where(&condition).Update("returnId", returnID).Error

		if err != nil {
			log.Println("error update return ID at " + key + ": " + err.Error())
		}
	}
	return nil
}

func (w *WIPReportService) RemoveAndBackupWIPHourly(databaseType string, thresholdDay int) error {
	db, _, _, _, _, err := setupDatabase(databaseType)
	if err != nil {
		return err
	}

	thresholdDate := time.Now().AddDate(0, 0, -thresholdDay)

	return db.Transaction(func(tx *gorm.DB) error {
		var records []types.DeckerOutput

		// 1. Lấy dữ liệu cần xoá
		if err := tx.
			Where("UserDate < ?", thresholdDate.Format("2006-01-02")).
			Find(&records).Error; err != nil {
			return err
		}

		if len(records) == 0 {
			return nil
		}

		// 2. Insert sang bảng backup theo batch
		// Tính toán batchSize an toàn: 2100 / số_lượng_cột_của_struct
		// Giả sử struct có 20 cột -> 2100 / 20 = 105. Ta chọn mốc an toàn là 100.
		batchSize := 100
		if err := tx.
			Table("wip_hourly_his").
			CreateInBatches(&records, batchSize).Error; err != nil {
			return fmt.Errorf("error insert backup: %w", err)
		}
		// -----------------

		// 3. Xoá dữ liệu gốc
		if err := tx.
			Where("UserDate < ?", thresholdDate.Format("2006-01-02")).
			Delete(&types.DeckerOutput{}).Error; err != nil {
			return fmt.Errorf("error delete original: %w", err)
		}

		return nil
	})
}
