package services

import (
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"
	"unicode"
	"web-api/internal/pkg/models/types"

	"github.com/xuri/excelize/v2"
)

var stageOrder = map[string]int{
	"RM0-1":  0,
	"RM0-3":  1,
	"WIP3-1": 2,
	"WIP3-3": 3,
	"WIP6":   4,
	"WIP8":   5,
	"FG10":   6,
	"FG14":   7,
}

type PoInventorySummary struct {
	StyleNumber string
	ColorCode   string
	PoType      string
	Inventory   int
}

func resolveConflictingData(milestones []types.Milestone) []types.Milestone {
	for i := 1; i < len(milestones); i++ {

		if milestones[i-1].CompletionQuantity < milestones[i].CompletionQuantity {

			milestones[i-1].CompletionQuantity = milestones[i].CompletionQuantity
			milestones[i-1].SizeList = milestones[i].SizeList

			for j := i - 2; j >= 0 && milestones[j].CompletionQuantity < milestones[j+1].CompletionQuantity; j-- {

				milestones[j].CompletionQuantity = milestones[j+1].CompletionQuantity
				milestones[j].SizeList = milestones[j+1].SizeList
			}
		}
	}
	return milestones
}

func AdjustQtyByStage(milestones []types.Milestone) []types.Milestone {

	relations := map[string][]string{
		"RM0-1":  {"RM0-3"},
		"RM0-3":  {"WIP3-1", "WIP3-3"},
		"WIP3-1": {"WIP6"},
		"WIP6":   {"WIP8"},
		"WIP3-3": {"WIP8"},
		"WIP8":   {"FG10"},
		"FG10":   {"FG14"},
	}

	milestoneMap := getMilestoneMap(milestones)

	changed := true
	for changed {
		changed = false

		for from, tos := range relations {
			fromStage, ok := milestoneMap[from]
			if !ok {
				continue
			}

			for _, to := range tos {
				toStage, ok := milestoneMap[to]
				if !ok {
					continue
				}

				if toStage.CompletionQuantity > fromStage.CompletionQuantity {
					fromStage.CompletionQuantity = toStage.CompletionQuantity
					fromStage.SizeList = toStage.SizeList
					changed = true
				}
			}
		}
	}

	return milestones
}

func getMilestoneMap(milestones []types.Milestone) map[string]*types.Milestone {
	m := make(map[string]*types.Milestone)
	for i := range milestones {
		m[milestones[i].StageCode] = &milestones[i]
	}
	return m
}

func sortMilestones(milestones []types.Milestone) []types.Milestone {
	sort.Slice(milestones, func(i, j int) bool {
		return stageOrder[milestones[i].StageCode] < stageOrder[milestones[j].StageCode]
	})
	return milestones
}

func fillEmptyStage(milestoneList []types.Milestone) []types.Milestone {
	var checkMap = make(map[string]bool, len(milestoneList))
	var newMilestone types.Milestone
	for _, milestone := range milestoneList {
		if milestone.StageCode == "RM0-1" {
			newMilestone = milestone
		}
		checkMap[milestone.StageCode] = true
	}

	for stageCode := range stageOrder {
		if _, exist := checkMap[stageCode]; !exist {

			newSizeList := []types.Size{}

			for _, size := range newMilestone.SizeList {
				size.SizeCompletionQuantity = 0
				newSizeList = append(newSizeList, size)
			}
			newMilestone.SizeList = newSizeList
			newMilestone.StageCode = stageCode
			newMilestone.CompletionQuantity = 0

			milestoneList = append(milestoneList, newMilestone)
		}
	}
	return milestoneList
}

func RemoveStageWithEmptySizeList(milestones []types.Milestone) []types.Milestone {
	var result []types.Milestone
	for _, milestone := range milestones {
		if milestone.StageCode == "" {
			continue
		}
		if len(milestone.SizeList) == 1 && milestone.SizeList[0].SizeNumber == "" {
			continue
		}
		result = append(result, milestone)
	}

	return result
}

func RemovePo(poList []types.DailyPoStatus, poToRemove []string) []types.DailyPoStatus {

	poMap := make(map[string]bool)
	for _, po := range poToRemove {
		poMap[po] = true
	}

	result := poList[:0]
	for _, po := range poList {
		if !poMap[po.PoNumber] {
			result = append(result, po)
		}
	}
	return result
}

// Hàm điền các stage còn thiếu bằng cách copy từ stage có Qty cao nhất
func fillMissingStages(input []types.Milestone) []types.Milestone {
	// Tạo map tra cứu stage đã có
	existing := make(map[string]types.Milestone)
	maxOrder := -1

	for _, item := range input {
		existing[item.StageCode] = item
		if order, ok := stageOrder[item.StageCode]; ok && order > maxOrder {
			maxOrder = order
		}
	}

	// Fill các stage còn thiếu trước maxOrder
	for stage, order := range stageOrder {
		milestone, existed := existing[stage]
		if order < maxOrder && !existed {
			input = append(input, copyMilestone(milestone, stage))
		}
	}

	return input
}

func copyMilestone(original types.Milestone, newStageCode string) types.Milestone {
	var newMilestone types.Milestone
	data, _ := json.Marshal(original)

	_ = json.Unmarshal(data, &newMilestone)
	newMilestone.StageCode = newStageCode

	return newMilestone
}

func mergeDuplicatePOs(poList []types.DailyPoStatus) []types.DailyPoStatus {

	result := []types.DailyPoStatus{}
	poIndexMap := make(map[string]int)

	normalize := func(s string) string {
		return strings.TrimSpace(s)
	}

	for _, po := range poList {

		key := normalize(po.PoNumber) + "_" +
			normalize(po.ColorCode) + "_" +
			normalize(po.StyleNumber) + "_" +
			normalize(po.ShipID)

		if idx, exists := poIndexMap[key]; exists {

			existing := &result[idx]

			existing.PoQuantity += po.PoQuantity
			existing.PoCompletionQuantity += po.PoCompletionQuantity

			stageMap := make(map[string]*types.Milestone)

			for i := range existing.MilestoneList {
				ms := &existing.MilestoneList[i]
				stageMap[ms.StageCode] = ms
			}

			for _, newMs := range po.MilestoneList {

				if existingMs, found := stageMap[newMs.StageCode]; found {

					existingMs.CompletionQuantity += newMs.CompletionQuantity
					existingMs.SizeList = mergeSizeLists(existingMs.SizeList, newMs.SizeList)

				} else {

					existing.MilestoneList = append(existing.MilestoneList, newMs)

					stageMap[newMs.StageCode] =
						&existing.MilestoneList[len(existing.MilestoneList)-1]
				}
			}

		} else {

			poIndexMap[key] = len(result)
			result = append(result, po)
		}
	}

	return result
}

func mergeSizeLists(original []types.Size, incoming []types.Size) []types.Size {
	// Map contain sizeNo -> index of it in slice
	indexByKey := make(map[string]int, len(original))
	var result []types.Size

	normalize := func(s string) string {
		return strings.ToUpper(strings.TrimSpace(s))
	}

	// Add all sizeNo of first size list to map
	for i, size := range original {
		result = append(result, size)
		key := normalize(size.SizeNumber)
		if key == "" {
			continue
		}
		indexByKey[key] = i
	}

	// Handle second size list
	for _, size := range incoming {
		key := normalize(size.SizeNumber)

		// Skip empty sizeNo
		if key == "" {
			continue
		}

		// If sizeNo exist in first size list increase quantity
		if idx, existed := indexByKey[key]; existed {
			result[idx].SizeCompletionQuantity += size.SizeCompletionQuantity
			result[idx].SizeTargetQuantity += size.SizeTargetQuantity
		} else {
			// If it doesn't, add it to first size list
			result = append(result, size)
			// Also add to key map
			indexByKey[key] = len(result) - 1
		}
	}
	return result
}

// SortByTemplate sắp xếp input theo thứ tự xuất hiện trong template.
// Các phần tử không có trong template sẽ được đưa ra cuối cùng (theo thứ tự ban đầu).
func SortByTemplate(input []types.POExcelReport, template []string) []types.POExcelReport {
	// Tạo bản đồ vị trí từ template
	indexMap := make(map[string]int, len(template))
	for i, poNumber := range template {
		indexMap[poNumber] = i
	}

	// Sao chép slice để không làm thay đổi input gốc
	sorted := make([]types.POExcelReport, len(input))
	copy(sorted, input)

	// Sắp xếp theo thứ tự trong template
	sort.SliceStable(sorted, func(i, j int) bool {
		indexI, okI := indexMap[sorted[i].KHPO]
		if !okI {
			indexI = len(template) + 1
		}
		indexJ, okJ := indexMap[sorted[j].KHPO]
		if !okJ {
			indexJ = len(template) + 1
		}
		return indexI < indexJ
	})

	return sorted
}

func calculateInventoryAndGroupByPoType(dailyPoStatus []types.DailyPoStatus) []PoInventorySummary {
	groupMap := make(map[string]map[string]int)

	for _, po := range dailyPoStatus {
		key := fmt.Sprintf("%s-%s", po.StyleNumber, po.ColorCode)

		if _, exists := groupMap[key]; !exists {
			groupMap[key] = make(map[string]int)
		}

		fg10 := 0
		fg14 := 0

		for _, milestone := range po.MilestoneList {
			switch milestone.StageCode {
			case "FG10":
				fg10 += milestone.CompletionQuantity
			case "FG14":
				fg14 += milestone.CompletionQuantity
			}
		}

		diff := fg10 - fg14
		if diff > 0 {
			fmt.Printf("PoNumber:\t%-20s | Diff:\t%d\\n", po.PoNumber, diff)
		}

		groupMap[key][po.PoType] += diff
	}

	// 平展 groupMap 到 slice
	var summaries []PoInventorySummary
	for key, poTypeMap := range groupMap {
		parts := strings.Split(key, "-")
		styleNumber := parts[0]
		colorCode := parts[1]

		for poType, qty := range poTypeMap {
			summaries = append(summaries, PoInventorySummary{
				StyleNumber: styleNumber,
				ColorCode:   colorCode,
				PoType:      poType,
				Inventory:   qty,
			})
		}
	}

	return summaries
}

func exportInventorySummaryExcel(summaries []PoInventorySummary, filePath string) error {
	var f *excelize.File
	var err error

	sheet := "Sheet1"

	// 判斷檔案是否存在
	if _, err = os.Stat(filePath); err == nil {
		// 存在就打開
		f, err = excelize.OpenFile(filePath)
		if err != nil {
			return fmt.Errorf("failed to open existing file: %w", err)
		}
	} else if os.IsNotExist(err) {
		// 不存在就新建
		f = excelize.NewFile()
		f.NewSheet(sheet)
		// 新檔要寫標題列
		f.SetCellValue(sheet, "A1", "StyleName")
		f.SetCellValue(sheet, "B1", "ColorCode")
		f.SetCellValue(sheet, "C1", "POType")
		f.SetCellValue(sheet, "D1", "FG10-FG14")
	} else {
		// 其他錯誤
		return fmt.Errorf("failed to check file: %w", err)
	}

	// 找到最後一行
	rows, err := f.GetRows(sheet)
	if err != nil {
		return fmt.Errorf("failed to get rows: %w", err)
	}
	startRow := len(rows) + 1 // 從最後一行+1 開始

	// 寫入資料
	for i, s := range summaries {
		row := startRow + i
		f.SetCellValue(sheet, fmt.Sprintf("A%d", row), s.StyleNumber)
		f.SetCellValue(sheet, fmt.Sprintf("B%d", row), s.ColorCode)
		f.SetCellValue(sheet, fmt.Sprintf("C%d", row), s.PoType)
		f.SetCellValue(sheet, fmt.Sprintf("D%d", row), s.Inventory)
	}

	// 儲存
	if err := f.SaveAs(filePath); err != nil {
		return fmt.Errorf("failed to save file: %w", err)
	}
	return nil
}
func mapFactorySizeToDeckersSize(milestones []types.Milestone, deckerSizeList map[string]string, sizeMapKey string) {
	for i := range milestones {
		milestone := &milestones[i]

		// 處理 Size 字尾
		if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {
			for j := range milestone.SizeList {
				size := &milestone.SizeList[j]
				if len(size.SizeNumber) > 0 {
					lastChar := size.SizeNumber[len(size.SizeNumber)-1]
					if !unicode.IsLetter(rune(lastChar)) {
						size.SizeNumber += lastSizeStr
					}
				}
			}
		}
	}
}

func updatePoCompletionQuantity(milestones []types.Milestone, PoCompletionQuantity int) int {
	for _, milestone := range milestones {
		if milestone.StageCode == "WIP8" {
			return milestone.CompletionQuantity
		}
	}
	return PoCompletionQuantity
}

func updatePoStatus(PoQuantity int, PoCompletionQuantity int) string {
	if PoCompletionQuantity == PoQuantity {
		return "001"
	}
	return "002"
}

func normalizeStageCode(code string) string {
	switch code {
	case "C":
		return "WIP3-1"
	case "O":
		return "WIP3-3"
	case "S":
		return "WIP6"
	case "A":
		return "WIP8"
	default:
		return code
	}
}

func mergeMilestones(milestones []types.Milestone) []types.Milestone {
	milestoneMap := make(map[string]*types.Milestone)

	for _, ml := range milestones {
		stageCode := normalizeStageCode(ml.StageCode)

		if existing, ok := milestoneMap[stageCode]; ok {
			existing.CompletionQuantity += ml.CompletionQuantity
			existing.SizeList = append(existing.SizeList, ml.SizeList...)
		} else {
			// 要記得 copy 值，不要用 ml 的 pointer
			milestoneMap[stageCode] = &types.Milestone{
				StageCode:          stageCode,
				CompletionQuantity: ml.CompletionQuantity,
				SizeList:           ml.SizeList,
			}
		}
	}

	var result []types.Milestone
	for _, milestone := range milestoneMap {
		result = append(result, *milestone)
	}
	return result
}
