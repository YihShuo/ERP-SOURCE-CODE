package services

import "web-api/internal/api/repo"

type poBlacklistService struct{}

var PoBlacklistService poBlacklistService

func (p *poBlacklistService) GetAllPoBlacklist(databaseType string) ([]string, error) {
	blacklist, err := repo.PoBlacklistRepository.GetAllBlacklistPo(databaseType)
	if err != nil {
		return nil, err
	}
	return blacklist, nil
}

func (p *poBlacklistService) InsertPoBlacklist(databaseType string, blacklist []string) error {
	err := repo.PoBlacklistRepository.InsertPoBlacklist(databaseType, blacklist)
	if err != nil {
		return err
	}
	return nil
}

func (p *poBlacklistService) DeletePoBlacklist(databaseType string, blacklist []string) error {

	err := repo.PoBlacklistRepository.DeletePoBlacklist(databaseType, blacklist)
	if err != nil {
		return err
	}
	return nil
}
