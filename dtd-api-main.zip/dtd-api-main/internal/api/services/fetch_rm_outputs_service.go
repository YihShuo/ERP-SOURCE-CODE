package services

import (
	"database/sql"
	"fmt"
	"strings"
	"time"
	"web-api/internal/pkg/models/types"
)

type outputsRMService struct {
	*BaseService
}

var OutputsRMService = &outputsRMService{}

func (s *outputsRMService) GetDeckerOutputsRM(databaseType, date string) ([]types.DeckerOutputsRM, error) {
	// 1. 连接数据库
	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, fmt.Errorf("failed to setup database connection: %v", err)
	}

	// 2. 定义 SQL 查询语句
	sqlGetDataRM := fmt.Sprintf(`
		SELECT
			@factoryCode AS factoryCode,
			@factoryName AS factoryName,
			clzl.cllb AS stageCode,
			ISNULL(SUM(CGZLSS.Qty), 0) AS output,
			'byPO' AS outputType,
			CASE
				WHEN cllbzl.ywsm IS NULL THEN CLLBVN.MEMO
				ELSE cllbzl.ywsm
			END AS materialType,
			clzl.ywpm AS materialName,
			clzl.dwbh AS uom,
			ISNULL(DDZL.KHPO, '') AS po,
			%s
			CASE
				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
				WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' '
				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
			END AS shipId,
			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
			xxzl.XieMing AS styleName,
			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
			SUM(CGZLSS.Qty) AS orderQuantity,
			SUM(CGZLSS.Qty) AS output,
			'1D' AS logType,
			kfzl.kfjc AS brand,
			KCRK.ZSNO AS materialOrderNumber,
			SUM(CGZLSS.Qty) AS materialOrderQuantity
		FROM KCRK
		LEFT JOIN KCRKS ON KCRK.RKNO = KCRKS.RKNO
		LEFT JOIN clzl ON KCRKS.CLBH = clzl.cldh
		LEFT JOIN cllbzl ON clzl.cllb = cllbzl.cllb
		LEFT JOIN CGZLSS ON CGZLSS.ZLBH = KCRKS.CGBH AND CGZLSS.CLBH = KCRKS.CLBH
		LEFT JOIN DDZL ON DDZL.DDBH = KCRKS.CGBH
		LEFT JOIN xxzl ON DDZL.XieXing = xxzl.XieXing AND DDZL.SheHao = xxzl.SheHao
		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
		LEFT JOIN CLLBVN ON clzl.cllb = CLLBVN.LBBH
		WHERE CONVERT(VARCHAR, KCRK.CFMDATE, 23) = CONVERT(DATE, @date)
			AND KCRK.GSBH = @GSBH
			AND (DDZL.DDBH LIKE %s)
		GROUP BY KCRK.ZSNO, KCRKS.CLBH, clzl.ywpm, clzl.dwbh, cllbzl.ywsm, KCRKS.CGBH, 
				DDZL.KHPO, DDZL.Article, xxzl.XieMing, lbzls.zwsm, kfzl.kfjc, DDZL.DDBH, 
				clzl.cllb, CLLBVN.MEMO
	`, getPoTypeQuery(DDBH, "DDZL.DDBH"), getDDBHQuery(DDBH, "DDZL.DDBH"))

	// 执行查询
	rows, err := db.Raw(sqlGetDataRM, map[string]interface{}{
		"factoryCode": factoryCode,
		"factoryName": factoryName,
		"GSBH":        GSBH,
		"date":        date,
	}).Rows()

	if err != nil {
		return nil, fmt.Errorf("failed to execute query: %v", err)
	}
	defer rows.Close()

	// 遍历行并填充数据
	var results []types.DeckerOutputsRM
	for rows.Next() {
		record, err := DeckerOutputsRMRowMapper(rows, date)
		if err != nil {
			return nil, fmt.Errorf("failed to map row: %v", err)
		}
		results = append(results, *record)
	}

	// 如果没有数据，则返回一个空切片
	if len(results) == 0 {
		return []types.DeckerOutputsRM{}, nil
	}

	return results, nil
}

func DeckerOutputsRMRowMapper(rs *sql.Rows, datetime string) (*types.DeckerOutputsRM, error) {
	dateTimeFormat := "2006-01-02 15:04:05"
	parsedTime, err := time.Parse(dateTimeFormat, datetime)
	if err != nil {
		parsedTime, err = time.Parse("2006-01-02", datetime)
		if err != nil {
			return nil, fmt.Errorf("error parsing time: %v", err)
		}
	}

	// Subtract 1 hour
	modifiedTime := parsedTime.Add(-time.Hour)
	offset := "+07:00"
	modifiedFormatter := "2006-01-02T15:04:05" + offset
	startTime := modifiedTime.Add(time.Hour*7 + time.Minute*30).Format(modifiedFormatter)
	endTime := modifiedTime.Add(time.Hour*16 + time.Minute*59 + time.Second*59).Format(modifiedFormatter)
	var deckerOutputsRM types.DeckerOutputsRM
	var factoryCode, factoryName, stageCode, outputType, materialType, materialName, uom, po, recordType, shipId, styleNumber, styleName, colorCode, logType, brand, materialOrderNumber string
	var output, orderQuantity, materialOrderQuantity float64

	// 扩展了目标字段以匹配 SQL 查询中的所有 23 列
	if err := rs.Scan(
		&factoryCode,
		&factoryName,
		&stageCode,
		&output,
		&outputType,
		&materialType,
		&materialName,
		&uom,
		&po,
		&recordType,
		&shipId,
		&styleNumber,
		&styleName,
		&colorCode,
		&orderQuantity,
		&output, // 注意：这里的 output 会覆盖前面的 output 变量
		&logType,
		&brand,
		&materialOrderNumber,
		&materialOrderQuantity,
	); err != nil {
		return nil, fmt.Errorf("failed to scan row: %v", err)
	}
	// **Thêm logic xử lý stageCode**
	if strings.HasPrefix(stageCode, "J") {
		stageCode = "RM0-3"
	} else {
		stageCode = "RM0-1"
	}
	// 設定 DeckerOutputsRM 物件的字段
	deckerOutputsRM.StartTime = startTime
	deckerOutputsRM.EndTime = endTime
	deckerOutputsRM.FactoryCode = factoryCode
	deckerOutputsRM.FactoryName = factoryName
	deckerOutputsRM.StageCode = stageCode
	deckerOutputsRM.Output = output
	deckerOutputsRM.OutputType = outputType
	deckerOutputsRM.MaterialType = materialType
	deckerOutputsRM.MaterialName = materialName
	deckerOutputsRM.Uom = uom

	// 創建並填充 PoList
	addPoList := []types.PoDetails{}
	poList := types.PoDetails{
		Po:            po,
		Type:          recordType, // "PO", "CO", "Preload"
		ShipId:        shipId,
		StyleNumber:   styleNumber,
		StyleName:     styleName,
		ColorCode:     colorCode,
		OrderQuantity: orderQuantity,
		Output:        output, // 這裡的 output 是該 PO 的產量
	}

	addPoList = append(addPoList, poList)
	deckerOutputsRM.PoList = addPoList

	// 其他字段
	deckerOutputsRM.LogType = logType
	deckerOutputsRM.Brand = brand
	deckerOutputsRM.MaterialOrderNumber = materialOrderNumber
	deckerOutputsRM.MaterialOrderQuantity = materialOrderQuantity

	return &deckerOutputsRM, nil
}
