package services

import (
	"log"
	"web-api/internal/api/repo"
	"web-api/internal/pkg/models/request"
	"web-api/internal/pkg/models/types"
)

type authService struct {
}

var AuthService = &authService{}

func (a *authService) VerifyLogin(request request.AuthRequest) (types.UserInfo, error) {
	user, err := repo.UserRepository.GetUserLogin(request)
	if err != nil {
		return user, err
	}

	log.Println(user)

	if user.Password != request.Password {
		user.UserID = ""
	}

	return user, nil
}
