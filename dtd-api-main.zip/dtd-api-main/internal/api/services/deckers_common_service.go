package services

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"sort"
	"strings"
	"time"
	"web-api/internal/pkg/database"
	"web-api/internal/pkg/models/types"

	"gorm.io/gorm"
)

type commonService struct {
	*BaseService
}

var CommonService = &commonService{}

func setupDatabase(databaseType string) (*gorm.DB, string, string, string, map[string][]string, error) {
	db, factoryCode, factoryName, GSBH, DDBH, err := database.SetupDatabaseConnection(databaseType)
	if err != nil {
		return nil, "", "", "", nil, fmt.Errorf("failed to setup database: %v", err)
	}
	return db, factoryCode, factoryName, GSBH, DDBH, err
}

func getDDBHQuery(DDBH map[string][]string, columnName string) string {

	DDBHStr := ""
	counter := 0
	for _, codeList := range DDBH {
		for _, code := range codeList {
			if counter == 0 {
				DDBHStr = "'" + code + "'"
			} else {
				DDBHStr += " OR " + columnName + " LIKE '" + code + "'"
			}
			counter++
		}
	}
	return DDBHStr
}

func getDDBHQueryTypePO(DDBH map[string][]string, columnName string) string {

	DDBHStr := ""
	counter := 0
	DDBHArr := DDBH["PO"]
	for _, code := range DDBHArr {
		if counter == 0 {
			DDBHStr = "'" + code + "'"
		} else {
			DDBHStr += " OR " + columnName + " LIKE '" + code + "'"
		}
		counter++
	}
	return DDBHStr
}

func getPoTypeQuery(DDBH map[string][]string, columnName string) string {

	poTypeQuery := "CASE "

	for poType, codeList := range DDBH {

		if len(codeList) == 0 {
			continue
		}

		counter := 0
		poTypeQuery += "WHEN " + columnName + " LIKE "

		for _, code := range codeList {
			if counter == 0 {
				poTypeQuery += "'" + code + "'"
			} else {
				poTypeQuery += " OR " + columnName + " LIKE '" + code + "'"
			}
			counter++
		}

		poTypeQuery += " THEN '" + poType + "' "
	}

	poTypeQuery += " ELSE 'PO' END AS poType, "

	return poTypeQuery
}

// Define a struct to hold the query result for production line and stage code
type ProductionLineStage struct {
	ProductionLineNumber string `gorm:"column:productionLineNumber"`
	StageCode            string `gorm:"column:stageCode"`
}

// 這個新的結構體用於儲存分組和映射後的結果
type GroupedProductionLines map[string][]string // Key: Mapped StageCode, Value: List of ProductionLineNumbers

func (service *commonService) GetRecentProductionLines(databaseType string) (GroupedProductionLines, error) {
	// 計算 3 個月前的日期
	endDate := time.Now()
	startDate := endDate.AddDate(0, -3, 0)

	// 連接資料庫 (Assuming setupDatabase returns *gorm.DB and other values)
	db, _, _, _, DDBH, err := setupDatabase(databaseType)
	if err != nil {
		return nil, err
	}
	sqlDB, _ := db.DB()
	defer sqlDB.Close() // Ensure database connection is closed

	// 依照資料庫型別設定 productionLineNumber 欄位
	productionLineExpr := "BDepartment.DepName"
	if databaseType == "A" {
		productionLineExpr = `CASE
            WHEN RIGHT(BDepartment.DepName, 1) IN ('A', 'B', 'C')
                THEN LEFT(BDepartment.DepName, LEN(BDepartment.DepName) - 1)
            ELSE BDepartment.DepName
        END`
	}

	// 撈取資料的 SQL 語句
	// 這裡我們仍然是撈取 ProductionLineNumber 和 StageCode 的原始數據
	query := fmt.Sprintf(`SELECT DISTINCT %s AS productionLineNumber, SMDDSS.GXLB AS stageCode
    FROM SMZL
    LEFT JOIN SMDDSS ON SMDDSS.CODEBAR = SMZL.CODEBAR
    LEFT JOIN SMDD ON SMDD.DDBH = SMDDSS.DDBH AND SMDD.GXLB = SMDDSS.GXLB
    LEFT JOIN BDepartment ON SMZL.DepNO = BDepartment.ID
    WHERE
        SMZL.ScanDate >= ? AND SMZL.ScanDate < ?
        AND (SMDD.YSBH LIKE %s)`,
		productionLineExpr,
		getDDBHQuery(DDBH, "SMDD.YSBH"), // This string will be injected directly as a SQL literal
	)

	// 執行查詢
	var rawResults []ProductionLineStage // 儲存從資料庫撈取到的原始結果
	if err := db.Raw(query, startDate, endDate).Scan(&rawResults).Error; err != nil {
		return nil, fmt.Errorf("failed to fetch production line numbers and stage codes: %v", err)
	}

	// 初始化分組映射
	groupedResults := make(GroupedProductionLines)

	// 定義 StageCode 映射規則
	stageCodeMap := map[string]string{
		"C": "WIP3-1",
		"O": "WIP3-3",
		"S": "WIP6",
		"A": "WIP8",
	}

	// 遍歷原始結果，進行映射和分組
	for _, row := range rawResults {
		mappedStageCode, ok := stageCodeMap[row.StageCode]
		if !ok {
			mappedStageCode = row.StageCode // 如果沒有匹配的映射，使用原始的 StageCode
		}

		// 將 ProductionLineNumber 加入到對應的 StageCode 分組中
		groupedResults[mappedStageCode] = append(groupedResults[mappedStageCode], row.ProductionLineNumber)
	}

	// 可選：對每個組內的 ProductionLineNumber 進行排序，使其輸出更一致
	for stage, lines := range groupedResults {
		sort.Strings(lines)
		groupedResults[stage] = lines
	}

	return groupedResults, nil
}

func (service *commonService) ConvertStringToPoListJSON(input string) []string {

	poList := ParseIDList(input)

	// 包成 map => {"PoList": [...]}
	data := map[string][]string{
		"PoList": poList,
	}

	// 轉換成漂亮的 JSON
	jsonBytes, err := json.MarshalIndent(data, "", "    ")
	if err != nil {
		panic(err)
	}

	// 寫入檔案
	if err := os.WriteFile("po_list.json", jsonBytes, 0644); err != nil {
		panic(err)
	}
	fmt.Println("string has converse to PoList on po_list.json")
	return poList
}

func ParseIDList(input string) []string {
	lines := strings.Split(input, "\n") // 用單斜線 \n
	var ids []string
	for _, line := range lines {
		id := strings.TrimSpace(line)
		if id != "" {
			ids = append(ids, id)
		}
	}
	return ids
}

func HandleRyMap(ddbhMapStr []string) map[string]types.CancelPoInfo {
	ddbhMap := make(map[string]types.CancelPoInfo, len(ddbhMapStr))
	for _, keyPair := range ddbhMapStr {

		// String array: DDBH(index = 0) | Old KHPO (index = 1)
		keyArr := strings.Split(keyPair, ":")

		if len(keyArr) == 3 {
			oldPoInfo := types.CancelPoInfo{
				PoNumber: keyArr[1],
				ShipId:   keyArr[2],
			}
			ddbhMap[keyArr[0]] = oldPoInfo
		} else {
			log.Println("Ignore: " + keyPair)
		}
	}
	return ddbhMap
}

func Keys[K comparable, V any](m map[K]V) []K {
	ks := make([]K, 0, len(m))
	for k := range m {
		ks = append(ks, k)
	}
	return ks
}
