package services

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"web-api/internal/pkg/models/types"
)

var expectedStages = []string{"RM0-1", "RM0-3", "WIP3-1", "WIP3-3", "WIP6", "WIP8", "FG10", "FG14"}

// *檢查 Milestones*
func validateMilestones(milestones []types.Milestone) (bool, bool) {
	stageMap := make(map[string]int)
	missingStage, invalidQuantity := false, false

	// 把 milestones 轉成 map
	for _, m := range milestones {
		stageMap[m.StageCode] = m.CompletionQuantity
	}

	prevQuantity := -1
	// 依照 expectedStages 順序檢查
	for _, stage := range expectedStages {
		qty, exists := stageMap[stage]
		if !exists {
			missingStage = true // 有缺少的 Stage
			continue
		}
		if prevQuantity != -1 && qty > prevQuantity {
			invalidQuantity = true // 數量沒有遞減
		}
		prevQuantity = qty
	}

	return missingStage, invalidQuantity
}

// **初始化 IncompleteFields**
func NewIncompleteFields(checkFields map[string]bool) map[string][]string {
	result := make(map[string][]string)
	for field := range checkFields {
		result[field] = []string{}
	}
	return result
}

// **找出不完整的訂單**
func FindIncompleteOrders(orders []types.DailyPoStatus, checkFields map[string]bool) map[string][]string {

	result := NewIncompleteFields(checkFields)

	totalFg10 := 0
	totalFg14 := 0

	for _, order := range orders {
		// **字串類欄位檢查**
		stringFields := map[string]string{
			"LackDate":          order.Date,
			"LackPoType":        order.PoType,
			"LackFactoryCode":   order.FactoryCode,
			"LackFactoryName":   order.FactoryName,
			"LackStatus":        order.Status,
			"LackStatusMessage": order.StatusMessage,
			"LackStyleNumber":   order.StyleNumber,
			"LackStyleName":     order.StyleName,
			"LackColorCode":     order.ColorCode,
			"LackShipID":        order.ShipID,
			"LackSeason":        order.Season,
			"LackLogType":       order.LogType,
			"LackBrand":         order.Brand,
			"LackConfirmXFDate": order.ConfirmXFDate,
		}

		for key, value := range stringFields {
			if checkFields[key] && strings.TrimSpace(value) == "" {
				result[key] = append(result[key], order.PoNumber)
			}
		}

		// **數值類欄位檢查**
		numericFields := map[string]int{
			"LackPoCompletionQuantity": order.PoCompletionQuantity,
			"LackPoQuantity":           order.PoQuantity,
		}

		for key, value := range numericFields {
			if checkFields[key] && value == 0 {
				result[key] = append(result[key], order.PoNumber)
			}
		}

		// **Milestone 檢查**
		if checkFields["LackMilestones"] && len(order.MilestoneList) == 0 {
			result["LackMilestones"] = append(result["LackMilestones"], order.PoNumber)
		} else if checkFields["InvalidMilestones"] {
			missingStage, invalidQuantity := validateMilestones(order.MilestoneList)
			if missingStage {
				result["LackMilestones"] = append(result["LackMilestones"], order.PoNumber)
			}
			if invalidQuantity {
				result["InvalidMilestones"] = append(result["InvalidMilestones"], order.PoNumber)
			}
		}

		if strings.TrimSpace(order.PoNumber) == "" {
			result["NoPONumber"] = append(result["NoPONumber"], order.DDBH)
		}

		sumFg := 0
		for _, milestone := range order.MilestoneList {
			if milestone.StageCode == "FG10" {
				totalFg10 += milestone.CompletionQuantity
				sumFg += milestone.CompletionQuantity
			}
			if milestone.StageCode == "FG14" {
				totalFg14 += milestone.CompletionQuantity
				sumFg -= milestone.CompletionQuantity
			}
		}
		if sumFg < 0 {
			fmt.Printf("%v, ", order.PoNumber)
		}
	}
	log.Printf("FG different: %v", totalFg10-totalFg14)
	for key, value := range result {
		result[key] = uniqueElements(value)
	}

	return result
}

// **測試函式**
func TestPoStatus(orders []types.DailyPoStatus) {
	checkFields := map[string]bool{
		"LackShipID":               true,
		"LackPoCompletionQuantity": true,
		"LackPoQuantity":           true,
		"LackBrand":                true,
		"LackMilestones":           true,
		"InvalidMilestones":        true,
		"NoPONumber":               true,
	}

	missingData := FindIncompleteOrders(orders, checkFields)

	jsonOutput, _ := json.MarshalIndent(missingData, "", "  ")

	// Lấy đường dẫn thư mục của dự án
	projectPath, err := os.Getwd()
	if err != nil {
		fmt.Println("Lỗi khi lấy đường dẫn thư mục:", err)
		return
	}

	// Tạo đường dẫn cho file JSON
	filePath := filepath.Join(projectPath, "missing_data.json")

	// Ghi nội dung JSON ra file
	err = os.WriteFile(filePath, jsonOutput, 0644)
	if err != nil {
		fmt.Println("Lỗi khi ghi file:", err)
		return
	}

	fmt.Println("Dữ liệu đã được ghi vào:", filePath)

}

func uniqueElements(slice []string) []string {
	uniqueMap := make(map[string]bool)
	var uniqueSlice []string

	for _, v := range slice {
		if !uniqueMap[v] {
			uniqueSlice = append(uniqueSlice, v)
			uniqueMap[v] = true
		}
	}
	return uniqueSlice
}
