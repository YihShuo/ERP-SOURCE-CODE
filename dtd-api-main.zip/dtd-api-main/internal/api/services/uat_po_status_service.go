package services

// import (
// 	"fmt"
// 	"log"
// 	"strings"
// 	"unicode"
// 	"web-api/internal/integration/deckers"
// 	"web-api/internal/pkg/jwt"
// 	"web-api/internal/pkg/models/types"
// )

// type uatPoStatusService struct {
// }

// var UatPoStatusService = &uatPoStatusService{}

// func (s *uatPoStatusService) GetUatDailyPoStatus(databaseType, date string) ([]types.UatDailyPoStatus, []types.UatDailyPoStatus, error) {

// 	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	sqlQuery := fmt.Sprintf(`
// 		WITH ListKHPO AS (
// 			-- Nguồn 1: Bảng YWCP với ngày xuất hoặc ngày nhập hôm nay
// 			SELECT DISTINCT DDZL.KHPO
// 			FROM YWCP
// 			INNER JOIN DDZL
// 			ON DDZL.DDBH = YWCP.DDBH
// 			WHERE
// 			(
// 				CONVERT(DATE, YWCP.EXEDATE) = CONVERT(DATE, @date)
// 				OR CONVERT(DATE, YWCP.INDATE) = CONVERT(DATE, @date)
// 				OR CONVERT(DATE, YWCP.REDATE) = CONVERT(DATE, @date)
// 			)
// 			AND DDZL.KHPO IS NOT NULL
// 			AND LTRIM(RTRIM(DDZL.KHPO)) <> ''

// 			UNION

// 			-- Nguồn 2: Bảng SMDDSS với ngày quét hôm nay
// 			SELECT DISTINCT KHPO
// 			FROM SMDD
// 				INNER JOIN SMDDSS on SMDDSS.DDBH = SMDD.DDBH and SMDD.GXLB = SMDDSS.GXLB
// 				INNER JOIN DDZL ON DDZL.DDBH = SMDD.YSBH
// 			WHERE CONVERT(DATE, ScanEDate) = CONVERT(DATE, @date)

// 			UNION

// 			-- Nguồn 3: Bảng KCRK + KCRKS với ngày xác nhận nhập kho hôm nay
// 			SELECT  distinct DDZL.KHPO
// 			FROM KCRK
// 			LEFT JOIN KCRKS ON KCRK.RKNO = KCRKS.RKNO
// 			INNER JOIN DDZL ON DDZL.DDBH = KCRKS.CGBH
// 			WHERE CONVERT(DATE, CFMDATE) = CONVERT(DATE, @date)
// 			AND KCRK.GSBH = @gsbh
// 			AND (KCRKS.CGBH LIKE %s)
// 		)
// 		SELECT
// 			CONVERT(VARCHAR(10), @date, 23) AS date,
// 			DDZL.KHPO AS poNumber,
// 			%s
// 			@factoryCode AS factoryCode,
// 			@factoryName AS factoryName,
// 			'002' AS status,
// 			'Normal' AS statusMessage,
// 			CASE
// 				WHEN CHARINDEX('-', DDZL.Article) > 0
// 				THEN SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1)
// 				ELSE DDZL.Article
// 			END AS styleNumber,
// 			xxzl.XieMing AS styleName,
// 			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
// 			xxzl.jijie AS season,
// 			CASE
// 				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' '
// 				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
// 			END AS shipId,
// 			YWCP.Qty AS poCompletionQuantity,
// 			DDZL.Pairs AS poQuantity,
// 			'1d' AS logType,
// 			kfzl.kfjc AS brand,
// 			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
// 			'stageCode' AS stageCode,
// 			0 AS completionQuantity,
// 			'sizeNumber' AS sizeNumber,
// 			0 AS sizeCompletionQuantity,
// 			0 AS sizeTargetQuantity,
// 			DDZL.DDBH AS DDBH
// 		FROM DDZL
// 		INNER JOIN ListKHPO ON ListKHPO.KHPO = DDZL.KHPO
// 		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
// 		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
// 		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
// 		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
// 		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP
// 			ON YWCP.DDBH = DDZL.DDBH
// 		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
// 		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
// 		WHERE 1=1
// 			AND DDZL.KHPO != ''
// 			AND DDZL.KHPO IS NOT NULL
// 			AND DDZL.DDZT = 'Y'
// 			AND (DDZL.DDBH LIKE %s)
// 			AND NOT (
// 				DDZL.DDBH LIKE '%s'
// 				OR RIGHT(DDZL.DDBH, 2) = 'BG'
// 				OR DDZL.DDBH LIKE '%s'
// 			)
// 		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, xxzl.jijie
// 		ORDER BY DDZL.KHPO;

// 	`, getDDBHQuery(DDBH, "KCRKS.CGBH"), getPoTypeQuery(DDBH, "DDZL.DDBH"), getDDBHQuery(DDBH, "DDZL.DDBH"), "%-B%", "DHB%")

// 	queryParams := map[string]interface{}{
// 		"factoryCode": factoryCode,
// 		"factoryName": factoryName,
// 		"date":        date,
// 		"gsbh":        GSBH,
// 	}
// 	// 查詢 DailyPoStatus 資料
// 	var poStatusData []types.UatDailyPoStatus
// 	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	rawData := []types.UatDailyPoStatus{}

// 	// Cache size list from Decker
// 	deckerSizeList := make(map[string]string)

// 	// Get XFDetailMap
// 	XFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity

// 	const batchSize = 100

// 	for start := 0; start < len(poStatusData); start += batchSize {

// 		end := start + batchSize
// 		if end > len(poStatusData) {
// 			end = len(poStatusData)
// 		}

// 		log.Printf("Processing PO batch: %d ~ %d\n", start, end)

// 		batch := poStatusData[start:end]

// 		for i := range batch {
// 			value := &batch[i]

// 			value.MilestoneList = []types.Milestone{}

// 			sizeMapKey := value.StyleNumber + "-" + value.ColorCode

// 			milestoneListData, err := GetMilestoneData(
// 				db,
// 				value.PoNumber,
// 				GSBH,
// 				value.StyleNumber+"-"+value.ColorCode,
// 				value.DDBH,
// 				date,
// 			)
// 			if err != nil {
// 				return nil, nil, fmt.Errorf(
// 					"failed to get milestone data for PoNumber %s: %v",
// 					value.PoNumber,
// 					err,
// 				)
// 			}
// 			rawMilestone := []types.Milestone{}

// 			// 如果有 Milestone 資料，才填充到 MilestoneList
// 			if len(milestoneListData) > 0 {
// 				milestoneMap := make(map[string]*types.Milestone)
// 				for _, ml := range milestoneListData {
// 					// 根據 StageCode 轉換
// 					switch ml.StageCode {
// 					case "C":
// 						ml.StageCode = "WIP3-1"
// 					case "O":
// 						ml.StageCode = "WIP3-3"
// 					case "S":
// 						ml.StageCode = "WIP6"
// 					case "A":
// 						ml.StageCode = "WIP8"
// 					}

// 					rawMilestone = append(rawMilestone, ml)

// 					if milestone, exists := milestoneMap[ml.StageCode]; exists {
// 						milestone.CompletionQuantity += ml.CompletionQuantity
// 						milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
// 					} else {
// 						milestoneMap[ml.StageCode] = &types.Milestone{
// 							StageCode:          ml.StageCode,
// 							CompletionQuantity: ml.CompletionQuantity,
// 							SizeList:           ml.SizeList,
// 						}
// 					}
// 				}

// 				// Export raw data
// 				var rawPo = *value
// 				rawPo.MilestoneList = rawMilestone
// 				rawData = append(rawData, rawPo)

// 				var newMilestoneListData []types.Milestone
// 				for _, milestone := range milestoneMap {
// 					newMilestoneListData = append(newMilestoneListData, *milestone)
// 				}

// 				// Milestone handling code
// 				newMilestoneListData = fillMissingStages(newMilestoneListData)
// 				sortMilestones(newMilestoneListData)
// 				AdjustQtyByStage(newMilestoneListData)
// 				newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
// 				newMilestoneListData = fillEmptyStage(newMilestoneListData)
// 				value.MilestoneList = newMilestoneListData
// 			}

// 			err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(databaseType), deckerSizeList)
// 			if err != nil {
// 				return nil, nil, fmt.Errorf("error when get size list from deckers")
// 			}

// 			// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
// 			for _, milestone := range value.MilestoneList {

// 				// Get last size string from size map and check if exist
// 				if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 					// Change all size number: add last size string to the end
// 					for index := range milestone.SizeList {

// 						size := &milestone.SizeList[index]

// 						// Ignore empty size number
// 						if len(size.SizeNumber) > 0 {

// 							// Get last character in size number
// 							lastCharIndex := len(size.SizeNumber) - 1
// 							checkingChar := size.SizeNumber[lastCharIndex]

// 							// Check if it was added or not
// 							if !unicode.IsLetter(rune(checkingChar)) {

// 								// Add to the end
// 								size.SizeNumber += lastSizeStr
// 							}
// 						}
// 						size.SizeNumber = strings.TrimSpace(size.SizeNumber)
// 					}
// 				}

// 				// Add PO completion Qty = WIP8's Qty
// 				if milestone.StageCode == "WIP8" {
// 					value.PoCompletionQuantity = milestone.CompletionQuantity
// 				}
// 			}

// 			if value.PoCompletionQuantity == value.PoQuantity {
// 				value.Status = "001"
// 			}

// 			// XF Detail
// 			XFDetail, exist := XFDetailMap[value.DDBH]
// 			if exist {
// 				value.XFDetail = XFDetail
// 			} else {
// 				value.XFDetail = []types.XFDetail{}
// 			}
// 			for index, XFDetail := range value.XFDetail {

// 				// Get last size string from size map and check if exist
// 				if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 					sizeNumber := XFDetail.SizeNumber

// 					// Get last character in size number
// 					lastCharIndex := len(sizeNumber) - 1
// 					checkingChar := sizeNumber[lastCharIndex]

// 					// Check if it was added or not
// 					if !unicode.IsLetter(rune(checkingChar)) {

// 						// Add to the end
// 						sizeNumber += lastSizeStr
// 						value.XFDetail[index].SizeNumber = sizeNumber
// 					}
// 				}
// 			}
// 		}
// 	}
// 	result := mergeUatDuplicatePOs(poStatusData)

// 	return result, rawData, nil
// }

// func (s *uatPoStatusService) GetUatDailyPoStatusPreload(databaseType, date string) ([]types.UatDailyPoStatus, []types.UatDailyPoStatus, error) {

// 	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	sqlQuery := fmt.Sprintf(`
// 		WITH ListDDBH AS (
// 			SELECT DISTINCT DDBH FROM DDZL
// 			WHERE USERDATE = CAST(@date AS DATE)
// 				AND DDBH LIKE %s
// 		)
// 		SELECT
// 			CONVERT(VARCHAR(10), @date, 23) AS date,
// 			ISNULL(DDZL.KHPO, '') AS poNumber,
// 			%s
// 			@factoryCode AS factoryCode,
// 			@factoryName AS factoryName,
// 			'002' AS status,
// 			'Normal' AS statusMessage,
// 			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
// 			xxzl.XieMing AS styleName,
// 			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
// 			xxzl.jijie AS season,
// 			CASE
// 				WHEN CHARINDEX(' ', lbzls.zwsm) <= 1 THEN ' '
// 				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
// 			END AS shipId,
// 			YWCP.Qty AS poCompletionQuantity,
// 			DDZL.Pairs AS poQuantity,
// 			'1d' AS logType,
// 			kfzl.kfjc AS brand,
// 			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
// 			'stageCode' AS stageCode,
// 			0 AS completionQuantity,
// 			'sizeNumber' AS sizeNumber,
// 			0 AS sizeCompletionQuantity,
// 			0 AS sizeTargetQuantity,
// 			DDZL.DDBH AS DDBH
// 		FROM DDZL
// 		INNER JOIN ListDDBH ON ListDDBH.DDBH = DDZL.DDBH
// 		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
// 		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
// 		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
// 		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
// 		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP
// 			ON YWCP.DDBH = DDZL.DDBH
// 		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
// 		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
// 		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, xxzl.jijie
// 		ORDER BY DDZL.KHPO;

// 	`, "'F%'", getPoTypeQuery(DDBH, "DDZL.DDBH"))

// 	queryParams := map[string]interface{}{
// 		"factoryCode": factoryCode,
// 		"factoryName": factoryName,
// 		"date":        date,
// 		"gsbh":        GSBH,
// 	}
// 	// 查詢 DailyPoStatus 資料
// 	var poStatusData []types.UatDailyPoStatus
// 	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	rawData := []types.UatDailyPoStatus{}

// 	// Cache size list from Decker
// 	deckerSizeList := make(map[string]string)

// 	// Get XFDetailMap
// 	XFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
// 	for i := range poStatusData {
// 		value := &poStatusData[i]
// 		// 初始化 MilestoneList
// 		value.MilestoneList = []types.Milestone{}

// 		sizeMapKey := value.StyleNumber + "-" + value.ColorCode

// 		// 獲取 Milestone 資料
// 		milestoneListData, err := GetMilestoneData(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH, date)
// 		if err != nil {
// 			return nil, nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
// 		}

// 		rawMilestone := []types.Milestone{}

// 		// 如果有 Milestone 資料，才填充到 MilestoneList
// 		if len(milestoneListData) > 0 {
// 			milestoneMap := make(map[string]*types.Milestone)
// 			for _, ml := range milestoneListData {
// 				// 根據 StageCode 轉換
// 				switch ml.StageCode {
// 				case "C":
// 					ml.StageCode = "WIP3-1"
// 				case "O":
// 					ml.StageCode = "WIP3-3"
// 				case "S":
// 					ml.StageCode = "WIP6"
// 				case "A":
// 					ml.StageCode = "WIP8"
// 				}

// 				rawMilestone = append(rawMilestone, ml)

// 				if milestone, exists := milestoneMap[ml.StageCode]; exists {
// 					milestone.CompletionQuantity += ml.CompletionQuantity
// 					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
// 				} else {
// 					milestoneMap[ml.StageCode] = &types.Milestone{
// 						StageCode:          ml.StageCode,
// 						CompletionQuantity: ml.CompletionQuantity,
// 						SizeList:           ml.SizeList,
// 					}
// 				}
// 			}

// 			// Export raw data
// 			var rawPo = *value
// 			rawPo.MilestoneList = rawMilestone
// 			rawData = append(rawData, rawPo)

// 			var newMilestoneListData []types.Milestone
// 			for _, milestone := range milestoneMap {
// 				newMilestoneListData = append(newMilestoneListData, *milestone)
// 			}

// 			// Milestone handling code
// 			newMilestoneListData = fillMissingStages(newMilestoneListData)
// 			sortMilestones(newMilestoneListData)
// 			AdjustQtyByStage(newMilestoneListData)
// 			newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
// 			newMilestoneListData = fillEmptyStage(newMilestoneListData)
// 			value.MilestoneList = newMilestoneListData
// 		}

// 		err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(databaseType), deckerSizeList)
// 		if err != nil {
// 			return nil, nil, fmt.Errorf("error when get size list from deckers")
// 		}

// 		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
// 		for _, milestone := range value.MilestoneList {

// 			// Get last size string from size map and check if exist
// 			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 				// Change all size number: add last size string to the end
// 				for index := range milestone.SizeList {

// 					size := &milestone.SizeList[index]

// 					// Ignore empty size number
// 					if len(size.SizeNumber) > 0 {

// 						// Get last character in size number
// 						lastCharIndex := len(size.SizeNumber) - 1
// 						checkingChar := size.SizeNumber[lastCharIndex]

// 						// Check if it was added or not
// 						if !unicode.IsLetter(rune(checkingChar)) {

// 							// Add to the end
// 							size.SizeNumber += lastSizeStr
// 						}
// 					}
// 					size.SizeNumber = strings.TrimSpace(size.SizeNumber)
// 				}
// 			}

// 			// Add PO completion Qty = WIP8's Qty
// 			if milestone.StageCode == "WIP8" {
// 				value.PoCompletionQuantity = milestone.CompletionQuantity
// 			}
// 		}

// 		if value.PoCompletionQuantity == value.PoQuantity {
// 			value.Status = "001"
// 		}

// 		// XF Detail
// 		XFDetail, exist := XFDetailMap[value.DDBH]
// 		if exist {
// 			value.XFDetail = XFDetail
// 		} else {
// 			value.XFDetail = []types.XFDetail{}
// 		}
// 		for index, XFDetail := range value.XFDetail {

// 			// Get last size string from size map and check if exist
// 			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 				sizeNumber := XFDetail.SizeNumber

// 				// Get last character in size number
// 				lastCharIndex := len(sizeNumber) - 1
// 				checkingChar := sizeNumber[lastCharIndex]

// 				// Check if it was added or not
// 				if !unicode.IsLetter(rune(checkingChar)) {

// 					// Add to the end
// 					sizeNumber += lastSizeStr
// 					value.XFDetail[index].SizeNumber = sizeNumber
// 				}
// 			}
// 		}
// 	}

// 	result := mergeUatDuplicatePOs(poStatusData)

// 	return result, rawData, nil
// }

// func (s *uatPoStatusService) GetUatDailyPoStatusByPOList(databaseType, date string, poList []string) ([]types.UatDailyPoStatus, []types.UatDailyPoStatus, error) {

// 	db, factoryCode, factoryName, GSBH, DDBH, err := setupDatabase(databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	poListSQL := BuildPoListSQL(poList)

// 	sqlTemplate := `
// 		SELECT
// 			CONVERT(VARCHAR(10), @date, 23) AS date,
// 			DDZL.KHPO AS poNumber,
// 			%s
// 			@factoryCode AS factoryCode,
// 			@factoryName AS factoryName,
// 			'002' AS status,
// 			'Normal' AS statusMessage,
// 			SUBSTRING(DDZL.Article, 1, CHARINDEX('-', DDZL.Article) - 1) AS styleNumber,
// 			xxzl.XieMing AS styleName,
// 			SUBSTRING(DDZL.Article, CHARINDEX('-', DDZL.Article) + 1, LEN(DDZL.Article)) AS colorCode,
// 			CASE
// 				WHEN DDZL.BUYNO LIKE '%s' THEN SUBSTRING(DDZL.BUYNO, 1, 3)
// 				ELSE SUBSTRING(DDZL.BUYNO, 5, 3)
// 			END AS season,
// 			CASE
// 				WHEN CHARINDEX(' ', lbzls.zwsm) = 0 THEN ' '
// 				WHEN SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1) IS NULL THEN ' '
// 				ELSE SUBSTRING(lbzls.zwsm, 1, CHARINDEX(' ', lbzls.zwsm) - 1)
// 			END AS shipId,
// 			YWCP.Qty AS poCompletionQuantity,
// 			DDZL.Pairs AS poQuantity,
// 			'1d' AS logType,
// 			kfzl.kfjc AS brand,
// 			CONVERT(VARCHAR, DDZL.ShipDate,23) AS confirmXFDate,
// 			'stageCode' AS stageCode,
// 			0 AS completionQuantity,
// 			'sizeNumber' AS sizeNumber,
// 			0 AS sizeCompletionQuantity,
// 			0 AS sizeTargetQuantity,
// 			DDZL.DDBH AS DDBH
// 		FROM DDZL
// 		LEFT JOIN kfzl ON DDZL.KHBH = kfzl.kfdh
// 		LEFT JOIN SMDD ON SMDD.YSBH = DDZL.DDBH
// 		LEFT JOIN SMDDSS ON SMDDSS.DDBH = SMDD.DDBH
// 		LEFT JOIN SMZL ON SMZL.CODEBAR = SMDDSS.CODEBAR
// 		LEFT JOIN xxzl ON xxzl.XieXing = DDZL.XieXing and xxzl.SheHao = DDZL.SheHao
// 		LEFT JOIN (SELECT YWCP.DDBH, SUM(YWCP.Qty) AS Qty FROM YWCP WHERE YWCP.SB = 1 GROUP BY YWCP.DDBH) YWCP
// 			ON YWCP.DDBH = DDZL.DDBH
// 		LEFT JOIN lbzls ON DDZL.Dest = lbzls.lbdh AND lbzls.lb = '13'
// 		WHERE DDZL.KHPO IN (%s)
// 			AND DDZL.DDZT = 'Y'
// 			AND NOT (
// 				DDZL.DDBH LIKE '%s'
// 				OR RIGHT(DDZL.DDBH, 2) = 'BG'
// 				OR DDZL.DDBH LIKE '%s'
// 			)
// 		GROUP BY DDZL.DDBH, DDZL.KHPO, DDZL.Article, YWCP.Qty, DDZL.Pairs, kfzl.kfjc, DDZL.ShipDate, xxzl.XieMing, lbzls.zwsm, DDZL.BUYNO;
// 	`

// 	sqlQuery := fmt.Sprintf(sqlTemplate,
// 		getPoTypeQuery(DDBH, "DDZL.DDBH"),
// 		"%PR%",    // %s #3 (PO 季節提取)
// 		poListSQL, // %s #5
// 		"%-B%",
// 		"DHB%",
// 	)

// 	queryParams := map[string]interface{}{
// 		"factoryCode": factoryCode,
// 		"factoryName": factoryName,
// 		"date":        date,
// 	}

// 	// 查詢 DailyPoStatus 資料
// 	var poStatusData []types.UatDailyPoStatus
// 	err = db.Raw(sqlQuery, queryParams).Scan(&poStatusData).Error
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	// Cache size list from Decker
// 	deckerSizeList := make(map[string]string)

// 	rawData := []types.UatDailyPoStatus{}

// 	// Get XFDetailMap
// 	XFDetailMap, err := GetXFDetailMap(db, poStatusData, date, databaseType)
// 	if err != nil {
// 		return nil, nil, err
// 	}

// 	// 處理每一條資料，並從 MilestoneList 中獲取 WIP8 階段的 CompletionQuantity
// 	for i := range poStatusData {
// 		value := &poStatusData[i]
// 		// 初始化 MilestoneList
// 		value.MilestoneList = []types.Milestone{}

// 		sizeMapKey := value.StyleNumber + "-" + value.ColorCode

// 		println("Processing PO:", value.PoNumber)

// 		// 初始化 MilestoneList
// 		value.MilestoneList = []types.Milestone{}

// 		// 獲取 Milestone 資料
// 		milestoneListData, err := GetMilestoneDataWithOldFG(db, value.PoNumber, GSBH, value.StyleNumber+"-"+value.ColorCode, value.DDBH, date)
// 		if err != nil {
// 			return nil, nil, fmt.Errorf("failed to get milestone data for PoNumber %s: %v", value.PoNumber, err)
// 		}

// 		var rawPo = *value
// 		rawPo.MilestoneList = milestoneListData
// 		rawData = append(rawData, rawPo)

// 		// 如果有 Milestone 資料，才填充到 MilestoneList
// 		if len(milestoneListData) > 0 {
// 			milestoneMap := make(map[string]*types.Milestone)
// 			for _, ml := range milestoneListData {
// 				// 根據 StageCode 轉換
// 				switch ml.StageCode {
// 				case "C":
// 					ml.StageCode = "WIP3-1"
// 				case "O":
// 					ml.StageCode = "WIP3-3"
// 				case "S":
// 					ml.StageCode = "WIP6"
// 				case "A":
// 					ml.StageCode = "WIP8"
// 				}

// 				if milestone, exists := milestoneMap[ml.StageCode]; exists {
// 					milestone.CompletionQuantity += ml.CompletionQuantity
// 					milestone.SizeList = append(milestone.SizeList, ml.SizeList...)
// 				} else {
// 					milestoneMap[ml.StageCode] = &types.Milestone{
// 						StageCode:          ml.StageCode,
// 						CompletionQuantity: ml.CompletionQuantity,
// 						SizeList:           ml.SizeList,
// 					}
// 				}
// 			}

// 			var newMilestoneListData []types.Milestone
// 			for _, milestone := range milestoneMap {
// 				newMilestoneListData = append(newMilestoneListData, *milestone)
// 			}

// 			newMilestoneListData = fillMissingStages(newMilestoneListData)
// 			sortMilestones(newMilestoneListData)
// 			AdjustQtyByStage(newMilestoneListData)
// 			newMilestoneListData = RemoveStageWithEmptySizeList(newMilestoneListData)
// 			newMilestoneListData = fillEmptyStage(newMilestoneListData)
// 			value.MilestoneList = newMilestoneListData
// 		}

// 		err = deckers.DeckerClient.GetSizeList(value.StyleNumber, value.ColorCode, jwt.GetJWT(databaseType), deckerSizeList)
// 		if err != nil {
// 			return nil, nil, fmt.Errorf("error when get size list from deckers")
// 		}

// 		// 設置 poCompletionQuantity 為 WIP8 階段的 CompletionQuantity
// 		for _, milestone := range value.MilestoneList {

// 			// Get last size string from size map and check if exist
// 			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 				// Change all size number: add last size string to the end
// 				for index := range milestone.SizeList {

// 					size := &milestone.SizeList[index]

// 					// Ignore empty size number
// 					if len(size.SizeNumber) > 0 {

// 						// Get last character in size number
// 						lastCharIndex := len(size.SizeNumber) - 1
// 						checkingChar := size.SizeNumber[lastCharIndex]

// 						// Check if it was added or not
// 						if !unicode.IsLetter(rune(checkingChar)) {

// 							// Add to the end
// 							size.SizeNumber += lastSizeStr
// 						}
// 					}
// 				}
// 			}

// 			// Add PO completion Qty = WIP8's Qty
// 			if milestone.StageCode == "WIP8" {
// 				value.PoCompletionQuantity = milestone.CompletionQuantity
// 			}
// 		}

// 		if value.PoCompletionQuantity == value.PoQuantity {
// 			value.Status = "001"
// 		}

// 		// XF Detail
// 		XFDetail, exist := XFDetailMap[value.DDBH]
// 		if exist {
// 			value.XFDetail = XFDetail
// 		} else {
// 			value.XFDetail = []types.XFDetail{}
// 		}
// 		for index, XFDetail := range value.XFDetail {

// 			// Get last size string from size map and check if exist
// 			if lastSizeStr, exist := deckerSizeList[sizeMapKey]; exist {

// 				sizeNumber := XFDetail.SizeNumber

// 				// Get last character in size number
// 				lastCharIndex := len(sizeNumber) - 1
// 				checkingChar := sizeNumber[lastCharIndex]

// 				// Check if it was added or not
// 				if !unicode.IsLetter(rune(checkingChar)) {

// 					// Add to the end
// 					sizeNumber += lastSizeStr
// 					value.XFDetail[index].SizeNumber = sizeNumber
// 				}
// 			}
// 		}
// 	}

// 	result := mergeUatDuplicatePOs(poStatusData)
// 	// result := poStatusData

// 	return result, rawData, nil
// }
