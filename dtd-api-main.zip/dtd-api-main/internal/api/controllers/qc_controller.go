package controllers

import (
	"log"
	"net/http"
	"time"
	"web-api/internal/api/services"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/models/response"
	"web-api/internal/pkg/utils"

	"github.com/gin-gonic/gin"
)

type QcController struct {
}

var QcControllerInstance QcController

func (tqc *QcController) GetTqcOutput(ctx *gin.Context) {
	databaseType := ctx.Query("db")
	datetime := ctx.Query("datetime")
	data, err := services.QcServiceInstance.GetHourlyTqcOutput(databaseType, datetime)
	if err != nil {
		log.Printf("error occurs while getting TQC output: %v\n", err)
	}
	response.OkWithData(ctx, data)

	// Test environment
	// token, _ := jwt.GetTestOAuthToken(databaseType)
	// services.DeckersPostServiceInstance.PostTQCOutput(databaseType, data, token)
}

func (tqc *QcController) GetRqcOutput(ctx *gin.Context) {
	databaseType := ctx.Query("db")
	datetime := ctx.Query("datetime")
	data, err := services.QcServiceInstance.GetHourlyRqcOutput(databaseType, datetime)
	if err != nil {
		log.Printf("error occurs while getting RQC output: %v\n", err)
	}
	response.OkWithData(ctx, data)

	// Test environment
	// token, _ := jwt.GetTestOAuthToken(databaseType)
	// services.DeckersPostServiceInstance.PostRQCOutput(databaseType, data, token)
}

func (tqc *QcController) GetBgradeOutput(ctx *gin.Context) {
	databaseType := ctx.Query("db")
	date := ctx.Query("date")
	data, err := services.QcServiceInstance.GetDailyBgradeOutput(databaseType, date)
	if err != nil {
		log.Printf("error occurs while getting B grade output: %v\n", err)
	}

	if len(data) > 0 {

		token := jwt.GetJWT(databaseType)
		returnMap, err := services.DeckersPostServiceInstance.PostBgradeOutput(databaseType, data, token)
		if err != nil {
			response.FailWithDetailed(ctx, http.StatusInternalServerError, data, err.Error())
			return
		}

		err = services.QcServiceInstance.SendBgradeMail(databaseType, date, data, returnMap)
		if err != nil {
			log.Printf("error occurs while sending mail: %v\n", err)
			response.FailWithDetailed(ctx, http.StatusInternalServerError, data, err.Error())
			return
		}
	}

	response.OkWithData(ctx, data)

}

func (tqc *QcController) GetRepackingOutput(ctx *gin.Context) {
	databaseType := ctx.Query("db")
	date := ctx.Query("date")

	data, err := services.QcServiceInstance.GetRepackingOutput(databaseType, date)
	if err != nil {
		log.Printf("error occurs while getting Repacking output: %v\n", err)
		response.FailWithDetailed(ctx, http.StatusInternalServerError, data, err.Error())
		return
	}

	if len(data) > 0 {
		// get token to use
		token := jwt.GetJWT(databaseType)

		// gửi repacking
		returnMap, err := services.DeckersPostServiceInstance.PostRepacking(databaseType, data, token)
		if err != nil {
			response.FailWithDetailed(ctx, http.StatusInternalServerError, data, err.Error())
			return
		}

		// returnMap := map[string]string{}

		err = services.QcServiceInstance.SendRepackingMail(databaseType, date, data, returnMap)
		if err != nil {
			log.Printf("error occurs while sending mail: %v\n", err)
			response.FailWithDetailed(ctx, http.StatusInternalServerError, data, err.Error())
			return
		}
	}

	response.OkWithData(ctx, data)
}

func (tqc *QcController) SendRepackingOutput(ctx *gin.Context) {
	databaseType := ctx.Query("db")
	date := ctx.Query("date")

	data, err := services.QcServiceInstance.GetRepackingOutput(databaseType, date)
	if err != nil {
		response.FailWithDetailed(ctx, 401, err.Error(), "")
		return
	}
	// get token to use
	token := jwt.GetJWT(databaseType)

	// gửi repacking
	returnMap, err := services.DeckersPostServiceInstance.PostRepacking(databaseType, data, token)
	if err != nil {
		response.FailWithDetailed(ctx, 401, err.Error(), "")
		return
	}

	err = services.QcServiceInstance.SendRepackingMail(databaseType, date, data, returnMap)
	if err != nil {
		log.Printf("error occurs while sending mail: %v\n", err)
		response.FailWithDetailed(ctx, http.StatusInternalServerError, data, err.Error())
		return
	}

	response.OkWithData(ctx, data)
}

func (tqc *QcController) SendRepackingOutputByPO(ctx *gin.Context) {
	databaseType := ctx.Query("db")
	khpo := ctx.Query("po")

	data, err := services.QcServiceInstance.GetRepackingOutputByPO(databaseType, khpo)
	if err != nil {
		response.FailWithDetailed(ctx, 401, nil, err.Error())
		return
	}
	// get token to use
	token := jwt.GetJWT(databaseType)

	// gửi repacking
	returnMap, err := services.DeckersPostServiceInstance.PostRepacking(databaseType, data, token)
	if err != nil {
		response.FailWithDetailed(ctx, 401, data, err.Error())
		return
	}

	today := time.Now().Format("2006-01-02")

	err = services.QcServiceInstance.SendRepackingMail(databaseType, today, data, returnMap)
	if err != nil {
		log.Printf("error occurs while sending mail: %v\n", err)
		response.FailWithDetailed(ctx, http.StatusInternalServerError, data, err.Error())
		return
	}

	response.OkWithData(ctx, data)
}

func (tqc *QcController) CheckRQCActive(ctx *gin.Context) {
	databaseType := ctx.Query("db")
	datetime := ctx.Query("datetime")

	startTime, endTime, err := services.QcServiceInstance.GetRQCCheckTimeRange(datetime, -1*time.Hour)
	if err != nil {
		response.FailWithDetailed(ctx, 400, nil, "fail to convert datetime: "+err.Error())
		return
	}

	isActive, err := services.QcServiceInstance.CheckRQCActive(databaseType, startTime, endTime)
	if err != nil {
		response.FailWithMessage(ctx, "fail to check RQC active: "+err.Error())
		return
	}

	timeStr := services.QcServiceInstance.GenerateTimeString(startTime, endTime)

	if isActive {
		response.OkWithMessage(ctx, "RQC checked: Active in time "+timeStr)
	} else {
		utils.MailSenderInstance.SendEmailRQCCheck(databaseType, timeStr)
		response.OkWithMessage(ctx, "RQC checked: No inspection found. Warning mail sended!")
	}

}
