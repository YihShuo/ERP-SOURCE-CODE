package controllers

import (
	"fmt"
	"log"
	"web-api/internal/api/services"
	"web-api/internal/integration/deckers"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/models/response"

	"github.com/gin-gonic/gin"
)

type dtdTrackingController struct {
}

var DtdTrackingController = &dtdTrackingController{}

func (d *dtdTrackingController) GetReport(ctx *gin.Context) {

	khpo := ctx.Query("po")
	startDate := ctx.Query("from")
	endDate := ctx.Query("to")
	factory := ctx.Query("factory")

	data, err := services.PoReportService.GetReport(khpo, startDate, endDate, factory)
	if err != nil {
		msg := fmt.Sprintf("error when getting po report from db: %v", err)
		log.Println(msg)
		response.FailWithMessage(ctx, msg)
		return
	}
	rawData, err := services.PoReportService.GetRawReport(khpo, startDate, endDate, factory)
	if err != nil {
		msg := fmt.Sprintf("error when getting raw po report from db: %v", err)
		log.Println(msg)
		response.FailWithMessage(ctx, msg)
		return
	}
	result := services.PoReportService.MapReport(rawData, data)

	response.OkWithData(ctx, result)
}

func (d *dtdTrackingController) GetEPCPulling(ctx *gin.Context) {

	po := ctx.Query("po")
	factoryWorkOrder := ctx.Query("factoryWorkOrder")
	commandNumber := ctx.Query("commandNumber")
	databaseType := ctx.Query("db")

	token := jwt.GetJWT(databaseType)

	data, err := services.DtdTrackingService.GetEPCPulling(token, factoryWorkOrder, po, commandNumber)
	if err != nil {
		log.Printf("Get EPC Pulling failed: %v\n", err)
		response.FailWithMessage(ctx, "Get EPC Pulling failed: "+err.Error())
		return
	}

	response.OkWithData(ctx, data)
}

func (d *dtdTrackingController) SaveEPCData(ctx *gin.Context) {
	databaseType := ctx.Query("db")

	var req []deckers.EpcPullingApiResponse
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		log.Printf("Invalid JSON: %v\n", err)
		return
	}

	err := services.DtdTrackingService.SaveEPCPulling(databaseType, req)
	if err != nil {
		response.FailWithMessage(ctx, "Save EPC Pulling failed: "+err.Error())
		log.Printf("Save EPC Pulling failed: %v\n", err)
		return
	}
	response.Ok(ctx)
}

func (d *dtdTrackingController) CheckEPCData(ctx *gin.Context) {
	databaseType := ctx.Query("db")

	var epcList []string
	if err := ctx.ShouldBindJSON(&epcList); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		log.Printf("Invalid JSON: %v\n", err)
		return
	}

	epcMap, err := services.DtdTrackingService.CheckEpcInDatabase(databaseType, epcList)
	if err != nil {
		response.FailWithMessage(ctx, "Check EPC Data failed: "+err.Error())
		log.Printf("Check EPC Data failed: %v\n", err)
		return
	}
	response.OkWithData(ctx, epcMap)
}

func (d *dtdTrackingController) GetResentHistoryList(ctx *gin.Context) {

	khpo := ctx.Query("po")
	startDate := ctx.Query("from")
	endDate := ctx.Query("to")
	factory := ctx.Query("factory")

	data, err := services.PoReportService.GetDashboardResentPo(khpo, startDate, endDate, factory)
	if err != nil {
		log.Printf("Get Resent History List failed: %v\n", err)
		response.FailWithMessage(ctx, "Get Resent History List failed: "+err.Error())
		return
	}

	response.OkWithData(ctx, data)
}
