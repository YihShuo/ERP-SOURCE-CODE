package controllers

import (
	"fmt"
	"log"
	"net/http"
	"web-api/internal/api/repo"
	"web-api/internal/api/services"

	"time"
	"web-api/internal/pkg/config"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/models/request"
	"web-api/internal/pkg/models/response"
	"web-api/internal/pkg/models/types"
	"web-api/internal/pkg/utils"

	"github.com/gin-gonic/gin"
)

type deckersResentController struct {
	*baseController
}

var DeckersReSentController = &deckersResentController{}

func (c *deckersResentController) ResubmitPoByListHandler(ctx *gin.Context) {
	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// if !compareDatabase(ctx, req.DatabaseType) {
	// 	response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	// 	return
	// }

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, rawData, err := services.PoStatusService.GetDailyPoStatusByPOList(req.DatabaseType, req.Date, req.PoList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "GetDailyPoStatusByPOList: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
		return
	}
	response.OkWithData(ctx, data)

	report := services.PoStatusService.ExportPoReport(data)
	rawReport := services.PoStatusService.ExportPoReport(rawData)
	idMap, err := services.PoReportService.SavePOExcelReports(req.DatabaseType, report, true, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SavePOExcelReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}
	err = services.PoReportService.SaveRawPOReports(req.DatabaseType, rawReport, idMap)
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SaveRawPOReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}

	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, data, token, getAuthUserID(ctx))
}

func (c *deckersResentController) ResubmitSpecialPoByListHandler(ctx *gin.Context) {
	// 1. 定義新的 Request 結構，直接接收 data 陣列
	type Request struct {
		DatabaseType string                `json:"databaseType"`
		Data         []types.DailyPoStatus `json:"data"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// 2. 驗證資料是否為空
	if len(req.Data) == 0 {
		response.FailWithMessage(ctx, "data cannot be empty")
		return
	}

	// 3. 取得 JWT Token 並直接發送資料
	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, req.Data, token, getAuthUserID(ctx))

	// 4. 回傳成功回應
	response.Ok(ctx)
}

func (c *deckersResentController) ResubmitFullFG10PoListHandler(ctx *gin.Context) {
	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// if !compareDatabase(ctx, req.DatabaseType) {
	// 	response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	// 	return
	// }

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, rawData, err := services.PoStatusService.GetFullFG10POList(req.DatabaseType, req.Date, req.PoList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "GetFullFG10POList: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
		return
	}
	response.OkWithData(ctx, data)

	report := services.PoStatusService.ExportPoReport(data)
	rawReport := services.PoStatusService.ExportPoReport(rawData)
	idMap, err := services.PoReportService.SavePOExcelReports(req.DatabaseType, report, true, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SavePOExcelReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}
	err = services.PoReportService.SaveRawPOReports(req.DatabaseType, rawReport, idMap)
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SaveRawPOReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}

	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, data, token, getAuthUserID(ctx))
}

func (c *deckersResentController) ResubmitPoListByDatabaseHandler(ctx *gin.Context) {

	var req request.PoListDb
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, rawData, err := services.PoStatusService.GetPOListByDatabaseInfo(req)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "GetDailyPoStatusByPOList: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
		return
	}
	response.OkWithData(ctx, data)

	report := services.PoStatusService.ExportPoReport(data)
	rawReport := services.PoStatusService.ExportPoReport(rawData)
	idMap, err := services.PoReportService.SavePOExcelReports(req.DatabaseType, report, true, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SavePOExcelReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}
	err = services.PoReportService.SaveRawPOReports(req.DatabaseType, rawReport, idMap)
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "ListPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SaveRawPOReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}

	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, data, token, getAuthUserID(ctx))
}

func (c *deckersResentController) SendPoByPayload(ctx *gin.Context) {

	databaseType := ctx.Query("db")

	var requestBody []types.DailyPoStatus
	if err := ctx.ShouldBindJSON(&requestBody); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	response.OkWithData(ctx, requestBody)

	report := services.PoStatusService.ExportPoReport(requestBody)
	_, err := services.PoReportService.SavePOExcelReports(databaseType, report, true, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
	}

	token := jwt.GetJWT(databaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(databaseType, requestBody, token, getAuthUserID(ctx))
}

func (c *deckersResentController) ResubmitCancelPoByRyListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		KeyList      []string `json:"keyList"` // "DH2604-724:100634148:85586414" = RY:PO:ShipID
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// if !compareDatabase(ctx, req.DatabaseType) {
	// 	response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	// 	return
	// }

	if len(req.KeyList) == 0 {
		response.FailWithMessage(ctx, "KeyList cannot be empty")
		return
	}

	RyMap := services.HandleRyMap(req.KeyList)

	data, err := services.PoStatusService.GetDailyPoStatusCancelByKeyList(req.DatabaseType, req.Date, RyMap)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)

	report := services.PoStatusService.ExportCancelPoReport(data)
	rawReport := services.PoStatusService.ExportPoReport(data)
	idMap, err := services.PoReportService.SavePOExcelReports(req.DatabaseType, report, true, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "CancelPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SavePOExcelReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
		return
	}

	err = services.PoReportService.SaveRawPOReports(req.DatabaseType, rawReport, idMap)
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "CancelPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SaveRawPOReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
		return
	}

	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, data, token, getAuthUserID(ctx))
}

func (c *deckersResentController) ResubmitPoByDDBHListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		DDBHMapStr   []string `json:"ddbh"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	if len(req.DDBHMapStr) == 0 {
		response.FailWithMessage(ctx, "ddbh cannot be empty")
		return
	}

	data, rawData, err := services.PoStatusService.GetDailyPoStatusByDDBHList(req.DatabaseType, req.Date, req.DDBHMapStr)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)

	report := services.PoStatusService.ExportPoReport(data)
	rawReport := services.PoStatusService.ExportPoReport(rawData)
	idMap, err := services.PoReportService.SavePOExcelReports(req.DatabaseType, report, true, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
	}
	err = services.PoReportService.SaveRawPOReports(req.DatabaseType, rawReport, idMap)
	if err != nil {
		log.Println(err)
	}

	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, data, token, getAuthUserID(ctx))
}

func (c *deckersResentController) ResubmitDailyPOHandler(ctx *gin.Context) {

	date := ctx.Query("date")
	databaseType := ctx.Query("db")

	data, rawData, err := services.PoStatusService.GetDailyPoStatus(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "GetDailyPoStatus: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(databaseType, poLog)
		return
	}

	preloadData, preloadRawData, err := services.PoStatusService.GetDailyPoStatusPreload(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "GetDailyPoStatusPreload: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(databaseType, poLog)
		return
	}

	data = append(data, preloadData...)
	rawData = append(rawData, preloadRawData...)

	log.Printf("PO length: %v\n", len(data))

	report := services.PoStatusService.ExportPoReport(data)
	rawReport := services.PoStatusService.ExportPoReport(rawData)
	idMap, err := services.PoReportService.SavePOExcelReports(databaseType, report, false, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SavePOExcelReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(databaseType, poLog)
	}
	err = services.PoReportService.SaveRawPOReports(databaseType, rawReport, idMap)
	if err != nil {
		log.Printf("Failed to save raw DailyPO: %v", err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SaveRawPOReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(databaseType, poLog)
	}

	token := jwt.GetJWT(databaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(databaseType, data, token, getAuthUserID(ctx))

	response.OkWithData(ctx, data)
}

func (c *deckersResentController) ResubmitDailyPOPreloadHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		RyList       []string `json:"ryList"`
	}
	var req Request

	if err := c.ValidateReqParams(ctx, &req); err != nil {
		response.FailWithDetailed(ctx, http.StatusBadRequest, nil, err.Error())
		return
	}

	fmt.Println(req.RyList)
	data, rawData, err := services.PoStatusService.GetDailyPoStatusPreloadByRyList(req.DatabaseType, req.Date, req.RyList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "GetDailyPoStatus: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
		return
	}

	log.Printf("PO length: %v\n", len(data))

	report := services.PoStatusService.ExportPoReport(data)
	rawReport := services.PoStatusService.ExportPoReport(rawData)
	idMap, err := services.PoReportService.SavePOExcelReports(req.DatabaseType, report, false, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SavePOExcelReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}
	err = services.PoReportService.SaveRawPOReports(req.DatabaseType, rawReport, idMap)
	if err != nil {
		log.Printf("Failed to save raw DailyPO: %v", err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SaveRawPOReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}

	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, data, token, getAuthUserID(ctx))

	response.OkWithData(ctx, data)
}

func (c *deckersResentController) ResendMailDailyPO(ctx *gin.Context) {

	date := ctx.Query("date")
	databaseType := ctx.Query("db")
	dbFactory, err := utils.GetFactoryByDatabaseType(databaseType)
	if err != nil {
		response.FailWithDetailed(ctx, http.StatusBadRequest, nil, err.Error())
	}

	data, err := services.PoReportService.GetReport("", date, date, dbFactory)
	if err != nil {
		log.Println("Failed to get POdata: " + err.Error())
		return
	}

	filename := "po-report/" + date + "-DailyPO-" + dbFactory + ".xlsx"

	// Write excel file
	err = utils.WriteStructsToExcel(filename, "DailyPO", data)
	if err != nil {
		log.Println("cannot export excel file: " + err.Error())
	}

	// Send mail with excel file attachment
	err = utils.MailSenderInstance.SendEmailWithAttachment(databaseType, filename, date)
	if err != nil {
		log.Println("fail to send email: " + err.Error())
	}

	// Remove excel file to save memory
	defer utils.DeleteFile(filename)

	response.OkWithData(ctx, data)
}

func (c *deckersResentController) ResubmitDailyPOWithCustomDBInfo(ctx *gin.Context) {

	var req request.PoListDb
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	data, rawData, err := services.PoStatusService.GetDailyPoStatusByDatabaseInfo(req)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "GetDailyPoStatusByDatabaseInfo: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
		return
	}

	preloadData, preloadRawData, err := services.PoStatusService.GetDailyPoStatusPreloadByDatabaseInfo(req)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "GetDailyPoStatusPreloadByDatabaseInfo: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
		return
	}

	data = append(data, preloadData...)
	rawData = append(rawData, preloadRawData...)

	log.Printf("PO length: %v\n", len(data))

	report := services.PoStatusService.ExportPoReport(data)
	rawReport := services.PoStatusService.ExportPoReport(rawData)
	idMap, err := services.PoReportService.SavePOExcelReports(req.DatabaseType, report, false, getAuthUserID(ctx))
	if err != nil {
		log.Println(err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SavePOExcelReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}
	err = services.PoReportService.SaveRawPOReports(req.DatabaseType, rawReport, idMap)
	if err != nil {
		log.Printf("Failed to save raw DailyPO: %v", err)
		poLog := types.PoLog{
			AppName:  "dtd",
			Function: "DailyPo",
			LogDate:  time.Now(),
			Source:   "api",
			Env:      config.GetEnvironment(),
			Message:  "SaveRawPOReports: " + err.Error(),
		}
		err = repo.LogRepositoryInstance.SavePoLog(req.DatabaseType, poLog)
	}

	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, data, token, getAuthUserID(ctx))

	response.OkWithData(ctx, data)
}

func (dc *deckersResentController) ResubmitWIPHandler(ctx *gin.Context) {
	dateStr := ctx.Query("date") // 只傳 yyyy-MM-dd 格式，例如 2025-05-29
	databaseType := ctx.Query("db")

	// 解析成 time.Time
	baseDate, err := time.Parse("2006-01-02", dateStr)
	if err != nil {
		response.FailWithMessage(ctx, "Invalid date format, use yyyy-MM-dd")
		return
	}

	token := jwt.GetJWT(databaseType)
	// 時間範圍：09:00 到 21:00，每小時跑一次（含 09:00、含 21:00）
	for hour := 9; hour <= 21; hour++ {
		timestamp := baseDate.Add(time.Duration(hour) * time.Hour)
		timeStr := timestamp.Format("2006-01-02 15:04:05")
		log.Printf("Fetching WIP for time: %s\n", timeStr)

		data, err := services.OutputsWIPService.GetDeckerOutputsWIP(databaseType, timeStr)

		err = services.WIPReportServiceInstance.SaveWIPHourlyReport(databaseType, data)
		if err != nil {
			msg := fmt.Sprintf("error saving WIP hourly log: %v", err)
			log.Println(msg)
		}

		services.DeckersPostServiceInstance.PostDeckerOutputWIP(databaseType, data, token)
	}

	response.OkWithMessage(ctx, "WIP 資料重新上傳完成")
}

func (c *deckersResentController) ResubmitRMHandler(ctx *gin.Context) {

	date := ctx.Query("date")

	databaseType := GetDatabaseType()

	data, err := services.OutputsRMService.GetDeckerOutputsRM(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get RM data: "+err.Error())
		return
	}

	token := jwt.GetJWT(databaseType)

	services.DeckersPostServiceInstance.PostDeckerOutputsRM(data, databaseType, token)

	response.OkWithData(ctx, data)
}

func (c *deckersResentController) ResubmitFGHandler(ctx *gin.Context) {
	date := ctx.Query("date")
	log.Println(date)

	databaseType := GetDatabaseType()

	data, err := services.OutputsFGService.GetDeckerOutputsFG(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get FGdata: "+err.Error())
		return
	}

	token := jwt.GetJWT(databaseType)

	services.DeckersPostServiceInstance.PostDeckerOutputsFG(data, databaseType, token)

	response.OkWithData(ctx, data)
}

func (dc *deckersResentController) ResendWeeklyFG(ctx *gin.Context) {

	databaseType := ctx.Query("db")

	data, err := services.PoReportService.GetFGReportWithReturnID(databaseType)
	if err != nil {
		msg := fmt.Sprintf("error when getting po report from db: %v", err)
		log.Println(msg)
		response.FailWithMessage(ctx, msg)
		return
	}
	response.OkWithData(ctx, data)

	filename := "po-report/Weekly-Deckers_FG.xlsx"
	err = utils.WriteStructsToExcelFGReport(filename, "Weekly FG", data)
	if err != nil {
		log.Printf("err getting FG report: %v", err)
	}
	utils.MailSenderInstance.SendEmailWithFGReport(databaseType, filename)
	defer utils.DeleteFile(filename)
}
