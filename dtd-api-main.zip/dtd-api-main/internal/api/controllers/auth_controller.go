package controllers

import (
	"web-api/internal/api/middlewares"
	"web-api/internal/api/services"
	"web-api/internal/pkg/models/request"
	"web-api/internal/pkg/models/response"

	"github.com/gin-gonic/gin"
)

type authController struct {
}

var AuthController authController

func (a *authController) LoginHandler(ctx *gin.Context) {

	var req request.AuthRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithDetailed(ctx, 400, nil, err.Error())
		return
	}

	user, err := services.AuthService.VerifyLogin(req)
	if err != nil {
		response.FailWithMessage(ctx, "Verify failed: "+err.Error())
		return
	}

	if user.UserID == "" {
		response.FailWithDetailed(ctx, 401, nil, "Verify failed: USER invalid")
		return
	}

	token, err := middlewares.GenerateToken(user)
	result := map[string]string{
		"token": token,
	}
	response.OkWithData(ctx, result)

}
