package controllers

import (
	"time"
	"web-api/internal/api/middlewares"
	"web-api/internal/pkg/models/response"
	"web-api/internal/pkg/utils"

	"github.com/gin-gonic/gin"
)

type CommonController struct {
}

var Common = &CommonController{}

func (c *CommonController) Ping(ctx *gin.Context) {
	response.OkWithData(ctx, "System time: "+time.Now().Format("2006-01-02 15:04:05"))
}

func (c *CommonController) Test(ctx *gin.Context) {
	response.OkWithData(ctx, "FIX: Save PO report")
}

func getAuthUserID(ctx *gin.Context) string {
	userID := ""
	userClaims, err := middlewares.GetUserClaims(ctx)
	if err == nil {
		userID = userClaims.UserID
	}
	return userID
}

func compareDatabase(ctx *gin.Context, requestDatabaseType string) bool {
	factory := ""
	userClaims, err := middlewares.GetUserClaims(ctx)
	if err == nil {
		factory = userClaims.Factory
	}

	userDatabaseType, _ := utils.GetDatabaseTypeByFactory(factory)
	if userDatabaseType != requestDatabaseType {
		return false
	}
	return true
}
