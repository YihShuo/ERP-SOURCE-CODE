package controllers

import (
	"fmt"
	"log"
	"net/http"
	"time"
	"web-api/internal/api/services"
	"web-api/internal/pkg/config"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/models/request"
	"web-api/internal/pkg/models/response"
	"web-api/internal/pkg/models/types"
	"web-api/internal/pkg/utils"

	"github.com/gin-gonic/gin"
)

type deckersController struct {
}

var DeckersControllerInstance = &deckersController{}

func GetDatabaseType() string {
	return config.GetConfig().Database.DatabaseType
}

func (c *deckersController) GetTokenHandler(ctx *gin.Context) {
	var databaseType = ctx.Query("db")
	token := jwt.GetJWT(databaseType)
	response.OkWithToken(ctx, token)
}

func (c *deckersController) GetUatTokenHandler(ctx *gin.Context) {
	var databaseType = ctx.Query("db")
	token := jwt.GetTestJWT(databaseType)
	response.OkWithToken(ctx, token)
}

func (c *deckersController) GetOutputsFGHandler(ctx *gin.Context) {
	date := ctx.Query("date")
	log.Println(date)

	databaseType := GetDatabaseType()

	data, err := services.OutputsFGService.GetDeckerOutputsFG(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get FGdata: "+err.Error())
		return
	}

	response.OkWithData(ctx, data)
}

func (c *deckersController) GetOutputsPOHandler(ctx *gin.Context) {

	date := ctx.Query("date")
	databaseType := ctx.Query("db")

	data, _, err := services.PoStatusService.GetDailyPoStatus(databaseType, date)
	// data, _, err := services.UatPoStatusService.GetUatDailyPoStatus(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	fmt.Println(data)

	preloadData, _, err := services.PoStatusService.GetDailyPoStatusPreload(databaseType, date)
	// preloadData, _, err := services.UatPoStatusService.GetUatDailyPoStatusPreload(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	data = append(data, preloadData...)

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)

	if len(preloadData) == 0 {
		return
	}

	// report := services.PoStatusService.ExportPoReport(data)

	// filename := GetFilename(databaseType, date, "DailyPo")
	// SendMail(filename, databaseType, date, "DailyPo", report)

	// rawReport := services.PoStatusService.ExportPoReport(rawData)
	// _, err = services.PoReportService.SavePOExcelReports(databaseType, report)
	// if err != nil {
	// 	log.Println(err)
	// }
	// services.PoReportService.SaveRawPOReports(databaseType, rawReport, idMap)

	// token := jwt.GetJWT(databaseType)
	// services.DeckersPostServiceInstance.PostDailyPoStatus(databaseType, data, token)
}

func (c *deckersController) GetNightExportPo(ctx *gin.Context) {

	date := ctx.Query("date")
	databaseType := ctx.Query("db")

	data, _, err := services.PoStatusService.GetNightExportPo(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetDailyPoStatusByStyleNameColorCodeListHandler(ctx *gin.Context) {
	type Request struct {
		Date   string   `json:"date"`
		ScList []string `json:"scList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	databaseType := GetDatabaseType()

	data, err := services.PoStatusService.GetDailyPoStatusByStyleNameColorCodeList(databaseType, req.Date, req.ScList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get PO data: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetPoMissingShipIDHandler(ctx *gin.Context) {

	databaseType := ctx.Query("databaseType")

	data, err := services.PoStatusService.GetPoMissingShipID(databaseType)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	// filename := GetFilename(databaseType, time.Now().Format("2006-01-02"), "EmptyShipID")
	// to, cc := GetMailRecipients()
	// utils.WriteStructsToExcelEmptyShipID(filename, "PO", data)
	// utils.MailSenderInstance.SendEmailWithEmptyShipID(databaseType, filename, to, cc)
	// utils.DeleteFile(filename)

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetPoByListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// if !compareDatabase(ctx, req.DatabaseType) {
	// 	response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	// 	return
	// }

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, _, err := services.PoStatusService.GetDailyPoStatusByPOList(req.DatabaseType, req.Date, req.PoList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	token := jwt.GetJWT(req.DatabaseType)
	services.DeckersPostServiceInstance.PostDailyPoStatus(req.DatabaseType, data, token, getAuthUserID(ctx))

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetXFPoByListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// if !compareDatabase(ctx, req.DatabaseType) {
	// 	response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	// 	return
	// }

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, _, err := services.PoStatusService.GetXFShippedPoStatusByPOList(req.DatabaseType, req.Date, req.PoList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetXFPoHandler(ctx *gin.Context) {

	type Request struct {
		DatabaseType string `json:"databaseType"`
		StartDate    string `json:"startDate"`
		EndDate      string `json:"endDate"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	if req.StartDate == "" || req.EndDate == "" {
		response.FailWithMessage(ctx, "startDate 和 endDate 為必填欄位，不能為空")
		return
	}

	// 驗證日期格式（假設前端傳入的是 "YYYY-MM-DD" 格式，Go 的標準模板是 "2006-01-02"）
	const dateFormat = "2006-01-02"

	start, err := time.Parse(dateFormat, req.StartDate)
	if err != nil {
		response.FailWithMessage(ctx, "startDate 格式錯誤，必須為 YYYY-MM-DD (例如: 2026-01-01)")
		return
	}

	end, err := time.Parse(dateFormat, req.EndDate)
	if err != nil {
		response.FailWithMessage(ctx, "endDate 格式錯誤，必須為 YYYY-MM-DD (例如: 2026-05-27)")
		return
	}

	// 驗證邏輯：開始時間不能晚於結束時間
	if start.After(end) {
		response.FailWithMessage(ctx, "日期邏輯錯誤：startDate 不能晚於 endDate")
		return
	}
	// ==========================================

	// if !compareDatabase(ctx, req.DatabaseType) {
	//  response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	//  return
	// }

	data, _, err := services.PoStatusService.GetXFShippedPoStatus(req.DatabaseType, req.StartDate, req.EndDate)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetSpecialPoByListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// if !compareDatabase(ctx, req.DatabaseType) {
	// 	response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	// 	return
	// }

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, _, err := services.PoStatusService.GetDailySpecialPoStatusByPOList(req.DatabaseType, req.Date, req.PoList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetPoListByDatabaseInfoHandler(ctx *gin.Context) {

	var req request.PoListDb
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, _, err := services.PoStatusService.GetPOListByDatabaseInfo(req)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetUatDailyPoByListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, _, err := services.PoStatusService.GetDailyPoStatusByPOList(req.DatabaseType, req.Date, req.PoList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetDailyPreloadByRyListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		RyList       []string `json:"ryList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	if len(req.RyList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, _, err := services.PoStatusService.GetDailyPoStatusPreloadByRyList(req.DatabaseType, req.Date, req.RyList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetCancelPoByRyListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		KeyList      []string `json:"keyList"` // "DH2604-724:100634148:85586414" = RY:PO:ShipID
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// if !compareDatabase(ctx, req.DatabaseType) {
	// 	response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	// 	return
	// }

	if len(req.KeyList) == 0 {
		response.FailWithMessage(ctx, "KeyList cannot be empty")
		return
	}

	RyMap := services.HandleRyMap(req.KeyList)

	data, err := services.PoStatusService.GetDailyPoStatusCancelByKeyList(req.DatabaseType, req.Date, RyMap)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetPoByDDBHListHandler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		DDBHList     []string `json:"ddbh"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	if len(req.DDBHList) == 0 {
		response.FailWithMessage(ctx, "ddbh cannot be empty")
		return
	}

	data, _, err := services.PoStatusService.GetDailyPoStatusByDDBHList(req.DatabaseType, req.Date, req.DDBHList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get POdata: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetOutputsRMHandler(ctx *gin.Context) {

	date := ctx.Query("date")

	databaseType := GetDatabaseType()

	data, err := services.OutputsRMService.GetDeckerOutputsRM(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get RM data: "+err.Error())
		return
	}

	response.OkWithData(ctx, data)
}

func (dc *deckersController) GetOutputsWIPHandler(ctx *gin.Context) {

	date := ctx.Query("date")
	databaseType := ctx.Query("db")

	data, err := services.OutputsWIPService.GetDeckerOutputsWIP(databaseType, date)

	if err != nil {
		response.FailWithMessage(ctx, "Fail to get WIP data: "+err.Error())
		return
	}

	err = services.WIPReportServiceInstance.SaveWIPHourlyReport(databaseType, data)
	if err != nil {
		msg := fmt.Sprintf("error saving WIP hourly log: %v", err)
		log.Println(msg)
	}

	token := jwt.GetJWT(databaseType)
	services.DeckersPostServiceInstance.PostDeckerOutputWIP(databaseType, data, token)

	response.OkWithData(ctx, data)
}

func (dc *deckersController) GetOutputsLeanHandler(ctx *gin.Context) {

	databaseType := GetDatabaseType()

	data, err := services.CommonService.GetRecentProductionLines(databaseType)
	if err != nil {
		response.FailWithMessage(ctx, "Fail to get recent leans data: "+err.Error())
		return
	}

	response.OkWithData(ctx, data)
}

func (dc *deckersController) GetProcessingPoYS(ctx *gin.Context) {

	date := ctx.Query("date")

	databaseType := GetDatabaseType()

	data, err := services.InitializeService.GetProcessingPoYS(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Fail to get processing PO data: "+err.Error())
		return
	}

	// if databaseType == "A" {
	// 	utils.WriteStructsToJSONFile(data, "po-result/YS-PO.json")
	// } else {
	// 	utils.WriteStructsToJSONFile(data, "po-result/YQ-PO.json")
	// }

	response.OkWithData(ctx, data)
}

func (dc *deckersController) GetProcessingPoTB(ctx *gin.Context) {

	date := ctx.Query("date")

	databaseType := config.GetConfig().Database.DatabaseType

	data, err := services.InitializeService.GetProcessingPoTB(databaseType, date)
	if err != nil {
		response.FailWithMessage(ctx, "Fail to get processing PO data: "+err.Error())
		return
	}

	// utils.WriteStructsToJSONFile(data, "po-result/TB-PO.json")
	// token := jwt.GetJWT(databaseType)
	// services.DeckersPostServiceInstance.PostDailyPoStatus(databaseType, data, token)

	response.OkWithData(ctx, data)
}

func (dc *deckersController) UploadExcelPoStatus(ctx *gin.Context) {

	date := time.Now().Format("2006-01-02")

	// Get file from request
	file, err := ctx.FormFile("file")
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{"error": "Không tìm thấy file"})
		return
	}

	result, err := services.PoStatusService.GetExcelPoMap(file, date)
	if err != nil {
		response.FailWithMessage(ctx, err.Error())
		return
	}

	response.OkWithData(ctx, result)
}

func GetFilename(databaseType, date, filetype string) string {
	dbFactory := ""
	switch databaseType {
	case "A":
		dbFactory = "YS"
	case "B":
		dbFactory = "TB"
	case "C":
		dbFactory = "YQ"
	}
	return "po-report/" + date + "-" + filetype + "-" + dbFactory + ".xlsx"
}

func GetWIPFilename(databaseType, date, filetype string) string {
	dbFactory := ""
	switch databaseType {
	case "A":
		dbFactory = "YS"
	case "B":
		dbFactory = "TB"
	case "C":
		dbFactory = "YQ"
	}
	return "po-report/" + dbFactory + "_" + filetype + "_" + date + ".xlsx"
}

func GetFilenameWithoutFactory(date, filetype string) string {
	return "po-report/" + filetype + "_" + date + ".xlsx"
}

func SendMail(filename, databaseType, date, po string, report []types.POExcelReport) {
	err := utils.WriteStructsToExcel(filename, po, report)
	if err != nil {
		log.Println("cannot export excel file: " + err.Error())
	}

	err = utils.MailSenderInstance.SendEmailWithAttachment(databaseType, filename, date)
	if err != nil {
		log.Println("fail to send email: " + err.Error())
	}

	utils.DeleteFile(filename)
}

func (dc *deckersController) GetFGReport(ctx *gin.Context) {

	databaseType := ctx.Query("db")

	data, err := services.PoReportService.GetFGReportWithReturnID(databaseType)
	if err != nil {
		msg := fmt.Sprintf("error when getting po report from db: %v", err)
		log.Println(msg)
		response.FailWithMessage(ctx, msg)
		return
	}
	response.OkWithData(ctx, data)

	// filename := "po-report/Weekly-Deckers_FG.xlsx"
	// err = utils.WriteStructsToExcelFGReport(filename, "Weekly FG", data)
	// if err != nil {
	// 	log.Printf("err getting FG report: %v", err)
	// }
	// utils.MailSenderInstance.SendEmailWithFGReport(databaseType, filename)
	// defer utils.DeleteFile(filename)
}

func (dc *deckersController) GetWIP(ctx *gin.Context) {

	date := ctx.Query("date")
	databaseType := ctx.Query("db")

	data, err := services.OutputsWIPService.GetDeckerOutputsWIPByDate(databaseType, date)
	if err != nil {
		msg := fmt.Sprintf("error when getting po report from db: %v", err)
		log.Println(msg)
		response.FailWithMessage(ctx, msg)
		return
	}
	response.OkWithData(ctx, data)

	filename := GetWIPFilename(databaseType, date, "WIP")
	err = utils.WriteWIPToExcel(filename, "WIP_"+date, data)
	if err != nil {
		log.Printf("err getting FG report: %v", err)
	}
	// utils.MailSenderInstance.SendEmailWithFGReport(databaseType, filename)
	// defer utils.DeleteFile(filename)
}

func (dc *deckersController) GetDelayWarningOrder(ctx *gin.Context) {

	data, err := services.DelayWarningService.GetDelayWaringOrder()
	if err != nil {
		msg := fmt.Sprintf("error when getting waring orders from db: %v", err)
		log.Println(msg)
		response.FailWithMessage(ctx, msg)
		return
	}
	response.OkWithData(ctx, data)

	if len(data) == 0 {
		return
	}
	// date := time.Now().Format("2006-01-02")

	// filename := GetFilenameWithoutFactory(date, "ERP potential delay warning")
	// err = utils.WriteStructsToExcelDelayWarning(filename, date, data)
	// if err != nil {
	// 	log.Printf("err getting FG report: %v", err)
	// }
	// utils.MailSenderInstance.SendEmailWithWarningOrder(filename)
	// defer utils.DeleteFile(filename)
}

func (dc *deckersController) RemoveAndBackupWIPHourly(ctx *gin.Context) {

	databaseType := ctx.Query("db")

	err := services.WIPReportServiceInstance.RemoveAndBackupWIPHourly(databaseType, 7)
	if err != nil {
		log.Printf("error remove or backup WIP: %v", err)
		response.FailWithMessage(ctx, err.Error())
		return
	}
	response.Ok(ctx)
}

func (dc *deckersController) GetAllBlacklistPo(ctx *gin.Context) {

	databaseType := ctx.Query("db")

	blacklist, err := services.PoBlacklistService.GetAllPoBlacklist(databaseType)
	if err != nil {
		log.Printf("error get PO blacklist: %v\n", err)
		response.FailWithMessage(ctx, err.Error())
		return
	}
	response.OkWithData(ctx, blacklist)
}

func (dc *deckersController) InsertBlacklistPo(ctx *gin.Context) {

	type Request struct {
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	err := services.PoBlacklistService.InsertPoBlacklist(req.DatabaseType, req.PoList)
	if err != nil {
		log.Printf("error insert PO blacklist: %v\n", err)
		response.FailWithMessage(ctx, err.Error())
		return
	}
	response.OkWithData(ctx, req.PoList)
}

func (dc *deckersController) DeleteBlacklistPo(ctx *gin.Context) {

	type Request struct {
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	err := services.PoBlacklistService.DeletePoBlacklist(req.DatabaseType, req.PoList)
	if err != nil {
		log.Printf("error delete PO blacklist: %v\n", err)
		response.FailWithMessage(ctx, err.Error())
		return
	}
	response.Ok(ctx)
}

func (c *deckersController) GetPoListWithFullFG10Handler(ctx *gin.Context) {

	type Request struct {
		Date         string   `json:"date"`
		DatabaseType string   `json:"databaseType"`
		PoList       []string `json:"poList"`
	}

	var req Request
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.FailWithMessage(ctx, "Invalid JSON: "+err.Error())
		return
	}

	// if !compareDatabase(ctx, req.DatabaseType) {
	// 	response.FailWithDetailed(ctx, 401, nil, "Authorize failed. Please login again")
	// 	return
	// }

	if len(req.PoList) == 0 {
		response.FailWithMessage(ctx, "poList cannot be empty")
		return
	}

	data, _, err := services.PoStatusService.GetFullFG10POList(req.DatabaseType, req.Date, req.PoList)
	if err != nil {
		response.FailWithMessage(ctx, "Failed to get PoListWithFullFG10: "+err.Error())
		return
	}

	log.Printf("PO length: %v\n", len(data))
	response.OkWithData(ctx, data)
}

func (c *deckersController) GetUnsyncPo(ctx *gin.Context) {
	date := ctx.Query("date")
	databaseType := ctx.Query("databaseType")

	data, err := services.DtdTrackingService.GetUnsyncPo(date, databaseType)
	if err != nil {
		msg := fmt.Sprintf("error getting unsync orders: %v", err.Error())
		log.Println(msg)
		response.FailWithMessage(ctx, msg)
		return
	}

	response.OkWithData(ctx, data)
}
