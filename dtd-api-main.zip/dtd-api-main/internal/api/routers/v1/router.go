package router_v1

import (
	"web-api/internal/api/middlewares"

	"github.com/gin-gonic/gin"
)

func Register(router *gin.Engine) {
	v1 := router.Group("/api/v1")

	// 1. NHÓM PUBLIC (Không cần Token)
	RegisterCommonRouter(v1.Group(""))
	RegisterReportRouter(v1.Group("/rp"))
	RegisterAdminRouter(v1.Group("/rp/admin"))
	RegisterDeckersRouter(v1.Group("/deckers"))
	RegisterQCRouter(v1.Group("/deckers/qc"))
	RegisterAuthRouter(v1.Group("/auth"))

	// 2. NHÓM PROTECTED (Bắt buộc có Token)
	// Tạo một group riêng cho dtd-tracking
	dtdTrackingGroup := v1.Group("/dtd-tracking")

	// Gắn middleware xác thực vào group này
	dtdTrackingGroup.Use(middlewares.AuthMiddleware())

	// Đăng ký router với group đã được bảo vệ
	RegisterDtdTrackingRouter(dtdTrackingGroup)

}
