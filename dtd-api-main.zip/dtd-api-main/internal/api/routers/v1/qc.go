package router_v1

import (
	"web-api/internal/api/controllers"

	"github.com/gin-gonic/gin"
)

func RegisterQCRouter(router *gin.RouterGroup) {
	router.GET("/tqc", controllers.QcControllerInstance.GetTqcOutput)
	router.GET("/rqc", controllers.QcControllerInstance.GetRqcOutput)
	router.GET("/rqc/active", controllers.QcControllerInstance.CheckRQCActive)
	router.GET("/repacking", controllers.QcControllerInstance.GetRepackingOutput)
	router.POST("/repacking/send", controllers.QcControllerInstance.SendRepackingOutput)
	router.POST("/repacking/send-by-po", controllers.QcControllerInstance.SendRepackingOutputByPO)
	router.GET("/b-grade-inventory", controllers.QcControllerInstance.GetBgradeOutput)
}
