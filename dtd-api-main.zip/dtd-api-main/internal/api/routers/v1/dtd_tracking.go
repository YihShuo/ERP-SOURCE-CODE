package router_v1

import (
	"web-api/internal/api/controllers"

	"github.com/gin-gonic/gin"
)

func RegisterDtdTrackingRouter(router *gin.RouterGroup) {

	// Get DATA
	router.POST("/PoList", controllers.DeckersControllerInstance.GetPoByListHandler)
	router.POST("/PoList/full-fg10", controllers.DeckersControllerInstance.GetPoListWithFullFG10Handler)
	router.POST("/PoList/cancel", controllers.DeckersControllerInstance.GetCancelPoByRyListHandler)
	router.POST("/PoList/special", controllers.DeckersControllerInstance.GetSpecialPoByListHandler)

	// Send DATA
	router.POST("/RePoList", controllers.DeckersReSentController.ResubmitPoByListHandler)
	router.POST("/RePoList/full-fg10", controllers.DeckersReSentController.ResubmitFullFG10PoListHandler)
	router.POST("/RePoList/cancel", controllers.DeckersReSentController.ResubmitCancelPoByRyListHandler)
	router.POST("/RePoList/special", controllers.DeckersReSentController.ResubmitPoByListHandler)

}
