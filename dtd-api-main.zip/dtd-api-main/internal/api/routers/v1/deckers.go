package router_v1

import (
	"web-api/internal/api/controllers"

	"github.com/gin-gonic/gin"
)

func RegisterDeckersRouter(router *gin.RouterGroup) {

	// APIs for Get Deckers token
	router.GET("/token", controllers.DeckersControllerInstance.GetTokenHandler)
	router.GET("/token/uat", controllers.DeckersControllerInstance.GetUatTokenHandler)

	// APIs for Get data for view
	router.GET("/FG", controllers.DeckersControllerInstance.GetOutputsFGHandler)
	router.GET("/PO", controllers.DeckersControllerInstance.GetOutputsPOHandler)
	router.GET("/PO/xf", controllers.DeckersControllerInstance.GetXFPoHandler)

	router.GET("/WIP", controllers.DeckersControllerInstance.GetOutputsWIPHandler)
	router.GET("/wip-hourly/backup", controllers.DeckersControllerInstance.RemoveAndBackupWIPHourly)
	router.GET("/WIP/day", controllers.DeckersControllerInstance.GetWIP)
	router.GET("/RM", controllers.DeckersControllerInstance.GetOutputsRMHandler)
	router.GET("/PO/YS", controllers.DeckersControllerInstance.GetProcessingPoYS)
	router.GET("/PO/TB", controllers.DeckersControllerInstance.GetProcessingPoTB)
	router.GET("/PoList", controllers.DeckersControllerInstance.GetPoByListHandler)
	router.GET("/PoList/xf", controllers.DeckersControllerInstance.GetXFPoByListHandler)
	router.GET("/daily-po/night-export", controllers.DeckersControllerInstance.GetNightExportPo)

	router.GET("/PoList/special", controllers.DeckersControllerInstance.GetSpecialPoByListHandler)
	router.POST("/PoList/database", controllers.DeckersControllerInstance.GetPoListByDatabaseInfoHandler)
	router.GET("/PoList/cancel", controllers.DeckersControllerInstance.GetCancelPoByRyListHandler)
	router.GET("/PoList/ddbh", controllers.DeckersControllerInstance.GetPoByDDBHListHandler)
	router.GET("/PoList/uat", controllers.DeckersControllerInstance.GetUatDailyPoByListHandler)
	router.GET("/PoList/preload", controllers.DeckersControllerInstance.GetDailyPreloadByRyListHandler)
	router.GET("/unsync-orders", controllers.DeckersControllerInstance.GetUnsyncPo)

	// APIs for Send data to Deckers
	router.GET("/RePoList", controllers.DeckersReSentController.ResubmitPoByListHandler)
	router.GET("/RePoList/special", controllers.DeckersReSentController.ResubmitSpecialPoByListHandler)

	router.POST("/RePoList/database", controllers.DeckersReSentController.ResubmitPoListByDatabaseHandler)
	router.POST("/RePoList/modify", controllers.DeckersReSentController.SendPoByPayload)
	router.GET("/RePoList/cancel", controllers.DeckersReSentController.ResubmitCancelPoByRyListHandler)
	router.GET("/RePoList/ddbh", controllers.DeckersReSentController.ResubmitPoByDDBHListHandler)
	router.GET("/RePoList/preload", controllers.DeckersReSentController.ResubmitDailyPOPreloadHandler)
	router.GET("/ReWIP", controllers.DeckersReSentController.ResubmitWIPHandler)
	router.GET("/ReDailyPO", controllers.DeckersReSentController.ResubmitDailyPOHandler)
	router.POST("/ReDailyPO/database", controllers.DeckersReSentController.ResubmitDailyPOWithCustomDBInfo)
	router.GET("/ReFG", controllers.DeckersReSentController.ResubmitFGHandler)
	router.GET("/ReRM", controllers.DeckersReSentController.ResubmitRMHandler)
	router.GET("/weekly-fg/resend", controllers.DeckersReSentController.ResendWeeklyFG)
	router.GET("/ReDailyPO/mail/excel", controllers.DeckersReSentController.ResendMailDailyPO)

	// APIs for DTD-Tracking
	router.GET("/report", controllers.DtdTrackingController.GetReport)
	router.GET("/report/resent-history", controllers.DtdTrackingController.GetResentHistoryList)
	router.GET("/epcs", controllers.DtdTrackingController.GetEPCPulling)
	router.POST("/epcs", controllers.DtdTrackingController.SaveEPCData)
	router.POST("/epcs/exists", controllers.DtdTrackingController.CheckEPCData)

	// API for sending mail
	router.GET("/delay-warning", controllers.DeckersControllerInstance.GetDelayWarningOrder)

	// API for blacklist PO
	router.GET("/daily-po/blacklist", controllers.DeckersControllerInstance.GetAllBlacklistPo)
	router.POST("/daily-po/blacklist", controllers.DeckersControllerInstance.InsertBlacklistPo)
	router.DELETE("/daily-po/blacklist", controllers.DeckersControllerInstance.DeleteBlacklistPo)

	router.GET("/report/fg", controllers.DeckersControllerInstance.GetFGReport)

	router.GET("/poinfo", controllers.DeckersControllerInstance.GetPoMissingShipIDHandler)

	router.GET("/SCPO", controllers.DeckersControllerInstance.GetDailyPoStatusByStyleNameColorCodeListHandler)

	router.POST("/upload", controllers.DeckersControllerInstance.UploadExcelPoStatus)

	router.GET("/Leans", controllers.DeckersControllerInstance.GetOutputsLeanHandler)

}
