package api

import (
	"fmt"
	"os"

	router "web-api/internal/api/routers"
	"web-api/internal/api/tasks"
	"web-api/internal/pkg/config"
	"web-api/internal/pkg/database"
	"web-api/pkg/logger"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

func Run(configPath string) {

	if os.Getenv("APP_ENV") == "" {
		_ = godotenv.Load()
	}

	env := os.Getenv("APP_ENV")
	if env == "" {
		env = "development"
	}

	fmt.Println("Current ENV:", env)

	if configPath == "" {
		configPath = "data/config.yml"
	}

	if err := config.Setup(configPath, env); err != nil {
		logger.Errorf("failed to setup config, %s", err)
	}

	// 初始化 DB
	if err := database.Setup(); err != nil {
		logger.Errorf("failed to setup database, %s", err)
	}

	cfg := config.GetConfig()

	gin.SetMode(cfg.Server.Mode)

	web := router.Setup()

	go func() {
		fmt.Println("Web API Running on port " + cfg.Server.Port + " in " + cfg.Server.Mode + " mode ")
		fmt.Println("================================->")
		if err := web.Run(":" + cfg.Server.Port); err != nil {
			logger.Fatalf("Failed to run web server: %s", err)
		}
	}()

	if config.GetEnvironment() == "production" {
		fmt.Println("Scheduler start in production")
		go tasks.StartScheduler()
	} else {
		fmt.Println("Scheduler disabled in development")
	}

	select {}
}
