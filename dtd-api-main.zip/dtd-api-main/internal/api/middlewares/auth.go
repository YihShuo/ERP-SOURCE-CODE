package middlewares

import (
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
	"web-api/internal/pkg/models/types"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
)

// Secret key (SHA256: qwertyuiop)
var jwtKey = []byte("mpAEA6wxO6J6G8gfCTJlK4Ag2sksI02Y+gsGvwBA7P0=")

// Claims đại diện cho dữ liệu bạn muốn lưu trong Token
type Claims struct {
	UserID   string `json:"user_id"`
	Factory  string `json:"factory"`
	Username string `json:"username"`
	jwt.RegisteredClaims
}

// GenerateToken: Hàm tạo JWT sau khi user đăng nhập đúng UserID/Pass từ DB
func GenerateToken(user types.UserInfo) (string, error) {
	expirationTime := time.Now().Add(24 * time.Hour) // Token có hạn 24h
	claims := &Claims{
		UserID:   user.UserID,
		Factory:  user.Factory,
		Username: user.Username,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expirationTime),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(jwtKey)
}

// AuthMiddleware: Middleware để bảo vệ các URL cần đăng nhập
func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 1. Lấy chuỗi Authorization từ Header
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Yêu cầu cung cấp token"})
			c.Abort()
			return
		}

		// 2. Kiểm tra định dạng Bearer <token>
		parts := strings.SplitN(authHeader, " ", 2)
		if !(len(parts) == 2 && parts[0] == "Bearer") {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Định dạng Token không hợp lệ (Bearer <token>)"})
			c.Abort()
			return
		}

		tokenString := parts[1]
		claims := &Claims{}

		// 3. Parse và Validate Token
		token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
			// Đảm bảo thuật toán ký là HS256
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("thuật toán ký không hợp lệ")
			}
			return jwtKey, nil
		})

		if err != nil || !token.Valid {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Token không hợp lệ hoặc đã hết hạn"})
			c.Abort()
			return
		}

		// Lưu toàn bộ struct Claims vào Context
		c.Set("user_claims", claims)
		c.Next()
	}
}

// GetUserClaims: Hàm tiện ích để lấy toàn bộ thông tin User từ Gin Context
func GetUserClaims(c *gin.Context) (*Claims, error) {
	// Lấy data từ context ra
	claimsData, exists := c.Get("user_claims")
	if !exists {
		return nil, errors.New("không tìm thấy thông tin user trong context")
	}

	// Ép kiểu (Type assertion) về đúng kiểu *Claims
	userClaims, ok := claimsData.(*Claims)
	if !ok {
		return nil, errors.New("dữ liệu claims không hợp lệ")
	}

	return userClaims, nil
}
