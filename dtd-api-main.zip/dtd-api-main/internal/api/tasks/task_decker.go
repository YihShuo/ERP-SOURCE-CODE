package tasks

import (
	"fmt"
	"log"
	"os"
	"time"
	"web-api/internal/api/repo"
	"web-api/internal/api/services"
	"web-api/internal/pkg/config"
	"web-api/internal/pkg/jwt"
	"web-api/internal/pkg/utils"
)

// Task 1 Hourly
func PostDeckerOutputsHourly() {

	databaseType := config.GetConfig().Database.DatabaseType

	currentTime := time.Now().Format("2006-01-02 15:04:05")

	fmt.Println("Running PostDeckerOutputsHourly at:", time.Now())

	// get token to use
	token := jwt.GetJWT(databaseType)

	deckerOutputsWIP, err := services.OutputsWIPService.GetDeckerOutputsWIP(databaseType, currentTime)
	if err != nil {
		log.Printf("Fail to get DeckerOutputsWIP: %v\n", err)
		return
	}

	err = services.WIPReportServiceInstance.SaveWIPHourlyReport(databaseType, deckerOutputsWIP)
	if err != nil {
		log.Printf("error saving WIP hourly log: %v\n", err)
	}

	services.DeckersPostServiceInstance.PostDeckerOutputWIP(databaseType, deckerOutputsWIP, token)
}

// Task 2 Daily
func PostDeckerOutputsDaily() {
	databaseType := config.GetConfig().Database.DatabaseType
	currentDate := time.Now().Format("2006-01-02")

	log.Println("Running PostDeckerOutputsDaily at:", time.Now())

	// tokens
	token := jwt.GetJWT(databaseType)

	// -------------------------
	// RM
	// -------------------------
	deckerOutputsRM, err := services.OutputsRMService.GetDeckerOutputsRM(databaseType, currentDate)
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("GetDeckerOutputsRM", err)
	}
	log.Println("len deckerOutputsRM:", len(deckerOutputsRM))
	// services.DeckersPostServiceInstance.PostDeckerOutputsRM(deckerOutputsRM, databaseType, token)

	// -------------------------
	// FG
	// -------------------------
	deckerOutputsFG, err := services.OutputsFGService.GetDeckerOutputsFG(databaseType, currentDate)
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("GetDeckerOutputsFG", err)
	}
	log.Println("len deckerOutputsFG:", len(deckerOutputsFG))
	// services.DeckersPostServiceInstance.PostDeckerOutputsFG(deckerOutputsFG, databaseType, token)

	// -------------------------
	// Daily PO（正式）
	// -------------------------
	dailyPoStatus, rawDailyPoStatus, err := services.PoStatusService.GetDailyPoStatus(databaseType, currentDate)
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("GetDailyPoStatus", err)
	}

	// -------------------------
	// Daily PO（Preload）
	// -------------------------
	preloadData, preloadRawData, err := services.PoStatusService.GetDailyPoStatusPreload(databaseType, currentDate)
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("GetDailyPoStatusPreload", err)
	}

	dailyPoStatus = append(dailyPoStatus, preloadData...)
	rawDailyPoStatus = append(rawDailyPoStatus, preloadRawData...)

	// -------------------------
	// Export + Save（最重要）
	// -------------------------
	report := services.PoStatusService.ExportPoReport(dailyPoStatus)
	rawReport := services.PoStatusService.ExportPoReport(rawDailyPoStatus)

	idMap, err := services.PoReportService.SavePOExcelReports(databaseType, report, false, "AUTO")
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("SavePOExcelReports", err)
	}

	if err := services.PoReportService.SaveRawPOReports(databaseType, rawReport, idMap); err != nil {
		repo.LogRepositoryInstance.LogAndSave("SaveRawPOReports", err)
	}

	// -------------------------
	// 全部成功才 POST
	// -------------------------

	services.DeckersPostServiceInstance.PostDailyPoStatus(databaseType, dailyPoStatus, token, "AUTO")

	log.Println("PostDeckerOutputsDaily completed successfully")
}

func PostDeckerMidnightDaily() {
	databaseType := config.GetConfig().Database.DatabaseType
	currentDate := time.Now().Add(-24 * time.Hour).Format("2006-01-02")

	log.Println("Running PostDeckerMidnightDaily at:", time.Now())

	// tokens
	token := jwt.GetJWT(databaseType)

	dailyPoStatus, rawDailyPoStatus, err := services.PoStatusService.GetNightExportPo(databaseType, currentDate)
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("GetNightExportPo", err)
	}

	report := services.PoStatusService.ExportPoReport(dailyPoStatus)
	rawReport := services.PoStatusService.ExportPoReport(rawDailyPoStatus)

	idMap, err := services.PoReportService.SavePOExcelReports(databaseType, report, false, "AUTO")
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("SavePOExcelReports", err)
	}

	if err := services.PoReportService.SaveRawPOReports(databaseType, rawReport, idMap); err != nil {
		repo.LogRepositoryInstance.LogAndSave("SaveRawPOReports", err)
	}

	services.DeckersPostServiceInstance.PostDailyPoStatus(databaseType, dailyPoStatus, token, "AUTO")
}

func PostQcOutputDaily() {
	log.Println("Running PostDeckerQcDaily at:", time.Now())

	databaseType := config.GetConfig().Database.DatabaseType
	today := time.Now().Format("2006-01-02")
	token := jwt.GetJWT(databaseType)

	// B-grade
	bgradeInventory, err := services.QcServiceInstance.GetDailyBgradeOutput(databaseType, today)
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("GetDailyBgradeOutput", err)
	} else {
		if len(bgradeInventory) > 0 {
			returnMap, postErr := services.DeckersPostServiceInstance.PostBgradeOutput(databaseType, bgradeInventory, token)
			if postErr != nil {
				log.Printf("error occurs while post bgrade: %v\n", postErr)
				repo.LogRepositoryInstance.LogAndSave("PostBgradeOutput", postErr)
			}

			err = services.QcServiceInstance.SendBgradeMail(databaseType, today, bgradeInventory, returnMap)
			if err != nil {
				log.Printf("error occurs while sending mail: %v\n", err)
				repo.LogRepositoryInstance.LogAndSave("SendBgradeMail", err)
			}
		}
	}

	// Repacking
	repackingData, err := services.QcServiceInstance.GetRepackingOutput(databaseType, today)
	if err != nil {
		repo.LogRepositoryInstance.LogAndSave("GetRepackingOutput", err)
	} else {
		if len(repackingData) > 0 {
			returnMap, postErr := services.DeckersPostServiceInstance.PostRepacking(databaseType, repackingData, token)
			if postErr != nil {
				log.Printf("error occurs while post repacking: %v\n", err)
				repo.LogRepositoryInstance.LogAndSave("PostRepacking", postErr)
			}
			err = services.QcServiceInstance.SendRepackingMail(databaseType, today, repackingData, returnMap)
			if err != nil {
				log.Printf("error occurs while sending mail: %v\n", err)
				repo.LogRepositoryInstance.LogAndSave("SendRepackingMail", err)
			}
		}
	}
}

func PostQcOutputHourly() {

	log.Println("Running PostDeckerQcHourly at:", time.Now())

	databaseType := config.GetConfig().Database.DatabaseType

	currentTime := time.Now().Format("2006-01-02 15:04:05")

	// get token to use
	token := jwt.GetJWT(databaseType)

	// TQC output
	tqcData, err := services.QcServiceInstance.GetHourlyTqcOutput(databaseType, currentTime)
	if err != nil {
		log.Printf("error occurs while getting TQC output: %v\n", err)
	} else {
		if len(tqcData) > 0 {
			services.DeckersPostServiceInstance.PostTQCOutput(databaseType, tqcData, token)
		}
	}

	// RQC output
	rqcData, err := services.QcServiceInstance.GetHourlyRqcOutput(databaseType, currentTime)
	if err != nil {
		log.Printf("error occurs while getting RQC output: %v\n", err)
	} else {
		if len(rqcData) > 0 {
			services.DeckersPostServiceInstance.PostRQCOutput(databaseType, rqcData, token)
		}
	}
}

func SendMailWithDailyPoReport() {
	databaseType := config.GetConfig().Database.DatabaseType
	dbFactory := ""
	switch databaseType {
	case "A":
		dbFactory = "YS"
	case "B":
		dbFactory = "TB"
	case "C":
		dbFactory = "YQ"
	}
	date := time.Now().AddDate(0, 0, -1).Format("2006-01-02")

	data, err := services.PoReportService.GetReport("", date, date, dbFactory)
	if err != nil {
		log.Println("Failed to get POdata: " + err.Error())
		return
	}

	filename := "po-report/" + date + "-DailyPO-" + dbFactory + ".xlsx"

	// Write excel file
	err = utils.WriteStructsToExcel(filename, "DailyPO", data)
	if err != nil {
		log.Println("cannot export excel file: " + err.Error())
	}

	// Send mail with excel file attachment
	err = utils.MailSenderInstance.SendEmailWithAttachment(databaseType, filename, date)
	if err != nil {
		log.Println("fail to send email: " + err.Error())
	}

	// Remove excel file to save memory
	defer utils.DeleteFile(filename)
}

// Remove po saved
func AutoRemoveLog() {
	databaseType := config.GetConfig().Database.DatabaseType

	// Remove PO logs older than 3 months
	// services.PoReportService.RemovePOInDatabase(databaseType, 3*30)

	// Remove WIP logs older than 7 days
	services.WIPReportServiceInstance.RemoveAndBackupWIPHourly(databaseType, 7)
}

func SendMailWithEmptyShipId() {
	databaseType := config.GetConfig().Database.DatabaseType
	dbFactory := ""
	switch databaseType {
	case "A":
		dbFactory = "YS"
	case "B":
		dbFactory = "TB"
	case "C":
		dbFactory = "YQ"
	}

	date := time.Now().Format("2006-01-02")

	data, err := services.PoStatusService.GetPoMissingShipID(databaseType)
	if err != nil {
		log.Printf("error when getting PO info: %v", err)
		return
	}

	// 檢查資料是否為空
	if len(data) == 0 {
		log.Printf("no PO data found for database %s, skip sending email", databaseType)
		return
	}

	filename := fmt.Sprintf("po-report/%s-EmptyShipID-%s.xlsx", date, dbFactory)

	// 建立 Excel
	err = utils.WriteStructsToExcelEmptyShipID(filename, "PO", data)
	if err != nil {
		log.Printf("error when writing excel: %v", err)
		return
	}
	defer func() {
		// 確保刪除不會中斷主流程
		if err := utils.DeleteFile(filename); err != nil {
			log.Printf("failed to delete temp file: %v", err)
		}
	}()

	// 最後寄信
	utils.MailSenderInstance.SendEmailWithEmptyShipID(databaseType, filename)
	log.Printf("email sent successfully for %s", databaseType)
}

func SendMailWithFGQuatity() {
	databaseType := config.GetConfig().Database.DatabaseType
	dbFactory := ""
	switch databaseType {
	case "A":
		dbFactory = "YS"
	case "B":
		dbFactory = "TB"
	case "C":
		dbFactory = "YQ"
	}

	date := time.Now().Format("2006-01-02")

	data, err := services.PoReportService.GetFGReportWithReturnID(databaseType)
	if err != nil {
		log.Printf("error when getting PO info: %v", err)
		return
	}

	filename := "po-report/" + date + "-FG-" + dbFactory + ".xlsx"
	err = utils.WriteStructsToExcelFGReport(filename, "FG", data)
	if err != nil {
		log.Printf("error when writing excel: %v", err)
		return
	}
	defer utils.DeleteFile(filename)

	info, err := os.Stat(filename)
	if err == nil && info.Size() > 0 {
		utils.MailSenderInstance.SendEmailWithFGReport(databaseType, filename)
	} else {
		log.Printf("skip sending email because file is empty or not found: %s", filename)
	}
}

func SendMailWithWarningOrder() {

	if databaseType := config.GetConfig().Database.DatabaseType; databaseType != "A" {
		return
	}

	date := time.Now().Format("2006-01-02")

	data, err := services.DelayWarningService.GetDelayWaringOrder()
	if err != nil {
		log.Printf("error when getting PO info: %v", err)
		return
	}

	// 檢查資料是否為空
	if len(data) == 0 {
		log.Printf("No Delay warning data found, skip sending email")
		return
	}

	filename := fmt.Sprintf("po-report/%s-ERP potential delay warning.xlsx", date)

	// 建立 Excel
	err = utils.WriteStructsToExcelDelayWarning(filename, date, data)
	if err != nil {
		log.Printf("error when writing excel: %v", err)
		return
	}
	defer func() {
		// 確保刪除不會中斷主流程
		if err := utils.DeleteFile(filename); err != nil {
			log.Printf("failed to delete temp file: %v", err)
		}
	}()

	// 最後寄信
	utils.MailSenderInstance.SendEmailWithWarningOrder(filename)
	log.Printf("Delay warning email sent successfully")
}

func CheckRQCActive() {

	databaseType := config.GetConfig().Database.DatabaseType

	currentTime := time.Now().Format("2006-01-02 15:04:05")

	startTime, endTime, err := services.QcServiceInstance.GetRQCCheckTimeRange(currentTime, -1*time.Hour)
	if err != nil {
		log.Printf("GetRQCCheckTimeRange failed: %v\n", err.Error())
		return
	}

	isActive, err := services.QcServiceInstance.CheckRQCActive(databaseType, startTime, endTime)
	if err != nil {
		log.Printf("CheckRQCActive failed: %v\n", err.Error())
		return
	}

	timeStr := services.QcServiceInstance.GenerateTimeString(startTime, endTime)

	if isActive {
		log.Printf("RQC checked: Active in: %s", timeStr)
	} else {
		utils.MailSenderInstance.SendEmailRQCCheck(databaseType, timeStr)
		log.Printf("RQC checked: No inspection found in: %s. Warning mail sended!", timeStr)
	}
}
