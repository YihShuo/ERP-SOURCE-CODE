package tasks

import (
	"log"
	"web-api/internal/pkg/config"

	"github.com/robfig/cron/v3"
)

func StartScheduler() {
	c := cron.New()

	taskConfig := config.GetConfig().Tasks

	// Lấy các cron expression từ cấu hình

	// Add task: Hourly WIP send with Decker's API
	_, err := c.AddFunc(taskConfig.PostDeckerHourlyCron, PostDeckerOutputsHourly)
	if err != nil {
		log.Println("Error scheduling PostDeckerOutputsHourly: ", err)
		return
	}

	// Add task: Daily end-day (PO, FG, RM) send with Decker's API
	_, err = c.AddFunc(taskConfig.PostDeckerDailyCron, PostDeckerOutputsDaily)
	if err != nil {
		log.Println("Error scheduling PostDeckerOutputsDaily: ", err)
		return
	}

	// Add task: Daily midnight PO send with Decker's API
	_, err = c.AddFunc(taskConfig.PostDeckerNightCron, PostDeckerMidnightDaily)
	if err != nil {
		log.Println("Error scheduling PostDeckerMidnightDaily: ", err)
		return
	}

	// Add task: Send internal mail po result
	_, err = c.AddFunc(taskConfig.AutoMailSenderCron, SendMailWithDailyPoReport)
	if err != nil {
		log.Println("Error scheduling AutoMailSender: ", err)
		return
	}

	// Thêm task: Scheduled log cleanup
	_, err = c.AddFunc(taskConfig.AutoRemoval, AutoRemoveLog)
	if err != nil {
		log.Println("Error scheduling AutoRemoveLog: ", err)
		return
	}

	// Thêm task: Auto send empty ship id
	_, err = c.AddFunc(taskConfig.EmptyShipIdWarning, SendMailWithEmptyShipId)
	if err != nil {
		log.Println("Error scheduling Send mail with empty ship ID: ", err)
		return
	}

	// Thêm task: Auto send Deckers's FG
	_, err = c.AddFunc(taskConfig.InternalSendFG, SendMailWithFGQuatity)
	if err != nil {
		log.Println("Error scheduling Send mail with empty ship ID: ", err)
		return
	}

	// Add task: Deckers QC DTD daily
	_, err = c.AddFunc(taskConfig.PostDeckerQCDaily, PostQcOutputDaily)
	if err != nil {
		log.Println("Error scheduling PostQcOutputDaily: ", err)
		return
	}

	// Add task: Deckers QC DTD hourly
	_, err = c.AddFunc(taskConfig.PostDeckerQCHourly, PostQcOutputHourly)
	if err != nil {
		log.Println("Error scheduling PostDeckerOutputsHourly: ", err)
		return
	}

	// Add task: Deckers QC DTD hourly
	_, err = c.AddFunc(taskConfig.DelayWarningMail, SendMailWithWarningOrder)
	if err != nil {
		log.Println("Error scheduling SendMailWithWarningOrder: ", err)
		return
	}

	// Add task: RQC check
	_, err = c.AddFunc(taskConfig.RqcCheck, CheckRQCActive)
	if err != nil {
		log.Println("Error scheduling CheckRQCActive: ", err)
		return
	}

	c.Start()

	// Giữ cho chương trình không bị thoát
	select {}
}
