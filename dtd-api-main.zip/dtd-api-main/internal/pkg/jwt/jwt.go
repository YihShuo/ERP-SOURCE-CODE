package jwt

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
	"web-api/internal/api/repo"
	"web-api/internal/pkg/config"
	"web-api/internal/pkg/models/types"
)

var (
	hokaJwtToken = map[string]string{}
	testJwtToken = map[string]string{}
	mu           sync.RWMutex
)

// JWT Payload
type JWTClaims struct {
	Exp int64 `json:"exp"`
}

// SetJWT lưu JWT vào bộ nhớ
func SetJWT(databaseType, token string) {
	mu.Lock()
	defer mu.Unlock()
	hokaJwtToken[databaseType] = token
}

// SetJWT lưu JWT vào bộ nhớ
func SetTestJWT(databaseType, token string) {
	mu.Lock()
	defer mu.Unlock()
	testJwtToken[databaseType] = token
}

// Get JWT lấy JWT từ bộ nhớ
func GetJWT(databaseType string) string {
	mu.RLock()
	token := hokaJwtToken[databaseType]
	mu.RUnlock()
	if isExpired, _ := IsJWTExpired(token); isExpired {
		newToken, err := GetOAuthToken(databaseType)
		if err != nil {
			log.Printf("Fail to get decker's token: %v\n", err)
		}
		SetJWT(databaseType, newToken)
		saveLog(err, "GetJWT", config.GetEnvironment(), databaseType)
		return newToken
	}
	return token
}

// Get JWT lấy JWT từ bộ nhớ
func GetTestJWT(databaseType string) string {
	mu.RLock()
	token := testJwtToken[databaseType]
	mu.RUnlock()
	if isExpired, _ := IsJWTExpired(token); isExpired {
		newToken, err := GetTestOAuthToken(databaseType)
		if err != nil {
			log.Printf("Fail to get decker's UAT token: %v\n", err)
		}
		saveLog(err, "GetTestJWT", "development", databaseType)
		SetTestJWT(databaseType, newToken)
		return newToken
	}
	return token
}

func saveLog(err error, function, databaseType, environment string) {
	now := time.Now()
	mes := "Get JWT success"
	if err != nil {
		mes = err.Error()
	}
	poLog := types.PoLog{
		AppName:  "dtd",
		Function: function,
		LogDate:  now,
		Source:   "jwt",
		Env:      environment,
		Message:  mes,
	}
	repo.LogRepositoryInstance.SavePoLog(databaseType, poLog)
}

// Validate JWT's expiration
func IsJWTExpired(tokenString string) (bool, error) {
	parts := strings.Split(tokenString, ".")
	if len(parts) != 3 {
		return true, fmt.Errorf("invalid JWT format")
	}

	// Decode JWT's payload
	payloadBytes, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return true, fmt.Errorf("failed to decode payload: %v", err)
	}

	// Parse JSON
	var claims JWTClaims
	if err := json.Unmarshal(payloadBytes, &claims); err != nil {
		return true, fmt.Errorf("failed to parse claims: %v", err)
	}

	// Check expiration
	if claims.Exp == 0 {
		return true, fmt.Errorf("exp field not found in token")
	}

	expTime := time.Unix(claims.Exp, 0)

	// To avoid case: token will be expired right after check by this function
	timeBuffer := 1 * time.Hour
	return expTime.Before(time.Now().Add(timeBuffer)), nil
}

func GetOAuthToken(databaseType string) (string, error) {
	var clientId, clientSecret string

	environment := config.GetEnvironment()

	config := config.GetConfig()

	switch environment {
	case "development":
		switch databaseType {
		// case "A":
		// 	clientId = "483564781400133"
		// 	clientSecret = "ZERyCFfULDYfvJmNRRccoEZFWPtcRODy"
		// case "B":
		// 	clientId = "547316905955397"
		// 	clientSecret = "AwQxilueSZLIRASNvKiOXwJbbawpEHqk"
		// case "C":
		// 	clientId = "579171156533317"
		// 	clientSecret = "jgSzUiAYwaEXyfANdJirsXbrgsamonxG"
		// default:
		// 	return "", fmt.Errorf("invalid database type: %s", databaseType)
		// }
		case "A":
			clientId = "527410088992837"
			clientSecret = "TeCULZuarkZAgNYEowdDphSeeBYBKhaX"
		case "B":
			clientId = "651690765226053"
			clientSecret = "qUSZHKrHhULQsBdunFgboQcGHDlomlak"
		case "C":
			clientId = "663391917482053"
			clientSecret = "TLjvniLiBpHuGMArxjouHgeYmFAZWQza"
		default:
			return "", fmt.Errorf("invalid database type: %s", databaseType)
		}
	case "production":
		switch databaseType {
		case "A":
			clientId = "527410088992837"
			clientSecret = "TeCULZuarkZAgNYEowdDphSeeBYBKhaX"
		case "B":
			clientId = "651690765226053"
			clientSecret = "qUSZHKrHhULQsBdunFgboQcGHDlomlak"
		case "C":
			clientId = "663391917482053"
			clientSecret = "TLjvniLiBpHuGMArxjouHgeYmFAZWQza"
		default:
			return "", fmt.Errorf("invalid database type: %s", databaseType)
		}
	}

	tokenUri := config.DeckersServer.OAuthKey

	// Create the Authorization header value
	authHeader := "Basic " + base64.StdEncoding.EncodeToString([]byte(clientId+":"+clientSecret))

	// Prepare the form data
	data := url.Values{}
	data.Set("grant_type", "client_credentials")

	// Create an HTTP request
	req, err := http.NewRequest("POST", tokenUri, bytes.NewBufferString(data.Encode()))
	if err != nil {
		return "", err
	}

	// Set headers
	req.Header.Set("Authorization", authHeader)
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	// Execute the request
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	// Check the response status
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("failed to obtain token: status %d", resp.StatusCode)
	}

	// Parse the JSON response
	var tokenResponse map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&tokenResponse); err != nil {
		return "", err
	}

	// Extract the access token
	if accessToken, ok := tokenResponse["access_token"].(string); ok {
		return accessToken, nil
	}

	return "", errors.New("access_token not found in response")
}

func GetTestOAuthToken(databaseType string) (string, error) {
	var clientId, clientSecret string

	config := config.GetConfig()

	switch databaseType {
	case "A":
		clientId = "483564781400133"
		clientSecret = "ZERyCFfULDYfvJmNRRccoEZFWPtcRODy"
	case "B":
		clientId = "547316905955397"
		clientSecret = "AwQxilueSZLIRASNvKiOXwJbbawpEHqk"
	case "C":
		clientId = "579171156533317"
		clientSecret = "jgSzUiAYwaEXyfANdJirsXbrgsamonxG"
	default:
		return "", fmt.Errorf("invalid database type: %s", databaseType)
	}

	tokenUri := config.DeckersServer.TestOAuthKey

	// Create the Authorization header value
	authHeader := "Basic " + base64.StdEncoding.EncodeToString([]byte(clientId+":"+clientSecret))

	// Prepare the form data
	data := url.Values{}
	data.Set("grant_type", "client_credentials")

	// Create an HTTP request
	req, err := http.NewRequest("POST", tokenUri, bytes.NewBufferString(data.Encode()))
	if err != nil {
		return "", err
	}

	// Set headers
	req.Header.Set("Authorization", authHeader)
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	// Execute the request
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	// Check the response status
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("failed to obtain token: status %d", resp.StatusCode)
	}

	// Parse the JSON response
	var tokenResponse map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&tokenResponse); err != nil {
		return "", err
	}

	// Extract the access token
	if accessToken, ok := tokenResponse["access_token"].(string); ok {
		return accessToken, nil
	}

	return "", errors.New("access_token not found in response")
}
