package config

import (
	"fmt"
	"log"
	"os"
	"sync"

	"github.com/spf13/viper"
)

type Configuration struct {
	Environment string                   `mapstructure:"environment"`
	Development EnvironmentConfiguration `mapstructure:"development"`
	Production  EnvironmentConfiguration `mapstructure:"production"`
}

type EnvironmentConfiguration struct {
	Server        ServerConfiguration        `mapstructure:"server"`
	Database      DatabaseConfiguration      `mapstructure:"database"`
	Mail          MailConfig                 `mapstructure:"email"`
	DeckersServer DeckersServerConfiguration `mapstructure:"deckersServer"`
	Tasks         TaskConfig                 `mapstructure:"tasks"`
	Cors          CorsConfiguration          `mapstructure:"cors"`
}

type CorsConfiguration struct {
	Global bool
	Ips    string
}

type TaskConfig struct {
	PostDeckerHourlyCron string `mapstructure:"postDeckerHourlyCron"`
	PostDeckerDailyCron  string `mapstructure:"postDeckerDailyCron"`
	PostDeckerNightCron  string `mapstructure:"postDeckerNightCron"`
	PostDeckerQCDaily    string `mapstructure:"postDeckerQCDaily"`
	PostDeckerQCHourly   string `mapstructure:"postDeckerQCHourly"`
	AutoMailSenderCron   string `mapstructure:"autoMailSenderCron"`
	AutoRemoval          string `mapstructure:"autoRemoval"`
	EmptyShipIdWarning   string `mapstructure:"emptyShipIdWarning"`
	InternalSendFG       string `mapstructure:"internalSendFG"`
	DelayWarningMail     string `mapstructure:"delayWarningMail"`
	RqcCheck             string `mapstructure:"rqcCheck"`
}

type ServerConfiguration struct {
	Port   string `mapstructure:"port"`
	Secret string `mapstructure:"secret"`
	Mode   string `mapstructure:"mode"`
}

type DatabaseConfiguration struct {
	Driver       string `mapstructure:"driver"`
	Dbname       string `mapstructure:"dbname"`
	Username     string `mapstructure:"username"`
	Password     string `mapstructure:"password"`
	Host         string `mapstructure:"host"`
	Port         string `mapstructure:"port"`
	Sslmode      bool   `mapstructure:"sslmode"`
	Logmode      bool   `mapstructure:"logmode"`
	DatabaseType string `mapstructure:"databaseType"`
}

type MailConfig struct {
	Username string `mapstructure:"username"`
	Password string `mapstructure:"password"`
	Host     string `mapstructure:"host"`
	Port     string `mapstructure:"port"`
}

type DeckersServerConfiguration struct {
	OAuthKey     string `mapstructure:"oauthKey"`
	PostData     string `mapstructure:"postData"`
	TestOAuthKey string `mapstructure:"testOauthKey"`
	TestPostData string `mapstructure:"testPostData"`
}

var (
	Config     *EnvironmentConfiguration
	once       sync.Once
	initErr    error
	currentEnv string
)

// Setup 只允許初始化一次（避免被覆蓋）
func Setup(configPath string, env string) error {
	once.Do(func() {

		// fallback（避免沒傳 env）
		if env == "" {
			env = os.Getenv("APP_ENV")
		}
		if env == "" {
			env = "development"
		}

		currentEnv = env

		viper.SetConfigFile(configPath)
		viper.SetConfigType("yaml")

		if err := viper.ReadInConfig(); err != nil {
			initErr = fmt.Errorf("error reading config file: %w", err)
			return
		}

		// ENV override
		if dbTypeEnv := os.Getenv("DATABASE_TYPE"); dbTypeEnv != "" {
			viper.Set(env+".database.databaseType", dbTypeEnv)
		}

		var fullConfig Configuration
		if err := viper.Unmarshal(&fullConfig); err != nil {
			initErr = fmt.Errorf("unable to decode config: %w", err)
			return
		}

		var envConfig EnvironmentConfiguration

		switch env {
		case "development":
			envConfig = fullConfig.Development
		case "production":
			envConfig = fullConfig.Production
		default:
			initErr = fmt.Errorf("unknown environment: %s", env)
			return
		}

		Config = &envConfig
	})

	return initErr
}

// GetConfig thread-safe 讀取
func GetConfig() *EnvironmentConfiguration {
	if Config == nil {
		log.Fatal("Configuration not initialized. Please call Setup() first.")
	}
	return Config
}

// 取得當前環境（安全版）
func GetEnvironment() string {
	if currentEnv != "" {
		return currentEnv
	}
	return "development"
}
