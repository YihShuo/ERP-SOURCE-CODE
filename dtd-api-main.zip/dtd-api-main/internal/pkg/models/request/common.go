package request

type PageInfo struct {
	PageNumber int `form:"pageNumber" json:"pageNumber" binding:"required,number"`
	PageSize   int `form:"pageSize" json:"pageSize" binding:"required,number"`
}

type PoListDb struct {
	Date         string   `json:"date"`
	DatabaseType string   `json:"databaseType"`
	DatabaseName string   `json:"databaseName"`
	Host         string   `json:"host"`
	Username     string   `json:"username"`
	Password     string   `json:"password"`
	PoList       []string `json:"poList"`
}
