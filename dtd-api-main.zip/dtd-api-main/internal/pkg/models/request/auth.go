package request

type AuthRequest struct {
	UserID   string `json:"user_id" binding:"required"`
	Password string `json:"password" binding:"required"`
	Factory  string `json:"factory" binding:"required"`
}
