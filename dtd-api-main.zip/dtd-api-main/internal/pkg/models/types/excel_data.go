package types

type ExcelData struct {
	RiskLevel string `json:"risk_level"`
	PoNumber  string `json:"po"`
	Factory   string `json:"factory"`
}

type POExcelReport struct {
	Date        string            `gorm:"column:report_date" json:"date"`
	KHPO        string            `gorm:"column:khpo" json:"khpo"`
	DDBH        string            `gorm:"-" json:"-"`
	StyleNo     string            `gorm:"column:style_no" json:"style_no"`
	ColorCode   string            `gorm:"column:color_code" json:"color_code"`
	ShipID      string            `gorm:"column:ship_id" json:"ship_id"`
	Status      string            `gorm:"column:status" json:"status"`
	Qty         int               `gorm:"column:quantity" json:"qty"`
	RM01        int               `gorm:"column:rm01" json:"rm01"`
	RM03        int               `gorm:"column:rm03" json:"rm03"`
	WIP31       int               `gorm:"column:wip31" json:"wip31"`
	WIP31Output int               `gorm:"column:wip31output" json:"wip31output"`
	WIP33       int               `gorm:"column:wip33" json:"wip33"`
	WIP33Output int               `gorm:"column:wip33output" json:"wip33output"`
	WIP6        int               `gorm:"column:wip6" json:"wip6"`
	WIP6Output  int               `gorm:"column:wip6output" json:"wip6output"`
	WIP8        int               `gorm:"column:wip8" json:"wip8"`
	WIP8Output  int               `gorm:"column:wip8output" json:"wip8output"`
	FG10        int               `gorm:"column:fg10" json:"fg10"`
	FG14        int               `gorm:"column:fg14" json:"fg14"`
	ReturnID    string            `gorm:"column:return_id" json:"return_id"`
	RawPo       []RawPOSaveReport `gorm:"-" json:"raw_po_list,omitempty"`
	XFDetail    []XFDetailQuery   `gorm:"-" json:"-"`
}

func (input *POExcelReport) ParseExcelToSave() POSaveReport {
	return POSaveReport{
		KHPO:        input.KHPO,
		StyleNo:     input.StyleNo,
		ColorCode:   input.ColorCode,
		ShipID:      input.ShipID,
		Status:      input.Status,
		Qty:         input.Qty,
		RM01:        input.RM01,
		RM03:        input.RM03,
		WIP31:       input.WIP31,
		WIP33:       input.WIP33,
		WIP6:        input.WIP6,
		WIP8:        input.WIP8,
		FG10:        input.FG10,
		FG14:        input.FG14,
		WIP31Output: input.WIP31Output,
		WIP33Output: input.WIP33Output,
		WIP6Output:  input.WIP6Output,
		WIP8Output:  input.WIP8Output,
		XFDetail:    input.XFDetail,
	}
}

func (input *POExcelReport) ParseExcelToRawSave() RawPOSaveReport {
	return RawPOSaveReport{
		KHPO:      input.KHPO,
		DDBH:      input.DDBH,
		StyleNo:   input.StyleNo,
		ColorCode: input.ColorCode,
		ShipID:    input.ShipID,
		Status:    input.Status,
		Qty:       input.Qty,
		RM01:      input.RM01,
		RM03:      input.RM03,
		WIP31:     input.WIP31,
		WIP33:     input.WIP33,
		WIP6:      input.WIP6,
		WIP8:      input.WIP8,
		FG10:      input.FG10,
		FG14:      input.FG14,
	}
}

type WIPExcelResult struct {
	Date        string
	KHPO        string
	DDBH        string
	StyleNumber string
	ColorCode   string
	ShipID      string
	Qty         uint
	WIP31       uint
	WIP33       uint
	WIP6        uint
	WIP8        uint
}

type BgradeInventoryExcel struct {
	FactoryCode    string `json:"factoryCode" gorm:"column:FactoryCode"`
	FactoryName    string `json:"factoryName" gorm:"column:FactoryName"`
	Brand          string `json:"brand" gorm:"column:Brand"`
	StyleNumber    string `json:"styleNumber" gorm:"column:StyleNumber"`
	StyleName      string `json:"styleName" gorm:"column:StyleName"`
	ColorCode      string `json:"colorCode" gorm:"column:ColorCode"`
	InventoryDate  string `json:"inventoryDate" gorm:"column:InventoryDate"`
	TotalBGradeQty int    `json:"totalBgradeQty" gorm:"column:TotalBGradeQty"`
	SizeDetailList string `json:"sizeDetailList" gorm:"column:SizeDetailList"`
	IODetailList   string `json:"ioDetailList" gorm:"column:IODetailList"`
	Remark         string `json:"remark" gorm:"column:Remark"`
	ReturnID       string `json:"return_id" gorm:"column:ReturnID"`
}
