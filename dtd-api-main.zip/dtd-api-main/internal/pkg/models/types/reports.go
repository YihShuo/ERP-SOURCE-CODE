package types

import "time"

//FILE - MODEL TYPES REPORTS

// type - Report_MNG
type ReportMng struct {
	Sno          uint   `json:"sno" form:"sno"`
	Rpcode       string `json:"rpcode" form:"rpcode"`
	Dpid         uint   `json:"dpid" form:"dpid"`
	Rptid        uint   `json:"rptid" form:"rptid"`
	Is_Answered  bool   `json:"is_answered" form:"is_answered"`
	Is_Completed bool   `json:"is_completed" form:"is_completed"`
	Updatedate   string `json:"updatedate" form:"updatedate"`
	Depname      string `json:"depname" form:"depname"`
}

// type - Report
type Report struct {
	ID          uint64 `json:"id" form:"id"`
	Note        string `json:"note" form:"note"`
	Answer      string `json:"answer" form:"answer"`
	Rpcode      string `json:"rpcode" form:"rpcode"`
	Note_Time   string `json:"note_time" form:"note_time"`
	Answer_Time string `json:"answer_time" form:"answer_time"`
}

// type - Admin
// type Admin struct {
// 	AdminID  uint   `json:"adminid" form:"adminid"`
// 	Username string `json:"username" form:"username"`
// 	Password string `json:"password" form:"password"`
// }

// struct WorkUnit
type Department struct {
	Dpid  uint   `json:"dpid" form:"dpid"`
	Title string `json:"title" form:"title"`
}

// type - MailType
type ReportType struct {
	Rptid uint   `json:"rptid" form:"rptid"`
	Title string `json:"type" form:"type"`
}

// type - Email
type Email struct {
	Mailid  uint   `json:"mailid" form:"mailid"`
	Email   string `json:"email" form:"email"`
	Adminid uint   `json:"adminid" form:"adminid"`
}

// type - CombinedReport
type CombinedReport struct {
	ID           uint64 `json:"id"`
	Rpcode       string `json:"rpcode"`
	Note         string `json:"note"`
	Answer       string `json:"answer"`
	Dpid         uint   `json:"dpid"`
	Rptid        uint   `json:"rptid"`
	Note_Time    string `json:"note_time"`
	Answer_Time  string `json:"answer_time"`
	Is_Answered  bool   `json:"is_answered"`
	Is_Completed bool   `json:"is_completed"`
	Updatedate   string `json:"updatedate"`
}

type POSaveReport struct {
	ID          uint            `gorm:"column:id;primaryKey;autoIncrement" json:"id,omitempty"`
	Date        time.Time       `gorm:"column:report_date" json:"date"`
	KHPO        string          `gorm:"column:khpo" json:"khpo"`
	StyleNo     string          `gorm:"column:style_no" json:"style_no"`
	ColorCode   string          `gorm:"column:color_code" json:"color_code"`
	ShipID      string          `gorm:"column:ship_id" json:"ship_id"`
	Status      string          `gorm:"column:status" json:"status"`
	Qty         int             `gorm:"column:quantity" json:"qty"`
	RM01        int             `gorm:"column:rm01" json:"rm01"`
	RM03        int             `gorm:"column:rm03" json:"rm03"`
	WIP31       int             `gorm:"column:wip31" json:"wip31"`
	WIP33       int             `gorm:"column:wip33" json:"wip33"`
	WIP6        int             `gorm:"column:wip6" json:"wip6"`
	WIP8        int             `gorm:"column:wip8" json:"wip8"`
	FG10        int             `gorm:"column:fg10" json:"fg10"`
	FG14        int             `gorm:"column:fg14" json:"fg14"`
	ReturnID    string          `gorm:"column:return_id" json:"return_id"`
	WIP31Output int             `gorm:"column:wip31output" json:"wip31output"`
	WIP33Output int             `gorm:"column:wip33output" json:"wip33output"`
	WIP6Output  int             `gorm:"column:wip6output" json:"wip6output"`
	WIP8Output  int             `gorm:"column:wip8output" json:"wip8output"`
	XFDetail    []XFDetailQuery `gorm:"-" json:"-"`
}

type RawPOSaveReport struct {
	ID        uint   `gorm:"column:id;primaryKey;autoIncrement" json:"-"`
	CombineID uint   `gorm:"column:combine_id" json:"-"`
	Date      string `gorm:"column:report_date" json:"date"`
	KHPO      string `gorm:"column:khpo" json:"khpo"`
	DDBH      string `gorm:"column:ddbh" json:"ddbh"`
	StyleNo   string `gorm:"column:style_no" json:"style_no"`
	ColorCode string `gorm:"column:color_code" json:"color_code"`
	ShipID    string `gorm:"column:ship_id" json:"ship_id"`
	Status    string `gorm:"column:status" json:"status"`
	Qty       int    `gorm:"column:quantity" json:"qty"`
	RM01      int    `gorm:"column:rm01" json:"rm01"`
	RM03      int    `gorm:"column:rm03" json:"rm03"`
	WIP31     int    `gorm:"column:wip31" json:"wip31"`
	WIP33     int    `gorm:"column:wip33" json:"wip33"`
	WIP6      int    `gorm:"column:wip6" json:"wip6"`
	WIP8      int    `gorm:"column:wip8" json:"wip8"`
	FG10      int    `gorm:"column:fg10" json:"fg10"`
	FG14      int    `gorm:"column:fg14" json:"fg14"`
}

func (POSaveReport) TableName() string {
	return "po_daily"
}

func (RawPOSaveReport) TableName() string {
	return "po_daily_raw"
}

type FGReport struct {
	FactoryName string `gorm:"column:factory_name" json:"factory_name"`
	FactoryCode string `gorm:"column:factory_code" json:"factory_code"`
	PoType      string `gorm:"column:po_type" json:"po_type"`
	KHPO        string `gorm:"column:KHPO" json:"KHPO"`
	StyleNumber string `gorm:"column:style_number" json:"style_number"`
	ColorCode   string `gorm:"column:color_code" json:"color_code"`
	ShipID      string `gorm:"column:ship_id" json:"ship_id"`
	Quantity    string `gorm:"column:po_quantity" json:"po_quantity,omitempty"`
	FactoryFG10 string `gorm:"column:factory_warehouse_fg10" json:"factory_warehouse_fg10"`
	DtdFG10     string `gorm:"column:dtd_tracking_fg10" json:"dtd_tracking_fg10"`
	FactoryFG14 string `gorm:"column:factory_warehouse_fg14" json:"factory_warehouse_fg14"`
	DtdFG14     string `gorm:"column:dtd_tracking_fg14" json:"dtd_tracking_fg14"`
	ReturnID    string `gorm:"column:return_id" json:"return_id"`
}

type UnsyncPo struct {
	FGReport
	FG10Diff string `gorm:"column:diff_fg10" json:"diff_fg10"`
	FG14Diff string `gorm:"column:diff_fg14" json:"diff_fg14"`
	IsMatch  bool   `gorm:"column:is_match" json:"is_match"`
}
