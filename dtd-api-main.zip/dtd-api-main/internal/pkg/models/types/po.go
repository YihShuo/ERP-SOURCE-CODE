package types

type PoPayload struct {
	ID          string `gorm:"-"`
	SentDate    string `gorm:"column:sent_date"`
	PostId      string `gorm:"column:post_id"`
	BatchNumber int    `gorm:"column:batch_no"`
	Payload     string `gorm:"column:payload"`
	ReturnID    string `gorm:"column:return_id"`
	UserID      string `gorm:"column:USERID"`
}

func (PoPayload) TableName() string {
	return "po_daily_payload"
}
