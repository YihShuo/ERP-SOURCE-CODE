package types

type DeckerOutput struct {
	ID                     uint64   `json:"-" gorm:"column:id;primary_key;auto_increment;"`
	StartTime              string   `json:"startTime" gorm:"column:startTime"`
	EndTime                string   `json:"endTime" gorm:"column:endTime"`
	FactoryCode            string   `json:"factoryCode" gorm:"column:factoryCode"`
	FactoryName            string   `json:"factoryName" gorm:"column:factoryName"`
	StageCode              string   `json:"stageCode" gorm:"column:stageCode"`
	ProductionLineType     string   `json:"productionLineType" gorm:"column:productionLineType"`
	ProductionLineNumber   string   `json:"productionLineNumber" gorm:"column:productionLineNumber"`
	PoList                 []PoItem `json:"poList" gorm:"-"`
	Po                     string   `json:"-" gorm:"column:po"`
	ShipId                 string   `json:"-" gorm:"column:shipId"`
	StyleNumber            string   `json:"styleNumber" gorm:"column:styleNumber"`
	StyleName              string   `json:"styleName" gorm:"column:styleName"`
	ColorCode              string   `json:"colorCode" gorm:"column:colorCode"`
	SizeNumber             string   `json:"sizeNumber" gorm:"column:sizeNumber"`
	Output                 int      `json:"output" gorm:"column:output"`
	LogType                string   `json:"logType" gorm:"column:logType"`
	Brand                  string   `json:"brand" gorm:"column:brand"`
	FactoryWorkOrderNumber string   `json:"factoryWorkOrderNumber" gorm:"column:factoryWorkOrderNumber"`
	FactoryWorkOrderQty    int      `json:"factoryWorkOrderQuantity" gorm:"column:factoryWorkOrderQuantity"`
	ReturnID               string   `json:"-" gorm:"column:returnId"`
}

type PoItem struct {
	Po     string `json:"po" gorm:"column:po"`
	ShipId string `json:"shipId" gorm:"column:shipId"`
}

type WIPQueryResult struct {
	Date        string `json:"Date" gorm:"column:Date"`
	KHPO        string `json:"KHPO" gorm:"column:KHPO"`
	DDBH        string `json:"DDBH" gorm:"column:DDBH"`
	StyleNumber string `json:"StyleNumber" gorm:"column:StyleNumber"`
	ColorCode   string `json:"ColorCode" gorm:"column:ColorCode"`
	ShipID      string `json:"ShipID" gorm:"column:ShipID"`
	Qty         uint   `json:"Qty" gorm:"column:Qty"`
	StageCode   string `json:"StageCode" gorm:"column:StageCode"`
	Output      uint   `json:"Output" gorm:"column:Output"`
}

func (queryResult *WIPQueryResult) ExtractExcelData() WIPExcelResult {
	return WIPExcelResult{
		Date:        queryResult.Date,
		KHPO:        queryResult.KHPO,
		DDBH:        queryResult.DDBH,
		StyleNumber: queryResult.StyleNumber,
		ColorCode:   queryResult.ColorCode,
		ShipID:      queryResult.ShipID,
		Qty:         queryResult.Qty,
	}
}

type WIPReport struct {
	DeckerOutput
	ReturnID string
}

func (DeckerOutput) TableName() string {
	return "wip_hourly"
}
