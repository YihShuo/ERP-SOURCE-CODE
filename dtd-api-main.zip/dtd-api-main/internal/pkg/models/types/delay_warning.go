package types

type DelayWarningOrder struct {
	RY               string `gorm:"column:DDBH"`
	Factory          string `gorm:"column:Factory"`
	BuySeason        string `gorm:"column:season"`
	BuyMonth         string `gorm:"column:buyMonth"`
	PO               string `gorm:"column:KHPO"`
	StyleNumber      string `gorm:"column:styleNumber"`
	ShipId           string `gorm:"column:shipId"`
	StyleName        string `gorm:"column:styleName"`
	ColorCode        string `gorm:"column:colorCode"`
	Qty              uint   `gorm:"column:quantity"`
	XFDate           string `gorm:"column:confirmXFDate"`
	CuttingStatus    string `gorm:"column:cuttingStatus"`
	Destination      string `gorm:"column:destination"`
	InspectionStatus string `gorm:"column:inspectionStatus"`
}
