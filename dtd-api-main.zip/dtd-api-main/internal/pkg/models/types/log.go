package types

import "time"

type PoLog struct {
	AppName  string    `gorm:"column:app_name"`
	Function string    `gorm:"column:function_name"`
	LogDate  time.Time `gorm:"column:log_date"`
	Source   string    `gorm:"column:source"`
	Env      string    `gorm:"column:env"`
	Message  string    `gorm:"column:message"`
}

func (PoLog) TableName() string {
	return "po_daily_log"
}
