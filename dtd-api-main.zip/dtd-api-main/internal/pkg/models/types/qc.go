package types

import (
	"encoding/json"
	"time"
)

type QcCommon struct {
	FactoryCode    string `gorm:"column:factoryCode" json:"factoryCode"`
	FactoryName    string `gorm:"column:factoryName" json:"factoryName"`
	Brand          string `gorm:"column:brand" json:"brand"`
	StyleNumber    string `gorm:"column:styleNumber" json:"styleNumber"`
	StyleName      string `gorm:"column:styleName" json:"styleName"`
	ColorCode      string `gorm:"column:colorCode" json:"colorCode"`
	PoNumber       string `gorm:"column:poNumber" json:"poNumber"`
	PoType         string `gorm:"column:poType" json:"poType"`
	ShipID         string `gorm:"column:shipId" json:"shipId"`
	DDBH           string `gorm:"column:SCBH" json:"-"`
	DepNo          string `gorm:"column:DepNo" json:"-"`
	LineNumber     string `gorm:"column:DepName" json:"lineNumber"`
	InspectionType string `gorm:"column:inspectionType" json:"inspectionType"`
	StartTime      string `gorm:"column:startTime" json:"startTime,omitempty"`
	EndTime        string `gorm:"column:endTime" json:"endTime,omitempty"`
}

type TqcQueryResult struct {
	QcCommon

	Tqc1PassQty uint `gorm:"column:TQC1_Pass_Qty"`
	Tqc2PassQty uint `gorm:"column:TQC2_Pass_Qty"`
	Tqc3PassQty uint `gorm:"column:TQC3_Pass_Qty"`

	Tqc1RepairQty uint `gorm:"column:TQC1_Repair_Qty"`
	Tqc2RepairQty uint `gorm:"column:TQC2_Repair_Qty"`
	Tqc3RepairQty uint `gorm:"column:TQC3_Repair_Qty"`

	Tqc1BgradeQty uint `gorm:"column:TQC1_Bgrade_Qty"`
	Tqc2BgradeQty uint `gorm:"column:TQC2_Bgrade_Qty"`
	Tqc3BgradeQty uint `gorm:"column:TQC3_Bgrade_Qty"`

	Tqc1CgradeQty uint `gorm:"column:TQC1_Cgrade_Qty"`
	Tqc2CgradeQty uint `gorm:"column:TQC2_Cgrade_Qty"`
	Tqc3CgradeQty uint `gorm:"column:TQC3_Cgrade_Qty"`

	AssemblyTotalInspectionPassQty uint `gorm:"column:assemblyTotalInspectionPassQty"`
	AssemblyTotalOutput            uint `gorm:"column:assemblyTotalOutput"`

	Inspectors    Inspector `gorm:"embedded"`
	InspectorName []string  `gorm:"-" json:"inspectorName"` //
}
type Inspector struct {
	TQC1Inspector string `gorm:"column:TQC1_Inspector"`
	TQC2Inspector string `gorm:"column:TQC2_Inspector"`
	TQC3Inspector string `gorm:"column:TQC3_Inspector"`
}

type TqcOutputPayload struct {
	QcCommon
	TqcInspectedQty                []uint    `json:"tqcInspectedQty"`
	TqcPassQty                     []uint    `json:"tqcPassQty"`
	TqcRepairQty                   []uint    `json:"tqcRepairQty"`
	TqcBgradeQty                   []uint    `json:"tqcBgradeQty"`
	TqcCgradeQty                   []uint    `json:"tqcCgradeQty"`
	AssemblyTotalInspectionPassQty uint      `json:"assemblyTotalInspectionPassQty"`
	RepairReasonList               []Reason  `json:"repairReasonList"`
	RejectReasonList               []Reason  `json:"rejectReasonList"`
	RejectRate                     []float32 `json:"rejectRate"`
	DefectRate                     []float32 `json:"defectRate"`
	DefectRateThreshold            float32   `json:"defectRateThreshold"`
	InspectorName                  []string  `json:"inspectorName"`
}

type TqcDataMapper struct {
	QcCommon
	DefectRateThreshold            float32 `gorm:"column:DefectRateThreshold"`
	AssemblyTotalInspectionPassQty uint    `gorm:"column:AssemblyTotalInspectionPassQty"`
	TqcInspectedQty                string  `gorm:"column:TqcInspectedQty"`
	TqcPassQty                     string  `gorm:"column:TqcPassQty"`
	TqcRepairQty                   string  `gorm:"column:TqcRepairQty"`
	TqcBgradeQty                   string  `gorm:"column:TqcBgradeQty"`
	TqcCgradeQty                   string  `gorm:"column:TqcCgradeQty"`
	RepairReasonList               string  `gorm:"column:RepairReasonList"`
	RejectReasonList               string  `gorm:"column:RejectReasonList"`
	RejectRate                     string  `gorm:"column:RejectRate"`
	DefectRate                     string  `gorm:"column:DefectRate"`
	InspectorName                  string  `gorm:"column:InspectorName"`
}

type Reason struct {
	DefectCode string `json:"defectCode" gorm:"column:defect_code"`
	Level      string `json:"level,omitempty" gorm:"column:DefectLevel"`
	Qty        uint   `json:"qty" gorm:"column:Qty"`
	DepNo      string `json:"-" gorm:"column:DepNo"`
	DDBH       string `json:"-" gorm:"column:SCBH"`
}

type RqcResult struct {
	QcCommon
	RqcInspectedQty  uint     `json:"rqcInspectedQty" gorm:"-"`
	RqcPassQty       uint     `json:"rqcPassQty" gorm:"column:rqcPassQty"`
	RqcRepairQty     uint     `json:"rqcRepairQty" gorm:"column:rqcRepairQty"`
	RqcBgradeQty     uint     `json:"rqcBgradeQty" gorm:"column:rqcBgradeQty"`
	RqcCgradeQty     uint     `json:"rqcCgradeQty" gorm:"column:rqcCgradeQty"`
	RepairReasonList []Reason `json:"repairReasonList" gorm:"-"`
	RejectReasonList []Reason `json:"rejectReasonList" gorm:"-"`
	RejectRate       float32  `json:"rejectRate"`
	DefectRate       float32  `json:"defectRate"`
	InspectorName    string   `json:"inspectorName" gorm:"column:RQCInspector"`
}

type ApprovedBy struct {
	Role string `json:"role" gorm:"role"`
	Name string `json:"name" gorm:"name"`
}

type RepackingResult struct {
	QcCommon
	InspectTime      time.Time    `gorm:"column:inspectTime" json:"inspectTime"`
	LotNumber        string       `json:"lotNumber" gorm:"column:LotNumber"`
	InspectedQty     uint         `json:"inspectedQty" gorm:"InspectedQty"`
	PassQty          uint         `json:"passQty" gorm:"column:PassQty"`
	RepairQty        uint         `json:"repairQty" gorm:"column:RepairQty"`
	BGradeQty        uint         `json:"bgradeQty" gorm:"column:BgradeQty"`
	CGradeQty        uint         `json:"cgradeQty" gorm:"column:CgradeQty"`
	RepairReasonList []Reason     `json:"repairReasonList" gorm:"-"`
	RejectReasonList []Reason     `json:"rejectReasonList" gorm:"-"`
	ApprovedBy       []ApprovedBy `json:"approvedBy" gorm:"-"`
	ApprovedTime     time.Time    `gorm:"column:approvedTime" json:"approvedTime"`
}

func (repacking *RepackingResult) ExtractExcel() RepackingResultExcel {

	taipeiLoc, _ := time.LoadLocation("Asia/Taipei")

	return RepackingResultExcel{
		QcCommon:         repacking.QcCommon,
		InspectTime:      repacking.InspectTime.In(taipeiLoc).Format(time.RFC3339),
		LotNumber:        repacking.LotNumber,
		InspectedQty:     repacking.InspectedQty,
		PassQty:          repacking.PassQty,
		RepairQty:        repacking.RepairQty,
		BGradeQty:        repacking.BGradeQty,
		CGradeQty:        repacking.CGradeQty,
		RepairReasonList: GetStringJson(repacking.RepairReasonList),
		RejectReasonList: GetStringJson(repacking.RejectReasonList),
		ApprovedBy:       GetStringJson(repacking.ApprovedBy),
		ApprovedTime:     repacking.ApprovedTime.In(taipeiLoc).Format(time.RFC3339),
	}
}

func GetStringJson(v any) string {
	result, err := json.Marshal(v)
	if err != nil {
		return ""
	}
	return string(result)
}

type RepackingResultExcel struct {
	QcCommon
	InspectTime      string `json:"inspectTime" gorm:"column:inspectTime"`
	LotNumber        string `json:"lotNumber" gorm:"column:LotNumber"`
	InspectedQty     uint   `json:"inspectedQty" gorm:"InspectedQty"`
	PassQty          uint   `json:"passQty" gorm:"column:PassQty"`
	RepairQty        uint   `json:"repairQty" gorm:"column:RepairQty"`
	BGradeQty        uint   `json:"bgradeQty" gorm:"column:BgradeQty"`
	CGradeQty        uint   `json:"cgradeQty" gorm:"column:CgradeQty"`
	RepairReasonList string `json:"repairReasonList" gorm:"-"`
	RejectReasonList string `json:"rejectReasonList" gorm:"-"`
	ApprovedBy       string `json:"approvedBy" gorm:"-"`
	ApprovedTime     string `gorm:"column:approvedTime" json:"approvedTime"`
	ReturnID         string `json:"return_id" gorm:"column:ReturnID"`
}
