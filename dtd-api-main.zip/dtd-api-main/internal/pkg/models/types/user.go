package types

type UserInfo struct {
	UserID   string `gorm:"user_id"`
	Username string `gorm:"username"`
	Password string `gorm:"password"`
	Factory  string `gorm:"factory"`
}
