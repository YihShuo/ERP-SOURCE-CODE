package types

import "time"

// RM
type DeckerOutputsRM struct {
	StartTime             string      `gorm:"column:startTime" json:"startTime"`
	EndTime               string      `gorm:"column:endTime" json:"endTime"`
	FactoryCode           string      `gorm:"column:factoryCode" json:"factoryCode"`
	FactoryName           string      `gorm:"column:factoryName" json:"factoryName"`
	StageCode             string      `gorm:"column:stageCode" json:"stageCode"`
	Output                float64     `gorm:"column:output" json:"output"`
	OutputType            string      `gorm:"column:outputType" json:"outputType"`
	MaterialType          string      `gorm:"column:materialType" json:"materialType"`
	MaterialName          string      `gorm:"column:materialName" json:"materialName"`
	Uom                   string      `gorm:"column:uom" json:"uom"`
	PoList                []PoDetails `gorm:"-" json:"poList"` // 這裡不需要直接映射到資料庫
	LogType               string      `gorm:"column:logType" json:"logType"`
	Brand                 string      `gorm:"column:brand" json:"brand"`
	MaterialOrderNumber   string      `gorm:"column:materialOrderNumber" json:"materialOrderNumber"`
	MaterialOrderQuantity float64     `gorm:"column:materialOrderQuantity" json:"materialOrderQuantity"`
}

type PoDetails struct {
	Po            string  `gorm:"column:po" json:"po"`
	Type          string  `gorm:"column:type" json:"type"`
	ShipId        string  `gorm:"column:shipId" json:"shipId"`
	StyleNumber   string  `gorm:"column:styleNumber" json:"styleNumber"`
	StyleName     string  `gorm:"column:styleName" json:"styleName"`
	ColorCode     string  `gorm:"column:colorCode" json:"colorCode"`
	OrderQuantity float64 `gorm:"column:orderQuantity" json:"orderQuantity"`
	Output        float64 `gorm:"column:output" json:"output"`
}

// PO
type Size struct {
	ID                     uint   `gorm:"column:id" json:"-"` // 忽略 ID
	SizeNumber             string `json:"sizeNumber" gorm:"column:sizeNumber"`
	SizeCompletionQuantity int    `json:"sizeCompletionQuantity" gorm:"column:sizeCompletionQuantity"`
	SizeTargetQuantity     int    `json:"sizeTargetQuantity" gorm:"column:sizeTargetQuantity"`
	MilestoneID            uint   `gorm:"column:milestoneId;index" json:"-"` // 忽略 MilestoneID
	DailyOutput            int    `json:"-" gorm:"column:dailyOutput"`
}

type Milestone struct {
	ID                 uint          `gorm:"column:id" json:"-"` // 忽略 ID
	StageCode          string        `json:"stageCode" gorm:"column:stageCode"`
	CompletionQuantity int           `json:"completionQuantity" gorm:"column:completionQuantity"`
	SizeList           []Size        `json:"sizeList" gorm:"foreignKey:MilestoneID"`           // Size 對應 Milestone
	PoNumber           string        `json:"-" gorm:"column:poNumber"`                         // 外鍵指向 DailyPoStatus
	DailyPoStatus      DailyPoStatus `gorm:"foreignKey:PoNumber;references:PoNumber" json:"-"` // 忽略 DailyPoStatus
}

type FGCheckList struct {
	StageCode  string `gorm:"column:stageCode"`
	PoNumber   string `gorm:"column:poNumber"`
	SizeNumber string `gorm:"column:sizeNumber"`
}

type DailyPoStatus struct {
	Date                 string      `json:"date" gorm:"column:date"`         // 数據归属日期
	PoNumber             string      `json:"poNumber" gorm:"column:poNumber"` // Deckers的PO号
	PoType               string      `json:"poType" gorm:"column:poType"`
	FactoryCode          string      `json:"factoryCode" gorm:"column:factoryCode"`     // 工厂代号编码
	FactoryName          string      `json:"factoryName" gorm:"column:factoryName"`     // 工厂代号名称
	Status               string      `json:"status" gorm:"column:status"`               // PO的当前状态
	StatusMessage        string      `json:"statusMessage" gorm:"column:statusMessage"` // 当前状态补充信息
	StyleNumber          string      `json:"styleNumber" gorm:"column:styleNumber"`     // 形体编码
	StyleName            string      `json:"styleName" gorm:"column:styleName"`         // 型体名称
	ColorCode            string      `json:"colorCode" gorm:"column:colorCode"`         // 颜色代码
	Season               string      `json:"season,omitempty"  gorm:"column:season"`
	ShipID               string      `json:"shipId" gorm:"column:shipId"`                             // Ship ID
	PoCompletionQuantity int         `json:"poCompletionQuantity" gorm:"column:poCompletionQuantity"` // 累计完成生产量
	PoQuantity           int         `json:"poQuantity" gorm:"column:poQuantity"`                     // 订单总量
	LogType              string      `json:"logType" gorm:"column:logType"`                           // 日志时间间隔
	Brand                string      `json:"brand" gorm:"column:brand"`                               // 品牌名称
	ConfirmXFDate        string      `json:"confirmXFDate" gorm:"column:confirmXFDate"`               // 交期
	DDBH                 string      `json:"-" gorm:"column:DDBH"`
	MilestoneList        []Milestone `json:"milestoneList" gorm:"foreignKey:PoNumber;references:PoNumber"` // 各关键节点概况
	XFDetail             []XFDetail  `json:"XFDetail" gorm:"-"`
}
type DailyPoXFStatusSummary struct {
	Date          string      `json:"date"`
	PoNumber      string      `json:"poNumber"`
	PoType        string      `json:"poType"`
	FactoryCode   string      `json:"factoryCode"`
	FactoryName   string      `json:"factoryName"`
	Status        string      `json:"status"`
	StatusMessage string      `json:"statusMessage"`
	StyleNumber   string      `json:"styleNumber"`
	StyleName     string      `json:"styleName"`
	ColorCode     string      `json:"colorCode"`
	Season        string      `json:"season,omitempty"`
	ShipID        string      `json:"shipId"`
	PoQuantity    int         `json:"poQuantity"`
	LogType       string      `json:"logType"`
	Brand         string      `json:"brand"`
	ConfirmXFDate string      `json:"confirmXFDate"`
	XFDetail      []XFSummary `json:"XFDetail"`
}

// ShippedDetailRecord 對應資料庫中的 ShippedDetail 表
type ShippedDetailRecord struct {
	Date          string    `gorm:"column:date;primaryKey"`
	PoNumber      string    `gorm:"column:poNumber;primaryKey"`
	PoType        string    `gorm:"column:poType"`
	FactoryCode   string    `gorm:"column:factoryCode"`
	FactoryName   string    `gorm:"column:factoryName"`
	Status        string    `gorm:"column:status"`
	StatusMessage string    `gorm:"column:statusMessage"`
	StyleNumber   string    `gorm:"column:styleNumber"`
	StyleName     string    `gorm:"column:styleName"`
	ColorCode     string    `gorm:"column:colorCode"`
	Season        string    `gorm:"column:season"`
	ShipID        string    `gorm:"column:shipId;primaryKey"` // 複合 Key 的一部分
	PoQuantity    int       `gorm:"column:poQuantity"`
	LogType       string    `gorm:"column:logType"`
	Brand         string    `gorm:"column:brand"`
	ConfirmXFDate string    `gorm:"column:confirmXFDate"`
	XFDetail      string    `gorm:"column:XFDetail;type:nvarchar(max)"` // 儲存整個 JSON 字串
	UpdatedAt     time.Time `gorm:"column:updated_at"`
}

// type UatDailyPoStatus struct {
// 	DailyPoStatus
// 	XFDetail []XFDetail `json:"XFDetail" gorm:"-"`
// }

type XFDetail struct {
	SizeNumber      string         `json:"sizeNumber" gorm:"-"`
	TotalXFQuantity int            `json:"totalXFQuantity" gorm:"-"`
	Detail          []XFSizeDetail `json:"detail" gorm:"-"`
}

type XFSummary struct {
	XFTime          string `json:"XFTime"`
	TruckNumber     string `json:"truckNumber"`
	ContainerNumber string `json:"containerNumber"`
	TotalXFQuantity int    `json:"totalXFQuantity"`
}

type XFSizeDetail struct {
	XFTime          string `json:"XFTime" gorm:"-"`
	XFQuantity      int    `json:"XFQuantity" gorm:"-"`
	TruckNumber     string `json:"truckNumber" gorm:"-"`
	ContainerNumber string `json:"containerNumber" gorm:"-"`
}

type XFDetailQuery struct {
	PoDailyID       uint      `json:"-" gorm:"column:po_daily_id"`
	XFTime          time.Time `json:"-" gorm:"column:XFTime"`
	RYNO            string    `json:"-" gorm:"column:RYNO"`
	SizeNumber      string    `json:"-" gorm:"column:sizeNumber"`
	TruckNumber     string    `json:"-" gorm:"column:truckNumber"`
	ContainerNumber string    `json:"-" gorm:"column:containerNumber"`
	Quantity        int       `json:"-" gorm:"column:Quantity"`
}

func (XFDetailQuery) TableName() string {
	return "po_daily_xfdetail"
}

func (xf *XFDetailQuery) GetXFTime() string {
	location := time.FixedZone("GMT+7", 7*60*60)
	t := xf.XFTime
	localized := time.Date(
		t.Year(),
		t.Month(),
		t.Day(),
		t.Hour(),
		t.Minute(),
		t.Second(),
		t.Nanosecond(),
		location,
	)
	return localized.Format(time.RFC3339)
}

type PoInfo struct {
	PoNumber      string `json:"poNumber" gorm:"column:poNumber"` // Deckers的PO号
	DDBH          string `json:"RY" gorm:"column:RY"`
	PoType        string `json:"poType" gorm:"column:poType"`
	FactoryCode   string `json:"factoryCode" gorm:"column:factoryCode"` // 工厂代号编码
	FactoryName   string `json:"factoryName" gorm:"column:factoryName"` // 工厂代号名称
	StyleNumber   string `json:"styleNumber" gorm:"column:styleNumber"` // 形体编码
	StyleName     string `json:"styleName" gorm:"column:styleName"`     // 型体名称
	ColorCode     string `json:"colorCode" gorm:"column:colorCode"`     // 颜色代码
	Season        string `json:"season,omitempty"  gorm:"column:season"`
	ShipID        string `json:"shipId" gorm:"column:shipId"` // Ship ID
	Dest          string `json:"dest" gorm:"column:dest"`
	PoQuantity    int    `json:"poQuantity" gorm:"column:poQuantity"`       // 订单总量
	Brand         string `json:"brand" gorm:"column:brand"`                 // 品牌名称
	ConfirmXFDate string `json:"confirmXFDate" gorm:"column:confirmXFDate"` // 交期
}

// FG
type DeckerOutputsFG struct {
	StartTime   string `json:"startTime" gorm:"column:startTime"`     // 数据起始时间
	EndTime     string `json:"endTime" gorm:"column:endTime"`         // 数据结束时间
	FactoryCode string `json:"factoryCode" gorm:"column:factoryCode"` // 工厂在Deckers的代号编码(F190)
	FactoryName string `json:"factoryName" gorm:"column:factoryName"` // 工厂在Deckers的代号名称(FT-YS)
	StageCode   string `json:"stageCode" gorm:"column:stageCode"`     // 数据采集点的代号(使用ENUM)
	PoNumber    string `json:"poNumber" gorm:"column:poNumber"`       // Deckers的PO号
	PoType      string `json:"poType" gorm:"column:poType"`           // PO的类型；PO, CO, PreLoad
	StyleNumber string `json:"styleNumber" gorm:"column:styleNumber"` // 形体编码
	StyleName   string `json:"styleName" gorm:"column:styleName"`     // 型体名称
	ColorCode   string `json:"colorCode" gorm:"column:colorCode"`     // 颜色代码
	ShipId      string `json:"shipId" gorm:"column:shipId"`           // Deckers PO对应的shipID
	SizeNumber  string `json:"sizeNumber" gorm:"column:sizeNumber"`   // 尺寸号
	Output      int    `json:"output" gorm:"column:output"`           // 产量
	LogType     string `json:"logType" gorm:"column:logType"`         // 统计间隔类型(1h)
	Brand       string `json:"brand" gorm:"column:brand"`
}

type SizeInfo struct {
	StyleNumber string `json:"styleNumber"`
	ColorCode   string `json:"colorCode"`
	SizeNumber  string `json:"sizeNumber"`
}

type CancelPoInfo struct {
	PoNumber string
	ShipId   string
}
