package types

import "time"

type BgradeInventory struct {
	FactoryCode    string       `json:"factoryCode" gorm:"column:FactoryCode"`
	FactoryName    string       `json:"factoryName" gorm:"column:FactoryName"`
	Brand          string       `json:"brand" gorm:"column:Brand"`
	StyleNumber    string       `json:"styleNumber" gorm:"column:StyleNumber"`
	StyleName      string       `json:"styleName" gorm:"column:StyleName"`
	ColorCode      string       `json:"colorCode" gorm:"column:ColorCode"`
	InventoryDate  string       `json:"inventoryDate" gorm:"column:InventoryDate"`
	TotalBGradeQty int          `json:"totalBgradeQty" gorm:"column:TotalBGradeQty"`
	SizeDetailList []SizeDetail `json:"sizeDetailList" gorm:"-"`
	IODetailList   []IODetail   `json:"ioDetailList" gorm:"-"`
	Remark         string       `json:"remark" gorm:"column:Remark"`
}

func (bgrade *BgradeInventory) ExtractExcel() BgradeInventoryExcel {
	return BgradeInventoryExcel{
		FactoryCode:    bgrade.FactoryCode,
		FactoryName:    bgrade.FactoryName,
		Brand:          bgrade.Brand,
		StyleNumber:    bgrade.StyleNumber,
		StyleName:      bgrade.StyleName,
		ColorCode:      bgrade.ColorCode,
		InventoryDate:  bgrade.InventoryDate,
		TotalBGradeQty: bgrade.TotalBGradeQty,
		SizeDetailList: GetStringJson(bgrade.SizeDetailList),
		IODetailList:   GetStringJson(bgrade.IODetailList),
		Remark:         bgrade.Remark,
	}
}

type SizeDetail struct {
	StyleNumber string `json:"-" gorm:"column:StyleNumber"`
	ColorCode   string `json:"-" gorm:"column:ColorCode"`
	SizeNumber  string `json:"sizeNumber" gorm:"column:Size"`
	Qty         uint   `json:"qty" gorm:"column:Qty"`
}

type IODetail struct {
	Type             string       `json:"type" gorm:"column:IoType"`
	PoNumber         string       `json:"poNumber,omitempty" gorm:"column:KHPO"`
	PoType           string       `json:"poType,omitempty" gorm:"column:PoType"`
	Source           string       `json:"source,omitempty" gorm:"column:Source"`
	Qty              uint         `json:"qty" gorm:"-"`
	Reason           string       `json:"reason" gorm:"column:Reason"`
	Timestamp        string       `json:"timestamp" gorm:"-"`
	IoSizeDetailList []SizeDetail `json:"ioSizeDetailList" gorm:"-"`
	StyleNumber      string       `json:"-" gorm:"column:StyleNumber"`
	ColorCode        string       `json:"-" gorm:"column:ColorCode"`
	QueryTime        time.Time    `json:"-" gorm:"column:Timestamp"`
	SizeNumber       string       `json:"-" gorm:"column:Size"`
	SizeQty          uint         `json:"-" gorm:"column:Io_Qty"`
}
