package response

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// 通用的回應結構
type CommonResponse struct {
	Code    int         `json:"code"`
	Data    interface{} `json:"data"`
	Message string      `json:"message"`
}

// 定義 TokenResponse 結構
type TokenResponse struct {
	Token string `json:"token"`
}

// Result 用來統一結構化回應
func Result(ctx *gin.Context, code int, data interface{}, message string) {
	ctx.JSON(code, CommonResponse{
		Code:    code,
		Data:    data,
		Message: message,
	})
}

// Ok 用來返回成功回應，沒有數據
func Ok(ctx *gin.Context) {
	Result(ctx, http.StatusOK, nil, "success")
}

// OkWithMessage 返回成功，並附加自定義訊息
func OkWithMessage(ctx *gin.Context, message string) {
	Result(ctx, http.StatusOK, nil, message)
}

// OkWithData 返回成功，並附加數據
func OkWithData(ctx *gin.Context, data interface{}) {
	Result(ctx, http.StatusOK, data, "success")
}

// OkWithDetailed 返回成功，並附加詳細的數據和訊息
func OkWithDetailed(ctx *gin.Context, code int, data interface{}, message string) {
	Result(ctx, code, data, message)
}

// Fail 返回失敗，沒有數據
func Fail(ctx *gin.Context) {
	Result(ctx, http.StatusInternalServerError, nil, "failure")
}

// FailWithMessage 返回失敗，並附加自定義訊息
func FailWithMessage(ctx *gin.Context, message string) {
	Result(ctx, http.StatusInternalServerError, nil, message)
}

// FailWithDetailed 返回失敗，並附加詳細的數據和訊息
func FailWithDetailed(ctx *gin.Context, code int, data interface{}, message string) {
	Result(ctx, code, data, message)
}

// 返回成功的 Token
func OkWithToken(ctx *gin.Context, token string) {
	// 創建 TokenResponse
	tokenResp := TokenResponse{
		Token: token,
	}
	// 返回結構化的結果
	Result(ctx, http.StatusOK, tokenResp, "success")
}
