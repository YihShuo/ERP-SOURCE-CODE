package response

type DeckerResponse struct {
	RetID   string `json:"retId"`
	RetCode int    `json:"retCode"`
	RetMsg  string `json:"retMsg"`
}
