package database

import (
	"errors"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"time"

	"web-api/internal/pkg/config"
	"web-api/internal/pkg/models/request"

	"gorm.io/driver/mysql"
	"gorm.io/driver/postgres"
	"gorm.io/driver/sqlite"
	"gorm.io/driver/sqlserver"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var (
	DB *gorm.DB
)

type Database struct {
	*gorm.DB
}

func Setup() error {
	configuration := config.GetConfig()

	db, err := CreateDatabaseConnection(configuration)
	if err != nil {
		return err
	}

	DB = db
	migration()

	return nil
}

func CreateDatabaseConnection(configuration *config.EnvironmentConfiguration) (*gorm.DB, error) {
	driver := strings.ToLower(configuration.Database.Driver)
	dsn, err := buildDSN(driver, configuration)
	if err != nil {
		return nil, errors.New("failed to build DSN")
	}

	logmode := configuration.Database.Logmode
	loglevel := logger.Silent
	if logmode {
		loglevel = logger.Info
	}
	newDBLogger := logger.New(
		log.New(getWriter(), "\r\n", log.LstdFlags), // io writer
		logger.Config{
			SlowThreshold:             time.Second, // Slow SQL threshold
			LogLevel:                  loglevel,    // Log level (Silent, Error, Warn, Info)
			IgnoreRecordNotFoundError: true,        // Ignore ErrRecordNotFound error for logger
			Colorful:                  false,       // Disable color
		},
	)

	var db *gorm.DB
	switch driver {
	case "mysql":
		db, err = gorm.Open(mysql.Open(dsn), &gorm.Config{Logger: newDBLogger})
	case "postgres":
		db, err = gorm.Open(postgres.Open(dsn), &gorm.Config{Logger: newDBLogger})
	case "sqlite":
		db, err = gorm.Open(sqlite.Open(dsn), &gorm.Config{Logger: newDBLogger})
	case "sqlserver":
		db, err = gorm.Open(sqlserver.Open(dsn), &gorm.Config{Logger: newDBLogger})
	}

	if err != nil {
		return nil, err
	}

	return db, nil

}

func buildDSN(driver string, configuration *config.EnvironmentConfiguration) (string, error) {
	switch driver {
	case "mysql":
		return fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8&parseTime=True", configuration.Database.Username, configuration.Database.Password, configuration.Database.Host, configuration.Database.Port, configuration.Database.Dbname), nil
	case "postgres":
		mode := "disable"
		if configuration.Database.Sslmode {
			mode = "require"
		}
		return fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%s sslmode=%s", configuration.Database.Host, configuration.Database.Username, configuration.Database.Password, configuration.Database.Dbname, configuration.Database.Port, mode), nil
	case "sqlite":
		return "./" + configuration.Database.Dbname + ".db", nil
	case "sqlserver":
		mode := "disable"
		if configuration.Database.Sslmode {
			mode = "true"
		}
		return fmt.Sprintf("sqlserver://%s:%s@%s:%s?database=%s&encrypt=%s", configuration.Database.Username, configuration.Database.Password, configuration.Database.Host, configuration.Database.Port, configuration.Database.Dbname, mode), nil
	default:
		return "", fmt.Errorf("unsupported database driver: %s", driver)
	}
}

func getWriter() io.Writer {
	file, err := os.OpenFile("log/database.log", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		return os.Stdout
	} else {
		return file
	}
}

func migration() {

}

func GetDB() *gorm.DB {
	return DB
}

func SetupDatabaseConnection(databaseType string) (*gorm.DB, string, string, string, map[string][]string, error) {
	var db *gorm.DB
	var err error

	factoryCode, factoryName, GSBH, DDBH := getParams(databaseType)

	switch databaseType {
	case "A":
		db, err = TyThacERPConnection()
	case "B":
		db, err = TyBachERPConnection()
	case "C":
		db, err = YiQuanERPConnection()
	case "D": // for use backup DB purpose
		factoryCode, factoryName, GSBH, DDBH = "FE12", "FT-YS", "VDH", map[string][]string{
			"PO":      {"JHS%", "JTS%"},
			"Preload": {"F%"},
			"Seeding": {"HK%", "HFS%"},
		}
		db, err = BackupERPConnection()
	default:
		return nil, "", "", "", nil, fmt.Errorf("invalid database type: %s", databaseType)
	}

	if err != nil {
		return nil, "", "", "", nil, fmt.Errorf("failed to connect to database: %v", err)
	}

	return db, factoryCode, factoryName, GSBH, DDBH, nil
}

func SetupCustomDatabaseConnection(request request.PoListDb) (*gorm.DB, string, string, string, map[string][]string, error) {
	var db *gorm.DB
	var err error

	factoryCode, factoryName, GSBH, DDBH := getParams(request.DatabaseType)

	db, err = CustomConnection(request)
	if err != nil {
		return nil, "", "", "", nil, fmt.Errorf("failed to connect to database: %v", err)
	}

	return db, factoryCode, factoryName, GSBH, DDBH, nil
}

func getParams(databaseType string) (string, string, string, map[string][]string) {
	switch databaseType {
	case "A":
		return "FE12", "FT-YS", "VDH", map[string][]string{
			"PO":      {"JHS%", "JTS%"},
			"Preload": {"F%"},
			"Seeding": {"HK%", "HFS%"},
		}
	case "B":
		return "FY10", "FT-VNTB", "HBA", map[string][]string{
			"Seeding": {"DHK%"},
			"PO":      {"DH[0-9]%", "DE%"},
			"Preload": {"F%"},
		}
	case "C":
		return "FI-11", "FT-IDNYQ", "VA12", map[string][]string{
			"PO":      {"IH%"},
			"Preload": {"F%"},
			"Seeding": {},
		}
	default:
		return "", "", "", nil
	}
}

func TyThacERPConnection() (*gorm.DB, error) {
	configuration := config.GetConfig()
	configuration.Database.Host = "192.168.71.7"
	configuration.Database.Username = "tyxuan"
	configuration.Database.Password = "jack"
	configuration.Database.Dbname = "LYS_ERP"
	return CreateDatabaseConnection(configuration)
}
func BackupERPConnection() (*gorm.DB, error) {
	configuration := config.GetConfig()
	configuration.Database.Host = "192.168.71.99"
	configuration.Database.Username = "sa"
	configuration.Database.Password = "IT@Admin17"
	configuration.Database.Dbname = "LYS_ERP"
	return CreateDatabaseConnection(configuration)
}
func TyBachERPConnection() (*gorm.DB, error) {
	configuration := config.GetConfig()
	configuration.Database.Host = "192.168.40.9"
	configuration.Database.Username = "tyxuan"
	configuration.Database.Password = "jack"
	configuration.Database.Dbname = "TB_ERP"
	return CreateDatabaseConnection(configuration)
}
func YiQuanERPConnection() (*gorm.DB, error) {
	configuration := config.GetConfig()
	configuration.Database.Host = "192.168.110.1"
	configuration.Database.Username = "yihquan"
	configuration.Database.Password = "VF9cVGeWQqmbZuSa"
	configuration.Database.Dbname = "LIY_ERP"
	return CreateDatabaseConnection(configuration)
}
func RPConnection() (*gorm.DB, error) {
	configuration := config.GetConfig()
	configuration.Database.Host = "192.168.23.9"
	configuration.Database.Username = "tyxuan"
	configuration.Database.Password = "Erp@admin2309"
	configuration.Database.Dbname = "LIY_ERP"
	return CreateDatabaseConnection(configuration)
}

func CustomConnection(request request.PoListDb) (*gorm.DB, error) {
	configuration := config.GetConfig()
	configuration.Database.Host = request.Host
	configuration.Database.Username = request.Username
	configuration.Database.Password = request.Password
	configuration.Database.Dbname = request.DatabaseName
	return CreateDatabaseConnection(configuration)
}
