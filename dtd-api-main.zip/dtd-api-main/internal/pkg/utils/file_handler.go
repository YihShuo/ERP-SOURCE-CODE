package utils

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"web-api/internal/pkg/models/types"

	"github.com/xuri/excelize/v2"
)

func WriteStructsToJSONFile[T any](data []T, filename string) error {
	// Mã hóa slice thành JSON
	jsonData, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal error: %w", err)
	}

	// Ghi JSON vào file
	err = os.WriteFile(filename, jsonData, 0644)
	if err != nil {
		return fmt.Errorf("write file error: %w", err)
	}

	return nil
}

func WriteStructsToExcel(filename string, sheet string, data []types.POExcelReport) error {
	f := excelize.NewFile()
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"日期(date)", "客戶訂單編號(khpo)", "Style No#", "Color", "Ship ID", "訂單狀態(status)", "數量(Qty)",
		"RM0-1", "RM0-3", "WIP3-1", "WIP3-1 Today Output", "WIP3-3", "WIP3-3 Today Output", "WIP6", "WIP6 Today Output", "WIP8", "WIP8 Today Output", "FG10", "FG14",
	}

	// Tạo style cho header: nền xanh lục, chữ đậm, canh giữa
	styleHeader, err := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#C6EFCE"}, Pattern: 1},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})

	styleOutput, err := f.NewStyle(&excelize.Style{
		Fill: excelize.Fill{
			Type:    "pattern",
			Color:   []string{"#E2F0D9"}, // 綠黃色（Excel 常用 Highlight）
			Pattern: 1,
		},
		Alignment: &excelize.Alignment{
			Horizontal: "center",
		},
	})
	if err != nil {
		return err
	}

	// Ghi tiêu đề
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h)
		f.SetCellStyle(sheet, cell, cell, styleHeader)
	}

	// Ghi dữ liệu
	for rowIdx, order := range data {
		row := rowIdx + 2

		f.SetCellValue(sheet, fmt.Sprintf("A%d", row), order.Date)
		f.SetCellValue(sheet, fmt.Sprintf("B%d", row), order.KHPO)
		f.SetCellValue(sheet, fmt.Sprintf("C%d", row), order.StyleNo)
		f.SetCellValue(sheet, fmt.Sprintf("D%d", row), order.ColorCode)
		f.SetCellValue(sheet, fmt.Sprintf("E%d", row), order.ShipID)
		f.SetCellValue(sheet, fmt.Sprintf("F%d", row), order.Status)
		f.SetCellValue(sheet, fmt.Sprintf("G%d", row), order.Qty)

		f.SetCellValue(sheet, fmt.Sprintf("H%d", row), order.RM01)
		f.SetCellValue(sheet, fmt.Sprintf("I%d", row), order.RM03)

		f.SetCellValue(sheet, fmt.Sprintf("J%d", row), order.WIP31)
		f.SetCellValue(sheet, fmt.Sprintf("K%d", row), order.WIP31Output)
		f.SetCellStyle(sheet, fmt.Sprintf("K%d", row), fmt.Sprintf("K%d", row), styleOutput)

		f.SetCellValue(sheet, fmt.Sprintf("L%d", row), order.WIP33)
		f.SetCellValue(sheet, fmt.Sprintf("M%d", row), order.WIP33Output)
		f.SetCellStyle(sheet, fmt.Sprintf("M%d", row), fmt.Sprintf("M%d", row), styleOutput)

		f.SetCellValue(sheet, fmt.Sprintf("N%d", row), order.WIP6)
		f.SetCellValue(sheet, fmt.Sprintf("O%d", row), order.WIP6Output)
		f.SetCellStyle(sheet, fmt.Sprintf("O%d", row), fmt.Sprintf("O%d", row), styleOutput)

		f.SetCellValue(sheet, fmt.Sprintf("P%d", row), order.WIP8)
		f.SetCellValue(sheet, fmt.Sprintf("Q%d", row), order.WIP8Output)
		f.SetCellStyle(sheet, fmt.Sprintf("Q%d", row), fmt.Sprintf("Q%d", row), styleOutput)

		f.SetCellValue(sheet, fmt.Sprintf("R%d", row), order.FG10)
		f.SetCellValue(sheet, fmt.Sprintf("S%d", row), order.FG14)
	}

	// Lưu file
	if err := f.SaveAs(filename); err != nil {
		return err
	}

	log.Println("Excel file has been created.")
	return nil
}

func WriteRepackingExcel(filename string, sheet string, data []types.RepackingResultExcel) error {
	f := excelize.NewFile()
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"Factory Code", "Factory Name", "Brand", "Style Number", "Style Name", "Color Code", "PO Number", "PO Type", "Ship ID",
		"Line Number", "Inspection Type", "Inspection Time", "Lot Number", "Inspected Qty", "Pass Qty", "Repair Qty", "B-grade Qty",
		"C-grade Qty", "Repair Reason", "Reject Reason", "Approved By", "Approved Time", "Return ID",
	}

	// Tạo style cho header: nền xanh lục, chữ đậm, canh giữa
	styleHeader, err := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#C6EFCE"}, Pattern: 1},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	if err != nil {
		return err
	}

	// Ghi tiêu đề
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h)
		f.SetCellStyle(sheet, cell, cell, styleHeader)
	}

	// Ghi dữ liệu
	for rowIdx, order := range data {
		row := rowIdx + 2

		f.SetCellValue(sheet, fmt.Sprintf("A%d", row), order.FactoryCode)
		f.SetCellValue(sheet, fmt.Sprintf("B%d", row), order.FactoryName)
		f.SetCellValue(sheet, fmt.Sprintf("C%d", row), order.Brand)
		f.SetCellValue(sheet, fmt.Sprintf("D%d", row), order.StyleNumber)
		f.SetCellValue(sheet, fmt.Sprintf("E%d", row), order.StyleName)
		f.SetCellValue(sheet, fmt.Sprintf("F%d", row), order.ColorCode)
		f.SetCellValue(sheet, fmt.Sprintf("G%d", row), order.PoNumber)
		f.SetCellValue(sheet, fmt.Sprintf("H%d", row), order.PoType)
		f.SetCellValue(sheet, fmt.Sprintf("I%d", row), order.ShipID)
		f.SetCellValue(sheet, fmt.Sprintf("J%d", row), order.LineNumber)
		f.SetCellValue(sheet, fmt.Sprintf("K%d", row), order.InspectionType)
		f.SetCellValue(sheet, fmt.Sprintf("L%d", row), order.InspectTime)
		f.SetCellValue(sheet, fmt.Sprintf("M%d", row), order.LotNumber)
		f.SetCellValue(sheet, fmt.Sprintf("N%d", row), order.InspectedQty)
		f.SetCellValue(sheet, fmt.Sprintf("O%d", row), order.PassQty)
		f.SetCellValue(sheet, fmt.Sprintf("P%d", row), order.RepairQty)
		f.SetCellValue(sheet, fmt.Sprintf("Q%d", row), order.BGradeQty)
		f.SetCellValue(sheet, fmt.Sprintf("R%d", row), order.CGradeQty)
		f.SetCellValue(sheet, fmt.Sprintf("S%d", row), order.RepairReasonList)
		f.SetCellValue(sheet, fmt.Sprintf("T%d", row), order.RejectReasonList)
		f.SetCellValue(sheet, fmt.Sprintf("U%d", row), order.ApprovedBy)
		f.SetCellValue(sheet, fmt.Sprintf("V%d", row), order.ApprovedTime)
		f.SetCellValue(sheet, fmt.Sprintf("W%d", row), order.ReturnID)
	}

	// Lưu file
	if err := f.SaveAs(filename); err != nil {
		return err
	}

	log.Println("Excel file has been created.")
	return nil
}

func WriteBgradeExcel(filename string, sheet string, data []types.BgradeInventoryExcel) error {
	f := excelize.NewFile()
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"Factory Code", "Factory Name", "Brand", "Style Number", "Style Name", "Color Code", "Inventory Date",
		"Total B-grade Qty", "Size Detail List", "IO Detail List", "Remark", "Return ID",
	}

	// Tạo style cho header: nền xanh lục, chữ đậm, canh giữa
	styleHeader, err := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#C6EFCE"}, Pattern: 1},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	if err != nil {
		return err
	}

	// Ghi tiêu đề
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h)
		f.SetCellStyle(sheet, cell, cell, styleHeader)
	}

	// Ghi dữ liệu
	for rowIdx, order := range data {
		row := rowIdx + 2

		f.SetCellValue(sheet, fmt.Sprintf("A%d", row), order.FactoryCode)
		f.SetCellValue(sheet, fmt.Sprintf("B%d", row), order.FactoryName)
		f.SetCellValue(sheet, fmt.Sprintf("C%d", row), order.Brand)
		f.SetCellValue(sheet, fmt.Sprintf("D%d", row), order.StyleNumber)
		f.SetCellValue(sheet, fmt.Sprintf("E%d", row), order.StyleName)
		f.SetCellValue(sheet, fmt.Sprintf("F%d", row), order.ColorCode)
		f.SetCellValue(sheet, fmt.Sprintf("G%d", row), order.InventoryDate)
		f.SetCellValue(sheet, fmt.Sprintf("H%d", row), order.TotalBGradeQty)
		f.SetCellValue(sheet, fmt.Sprintf("I%d", row), order.SizeDetailList)
		f.SetCellValue(sheet, fmt.Sprintf("J%d", row), order.IODetailList)
		f.SetCellValue(sheet, fmt.Sprintf("K%d", row), order.Remark)
		f.SetCellValue(sheet, fmt.Sprintf("L%d", row), order.ReturnID)
	}

	// Lưu file
	if err := f.SaveAs(filename); err != nil {
		return err
	}

	log.Println("Excel file has been created.")
	return nil
}

func WriteStructsToExcelEmptyShipID(filename string, sheet string, data []types.PoInfo) error {
	f := excelize.NewFile()
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"PO Number", "DDBH", "PO Type", "Factory Code", "Factory Name", "Style Number", "Style Name",
		"Color Code", "Season", "Ship ID", "DEST", "PO Quantity", "brand", "confirmXFDate",
	}

	// Tạo style cho header: nền xanh lục, chữ đậm, canh giữa
	styleHeader, err := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#C6EFCE"}, Pattern: 1},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	if err != nil {
		panic(err)
	}

	// Ghi tiêu đề
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h)
		f.SetCellStyle(sheet, cell, cell, styleHeader)
	}

	// Ghi dữ liệu
	for rowIdx, po := range data {
		row := rowIdx + 2 // dòng bắt đầu từ 2
		f.SetCellValue(sheet, fmt.Sprintf("A%d", row), po.PoNumber)
		f.SetCellValue(sheet, fmt.Sprintf("B%d", row), po.DDBH)
		f.SetCellValue(sheet, fmt.Sprintf("C%d", row), po.PoType)
		f.SetCellValue(sheet, fmt.Sprintf("D%d", row), po.FactoryCode)
		f.SetCellValue(sheet, fmt.Sprintf("E%d", row), po.FactoryName)
		f.SetCellValue(sheet, fmt.Sprintf("F%d", row), po.StyleNumber)
		f.SetCellValue(sheet, fmt.Sprintf("G%d", row), po.StyleName)
		f.SetCellValue(sheet, fmt.Sprintf("H%d", row), po.ColorCode)
		f.SetCellValue(sheet, fmt.Sprintf("I%d", row), po.Season)
		f.SetCellValue(sheet, fmt.Sprintf("J%d", row), po.ShipID)
		f.SetCellValue(sheet, fmt.Sprintf("K%d", row), po.Dest)
		f.SetCellValue(sheet, fmt.Sprintf("L%d", row), po.PoQuantity)
		f.SetCellValue(sheet, fmt.Sprintf("M%d", row), po.Brand)
		f.SetCellValue(sheet, fmt.Sprintf("N%d", row), po.ConfirmXFDate)
	}

	// Lưu file
	if err := f.SaveAs(filename); err != nil {
		return err
	}

	log.Println("Excel file has been created.")
	return nil
}

func WriteStructsToExcelFGReport(filename string, sheet string, data []types.FGReport) error {
	f := excelize.NewFile()
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"Factory Code", "Factory Name", "PO Type", "KHPO", "Style Number", "Color Code", "Ship ID",
		"PO Quantity", "Factory FG10", "DTD FG10", "Factory FG14", "DTD FG14", "Deckers's Return ID",
	}

	// Tạo style cho header: nền xanh lục, chữ đậm, canh giữa
	styleHeader, err := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#C6EFCE"}, Pattern: 1},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	if err != nil {
		panic(err)
	}

	// Ghi tiêu đề
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h)
		f.SetCellStyle(sheet, cell, cell, styleHeader)
	}

	// Set size for return ID
	f.SetColWidth(sheet, "M", "M", 30)

	// Ghi dữ liệu
	for rowIdx, fg := range data {
		row := rowIdx + 2 // dòng bắt đầu từ 2
		f.SetCellValue(sheet, fmt.Sprintf("A%d", row), fg.FactoryCode)
		f.SetCellValue(sheet, fmt.Sprintf("B%d", row), fg.FactoryName)
		f.SetCellValue(sheet, fmt.Sprintf("C%d", row), fg.PoType)
		f.SetCellValue(sheet, fmt.Sprintf("D%d", row), fg.KHPO)
		f.SetCellValue(sheet, fmt.Sprintf("E%d", row), fg.StyleNumber)
		f.SetCellValue(sheet, fmt.Sprintf("F%d", row), fg.ColorCode)
		f.SetCellValue(sheet, fmt.Sprintf("G%d", row), fg.ShipID)
		f.SetCellValue(sheet, fmt.Sprintf("H%d", row), fg.Quantity)
		f.SetCellValue(sheet, fmt.Sprintf("I%d", row), fg.FactoryFG10)
		f.SetCellValue(sheet, fmt.Sprintf("J%d", row), fg.DtdFG10)
		f.SetCellValue(sheet, fmt.Sprintf("K%d", row), fg.FactoryFG10)
		f.SetCellValue(sheet, fmt.Sprintf("L%d", row), fg.DtdFG10)
		f.SetCellValue(sheet, fmt.Sprintf("M%d", row), fg.ReturnID)
	}

	// Lưu file
	if err := f.SaveAs(filename); err != nil {
		return err
	}

	log.Println("Excel file has been created.")
	return nil
}

func WriteWIPToExcel(filename string, sheet string, data []types.WIPExcelResult) error {
	f := excelize.NewFile()
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"日期(date)", "客戶訂單編號(khpo)", "RY", "Style No#", "Color", "Ship ID", "數量(Qty)",
		"WIP3-1", "WIP3-3", "WIP6", "WIP8",
	}

	// Tạo style cho header: nền xanh lục, chữ đậm, canh giữa
	styleHeader, err := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#C6EFCE"}, Pattern: 1},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	if err != nil {
		return err
	}

	// Ghi tiêu đề
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h)
		f.SetCellStyle(sheet, cell, cell, styleHeader)
	}

	// Ghi dữ liệu
	for rowIdx, wip := range data {
		row := rowIdx + 2 // dòng bắt đầu từ 2
		f.SetCellValue(sheet, fmt.Sprintf("A%d", row), wip.Date)
		f.SetCellValue(sheet, fmt.Sprintf("B%d", row), wip.KHPO)
		f.SetCellValue(sheet, fmt.Sprintf("C%d", row), wip.DDBH)
		f.SetCellValue(sheet, fmt.Sprintf("D%d", row), wip.StyleNumber)
		f.SetCellValue(sheet, fmt.Sprintf("E%d", row), wip.ColorCode)
		f.SetCellValue(sheet, fmt.Sprintf("F%d", row), wip.ShipID)
		f.SetCellValue(sheet, fmt.Sprintf("G%d", row), wip.Qty)
		f.SetCellValue(sheet, fmt.Sprintf("H%d", row), wip.WIP31)
		f.SetCellValue(sheet, fmt.Sprintf("I%d", row), wip.WIP33)
		f.SetCellValue(sheet, fmt.Sprintf("J%d", row), wip.WIP6)
		f.SetCellValue(sheet, fmt.Sprintf("K%d", row), wip.WIP8)
	}

	// Lưu file
	if err := f.SaveAs(filename); err != nil {
		return err
	}

	log.Println("Excel file has been created.")
	return nil
}

// DeleteFile xóa một tệp tin nếu tồn tại.
// Trả về nil nếu xóa thành công hoặc file không tồn tại, trả về lỗi nếu gặp vấn đề khác.
func DeleteFile(path string) error {
	err := os.Remove(path)
	if err != nil {
		if os.IsNotExist(err) {
			// File không tồn tại – không phải lỗi nghiêm trọng
			fmt.Printf("File not found: %s (already deleted?)\n", path)
			return nil
		}
		// Lỗi khác khi xóa
		return fmt.Errorf("failed to delete file %s: %w", path, err)
	}
	fmt.Printf("Deleted file: %s\n", path)
	return nil
}

func ParseExcelFile(fileReader interface{}) ([]types.ExcelData, error) {
	// Cast lại thành io.Reader
	reader, ok := fileReader.(interface {
		Read([]byte) (int, error)
	})
	if !ok {
		return nil, errors.New("invalid file reader")
	}

	excel, err := excelize.OpenReader(reader)
	if err != nil {
		return nil, err
	}

	sheetName := excel.GetSheetName(0)
	rows, err := excel.GetRows(sheetName)
	if err != nil {
		return nil, err
	}

	var result []types.ExcelData
	for i, row := range rows {
		if i == 0 {
			continue // bỏ qua tiêu đề
		}
		risk := getCell(row, 1)
		if risk == "On Track" {
			continue
		}

		data := types.ExcelData{
			PoNumber:  getCell(row, 3),
			Factory:   getCell(row, 11),
			RiskLevel: risk,
		}

		result = append(result, data)
	}

	return result, nil
}

func WriteStructsToExcelDelayWarning(filename string, sheet string, data []types.DelayWarningOrder) error {
	f := excelize.NewFile()
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"FACTORY (工廠訂單號)\nRY#", "Factory (廠別)", "BUY SEASON", "BUY MONTH", "PO# (訂單號碼)", "STYLE NO#", "SHIP ID#",
		"STYLE NAME", "COLOR", "Q'TY", "CURRENT XF DATE (出貨日期)", "CUTTING STATUS (裁斷/一裁狀態)", "DESTINATION (出貨目的地)", "INSPECTION STATUS (驗貨狀態)",
	}

	// Tạo style cho header: nền xanh lục, chữ đậm, canh giữa
	styleHeader, err := f.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#C6EFCE"}, Pattern: 1},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	if err != nil {
		panic(err)
	}

	// Ghi tiêu đề
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h)
		f.SetCellStyle(sheet, cell, cell, styleHeader)
	}

	// Ghi dữ liệu
	for rowIdx, order := range data {
		row := rowIdx + 2 // dòng bắt đầu từ 2
		f.SetCellValue(sheet, fmt.Sprintf("A%d", row), order.RY)
		f.SetCellValue(sheet, fmt.Sprintf("B%d", row), order.Factory)
		f.SetCellValue(sheet, fmt.Sprintf("C%d", row), order.BuySeason)
		f.SetCellValue(sheet, fmt.Sprintf("D%d", row), order.BuyMonth)
		f.SetCellValue(sheet, fmt.Sprintf("E%d", row), order.PO)
		f.SetCellValue(sheet, fmt.Sprintf("F%d", row), order.StyleNumber)
		f.SetCellValue(sheet, fmt.Sprintf("G%d", row), order.ShipId)
		f.SetCellValue(sheet, fmt.Sprintf("H%d", row), order.StyleName)
		f.SetCellValue(sheet, fmt.Sprintf("I%d", row), order.ColorCode)
		f.SetCellValue(sheet, fmt.Sprintf("J%d", row), order.Qty)
		f.SetCellValue(sheet, fmt.Sprintf("K%d", row), order.XFDate)
		f.SetCellValue(sheet, fmt.Sprintf("L%d", row), order.CuttingStatus)
		f.SetCellValue(sheet, fmt.Sprintf("M%d", row), order.Destination)
		f.SetCellValue(sheet, fmt.Sprintf("N%d", row), order.InspectionStatus)
	}

	// Lưu file
	if err := f.SaveAs(filename); err != nil {
		return err
	}

	log.Println("Excel file has been created.")
	return nil
}

func getCell(row []string, index int) string {
	if len(row) > index {
		return row[index]
	}
	return ""
}
