package utils

import (
	"encoding/base64"
	"fmt"
	"log"
	"net/smtp"
	"os"
	"path/filepath"
	"strings"
)

type mailSender struct {
	From     string
	Password string
	SMTPHost string
	SMTPPort string
}

var MailSenderInstance = &mailSender{
	From:     "workflow@tyxuan.com.vn",
	Password: "Qwert@369*",
	SMTPHost: "mail.tyxuan.com.vn",
	SMTPPort: "587",
}

func GetPublicRecipients(databaseType string) (to []string, cc []string) {
	switch databaseType {
	case "A":
		to = []string{
			"katie.yang@tythac.com.vn",
			"sales01@tythac.com.vn",
			"chanel.yang@tythac.com.vn",
			"sales03@tythac.com.vn",
			"sales@tythac.com.vn",
			"anhit@tythac.com.vn",
		}
		cc = []string{
			"kevinkuo@tyxuan.com.vn",
			"liutonghao@tyxuan.com.vn",
			"tythac339967@gmail.com",
			"eleanor@laiyih.com.tw",
			"simon@tythac.com.vn",
			"wangjinhua@tyxuan.com.vn",
			"liang0810@tythac.com.vn",
			"lywu@tythac.com.vn",
			"hangdt@tythac.com.vn",
			"khiemsq@tythac.com.vn",
			"nhusq@tythac.com.vn",
			"giangktp@tythac.com.vn",
			"giangsq@tythac.com.vn",
			"Taiit@tythac.com.vn",
			"CIKevin@tythac.com.vn",
			"josef@tythac.com.vn",
			"tuyetsq@tythac.com.vn",
		}

	case "B":
		to = []string{
			"shaneskylin@tybach.com.vn",
			"B_nvtb@tybach.com.vn",
			"sales01@tythac.com.vn",
			"chanel.yang@tythac.com.vn",
		}
		cc = []string{
			"roger631@tybach.com.vn",
			"cfqian@tybach.com.vn",
			"kevinkuo@tyxuan.com.vn",
			"liutonghao@tyxuan.com.vn",
			"vinhit@tybach.com.vn",
			"austin@tybach.com.vn",
			"tythac339967@gmail.com",
			"chenhongmin@tybach.com.vn",
			"hungcuong@tybach.com.vn",
			"thienlysq@tybach.com.vn",
			"vocamtu@tybach.com.vn",
			"phuochuu@tybach.com.vn",
			"thuyanhsq@tybach.com.vn",
			"wuxiaoqiang@tybach.com.vn",
			"chungchiaoyi@tybach.com.vn",
			"yuankai@tybach.com.vn",
		}

	case "C":
		to = []string{
			"sharon2024@yihquan.co.id",
			"bogie_angga168@yihquan.co.id",
			"johny_chen076@yihquan.co.id",
			"xinbai_tan041@yihquan.co.id",
			"jackie_pan174@yihquan.co.id",
			"lico_mo2024@yihquan.co.id",
			"chanel.yang@tythac.com.vn",
			"ryan_feng025@yihquan.co.id",
			"sales01@tythac.com.vn",
		}
		cc = []string{
			"kevinkuo@tyxuan.com.vn",
			"liutonghao@tyxuan.com.vn",
			"tythac339967@gmail.com",
		}

	default:
		to = []string{"it@tyxuan.com.vn"}
		cc = []string{"liutonghao@tyxuan.com.vn"}
	}

	return
}

func GetPrivateRecipients(databaseType string) (to []string) {
	switch databaseType {
	case "A":
		to = []string{
			"tythac339967@gmail.com",
			"liutonghao@tyxuan.com.vn",
			"liang0810@tythac.com.vn",
		}

	case "B":
		to = []string{
			"dickhsu@tybach.com.vn",
			"cfqian@tybach.com.vn",
			"phuongit@tybach.com.vn",
			"vinhit@tybach.com.vn",
			"thuit@tybach.com.vn",
			"chungchiaoyi@tybach.com.vn",
			"tythac339967@gmail.com",
			"liutonghao@tyxuan.com.vn",
		}

	case "C":
		to = []string{
			"johny_chen076@yihquan.co.id",
			"rick_jiang083@yihquan.co.id",
			"ky_lim6576@yihquan.co.id",
			"ronnielin_034@yihquan.co.id",
			"ryan_feng025@yihquan.co.id",
			"tythac339967@gmail.com",
			"liutonghao@tyxuan.com.vn",
		}

	default:
		// 預設可選擇回傳空陣列或共用信箱
		to = []string{"it@tyxuan.com.vn"}
	}

	return
}

func GetDelayWarningRecipients() (to, cc []string) {
	return []string{
			"katie.yang@tythac.com.vn",
			"sales01@tythac.com.vn",
		}, []string{
			"kevinkuo@tyxuan.com.vn",
			"liutonghao@tyxuan.com.vn",
			"tythac339967@gmail.com",
		}
}

func GetTestRecipients() (to, cc []string) {
	return []string{
		"tythac339967@gmail.com",
	}, []string{}
}

// utils/mail_impl.go (簡化版實作參考)

func (ms *mailSender) SendEmailHTML(databaseType, mailSubject, htmlBody string) error {
	// 1. 取得收件人
	to := GetPrivateRecipients(databaseType)
	if len(to) == 0 {
		return fmt.Errorf("no recipients found for database type: %s", databaseType)
	}

	// 2. 統一主題格式
	var subject string
	switch databaseType {
	case "A":
		subject = fmt.Sprintf("TyThac %s, API Response", mailSubject)
	case "B":
		subject = fmt.Sprintf("TyBach %s, API Response", mailSubject)
	case "C":
		subject = fmt.Sprintf("YihQuan %s, API Response", mailSubject)
	default:
		return fmt.Errorf("invalid database type: %s", databaseType)
	}

	// 3. 準備 HTML 郵件標頭 (MIME 格式)
	headers := make(map[string]string)
	headers["From"] = ms.From
	headers["To"] = strings.Join(to, ",")
	headers["Subject"] = subject
	headers["MIME-Version"] = "1.0"
	headers["Content-Type"] = "text/html; charset=\"UTF-8\""

	// 4. 組裝訊息內容
	message := ""
	for k, v := range headers {
		message += fmt.Sprintf("%s: %s\r\n", k, v)
	}
	message += "\r\n" + htmlBody

	// 5. 設定認證並發送
	auth := smtp.PlainAuth("", ms.From, ms.Password, ms.SMTPHost)
	err := smtp.SendMail(ms.SMTPHost+":"+ms.SMTPPort, auth, ms.From, to, []byte(message))

	if err != nil {
		log.Printf("Failed to send HTML email: %v", err)
		return err
	}
	log.Printf("HTML email sent to %s successfully", strings.Join(to, ","))
	return nil
}

func (ms *mailSender) SendEmail(databaseType, mailSubject, emailBody string) error {

	to := GetPrivateRecipients(databaseType)

	var subject string
	switch databaseType {
	case "A":
		subject = fmt.Sprintf("TyThac %s, API Response", mailSubject)
	case "B":
		subject = fmt.Sprintf("TyBach %s, API Response", mailSubject)
	case "C":
		subject = fmt.Sprintf("YihQuan %s, API Response", mailSubject)
	default:
		return fmt.Errorf("invalid database type: %s", databaseType)
	}

	// Build email message
	message := fmt.Sprintf("From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n%s",
		ms.From,
		strings.Join(to, ","),
		subject,
		emailBody,
	)

	fmt.Println(message)
	// Send email
	auth := smtp.PlainAuth("", ms.From, ms.Password, ms.SMTPHost)
	err := smtp.SendMail(ms.SMTPHost+":"+ms.SMTPPort, auth, ms.From, to, []byte(message))
	if err != nil {
		log.Printf("Failed to send email: %v", err)
		return err
	}
	log.Printf("Email sent to %s successfully", to)
	return nil
}

func (ms *mailSender) SendEmailWithAttachment(databaseType, attachmentPath, date string) error {

	subject := date + " DTD Project Daily POs Checking List"
	emailBody := `各位業務主管您好，

		附件為今日DTD上傳後有異動的訂單清單，
		煩請協助對照您提供給客戶的資料，確認是否有遺漏或缺少的訂單。
		若有任何疑問，歡迎隨時與我們聯繫，謝謝!!!`

	// Tạo header MIME
	boundary := "BOUNDARY123456"

	to, cc := GetPublicRecipients(databaseType)

	headers := map[string]string{
		"From":         ms.From,
		"To":           strings.Join(to, ","),
		"Cc":           strings.Join(cc, ","),
		"Subject":      subject,
		"MIME-Version": "1.0",
		"Content-Type": "multipart/mixed; boundary=" + boundary,
	}

	var msg strings.Builder
	for k, v := range headers {
		msg.WriteString(fmt.Sprintf("%s: %s\r\n", k, v))
	}
	msg.WriteString("\r\n--" + boundary + "\r\n")
	msg.WriteString("Content-Type: text/plain; charset=\"utf-8\"\r\n")
	msg.WriteString("Content-Transfer-Encoding: 7bit\r\n\r\n")
	msg.WriteString(emailBody + "\r\n")

	// Nếu có tệp đính kèm
	if attachmentPath != "" {
		attachmentData, err := os.ReadFile(attachmentPath)
		if err != nil {
			return fmt.Errorf("cannot read attachment: %w", err)
		}
		encodedAttachment := base64.StdEncoding.EncodeToString(attachmentData)
		filename := filepath.Base(attachmentPath)

		msg.WriteString("\r\n--" + boundary + "\r\n")
		msg.WriteString("Content-Type: application/octet-stream\r\n")
		msg.WriteString("Content-Transfer-Encoding: base64\r\n")
		msg.WriteString("Content-Disposition: attachment; filename=\"" + filename + "\"\r\n\r\n")

		// Chia base64 thành các dòng dài 76 ký tự theo chuẩn MIME
		for i := 0; i < len(encodedAttachment); i += 76 {
			end := i + 76
			if end > len(encodedAttachment) {
				end = len(encodedAttachment)
			}
			msg.WriteString(encodedAttachment[i:end] + "\r\n")
		}
	}

	msg.WriteString("\r\n--" + boundary + "--")

	to = append(to, cc...)

	// Gửi email
	auth := smtp.PlainAuth("", ms.From, ms.Password, ms.SMTPHost)
	err := smtp.SendMail(ms.SMTPHost+":"+ms.SMTPPort, auth, ms.From, to, []byte(msg.String()))
	if err != nil {
		log.Printf("Failed to send email: %v", err)
		return err
	}
	log.Printf("Email sent to %s successfully", to)
	return nil
}

func (ms *mailSender) SendEmailWithEmptyShipID(databaseType, attachmentPath string) error {
	subject := "Missing Dest and ShipID orders."

	to, cc := GetPublicRecipients(databaseType)

	// Tạo header MIME
	boundary := "BOUNDARY123456"
	headers := map[string]string{
		"From":         ms.From,
		"To":           strings.Join(to, ","),
		"Cc":           strings.Join(cc, ","),
		"Subject":      subject,
		"MIME-Version": "1.0",
		"Content-Type": "multipart/mixed; boundary=" + boundary,
	}

	var msg strings.Builder
	for k, v := range headers {
		msg.WriteString(fmt.Sprintf("%s: %s\r\n", k, v))
	}

	// Nếu có tệp đính kèm
	if attachmentPath != "" {
		attachmentData, err := os.ReadFile(attachmentPath)
		if err != nil {
			return fmt.Errorf("cannot read attachment: %w", err)
		}
		encodedAttachment := base64.StdEncoding.EncodeToString(attachmentData)
		filename := filepath.Base(attachmentPath)

		msg.WriteString("\r\n--" + boundary + "\r\n")
		msg.WriteString("Content-Type: application/octet-stream\r\n")
		msg.WriteString("Content-Transfer-Encoding: base64\r\n")
		msg.WriteString("Content-Disposition: attachment; filename=\"" + filename + "\"\r\n\r\n")

		// Chia base64 thành các dòng dài 76 ký tự theo chuẩn MIME
		for i := 0; i < len(encodedAttachment); i += 76 {
			end := i + 76
			if end > len(encodedAttachment) {
				end = len(encodedAttachment)
			}
			msg.WriteString(encodedAttachment[i:end] + "\r\n")
		}
	}

	msg.WriteString("\r\n--" + boundary + "--")

	to = append(to, cc...)

	// Gửi email
	auth := smtp.PlainAuth("", ms.From, ms.Password, ms.SMTPHost)
	err := smtp.SendMail(ms.SMTPHost+":"+ms.SMTPPort, auth, ms.From, to, []byte(msg.String()))
	if err != nil {
		log.Printf("Failed to send email: %v", err)
		return err
	}
	log.Printf("Email sent to %s successfully", to)
	return nil
}

func (ms *mailSender) SendEmailWithFGReport(databaseType, attachmentPath string) error {
	subject := "Factory Weekly FG for Deckers"

	to, cc := GetPublicRecipients(databaseType)
	// to, cc := GetTestRecipients(databaseType)

	// Tạo header MIME
	boundary := "BOUNDARY123456"
	headers := map[string]string{
		"From":         ms.From,
		"To":           strings.Join(to, ","),
		"Cc":           strings.Join(cc, ","),
		"Subject":      subject,
		"MIME-Version": "1.0",
		"Content-Type": "multipart/mixed; boundary=" + boundary,
	}

	var msg strings.Builder
	for k, v := range headers {
		msg.WriteString(fmt.Sprintf("%s: %s\r\n", k, v))
	}

	// Nếu có tệp đính kèm
	if attachmentPath != "" {
		attachmentData, err := os.ReadFile(attachmentPath)
		if err != nil {
			return fmt.Errorf("cannot read attachment: %w", err)
		}
		encodedAttachment := base64.StdEncoding.EncodeToString(attachmentData)
		filename := filepath.Base(attachmentPath)

		msg.WriteString("\r\n--" + boundary + "\r\n")
		msg.WriteString("Content-Type: application/octet-stream\r\n")
		msg.WriteString("Content-Transfer-Encoding: base64\r\n")
		msg.WriteString("Content-Disposition: attachment; filename=\"" + filename + "\"\r\n\r\n")

		// Chia base64 thành các dòng dài 76 ký tự theo chuẩn MIME
		for i := 0; i < len(encodedAttachment); i += 76 {
			end := i + 76
			if end > len(encodedAttachment) {
				end = len(encodedAttachment)
			}
			msg.WriteString(encodedAttachment[i:end] + "\r\n")
		}
	}

	msg.WriteString("\r\n--" + boundary + "--")

	to = append(to, cc...)

	// Gửi email
	auth := smtp.PlainAuth("", ms.From, ms.Password, ms.SMTPHost)
	err := smtp.SendMail(ms.SMTPHost+":"+ms.SMTPPort, auth, ms.From, to, []byte(msg.String()))
	if err != nil {
		log.Printf("Failed to send email: %v", err)
		return err
	}
	log.Printf("Email sent to %s successfully", to)
	return nil
}

func (ms *mailSender) SendEmailWithWarningOrder(attachmentPath string) error {

	subject := "ERP potential delay warning"

	to, cc := GetDelayWarningRecipients()
	// to, cc := GetTestRecipients()

	// Tạo header MIME
	boundary := "BOUNDARY123456"
	headers := map[string]string{
		"From":         ms.From,
		"To":           strings.Join(to, ","),
		"Cc":           strings.Join(cc, ","),
		"Subject":      subject,
		"MIME-Version": "1.0",
		"Content-Type": "multipart/mixed; boundary=" + boundary,
	}

	var msg strings.Builder
	for k, v := range headers {
		msg.WriteString(fmt.Sprintf("%s: %s\r\n", k, v))
	}

	// Nếu có tệp đính kèm
	if attachmentPath != "" {
		attachmentData, err := os.ReadFile(attachmentPath)
		if err != nil {
			return fmt.Errorf("cannot read attachment: %w", err)
		}
		encodedAttachment := base64.StdEncoding.EncodeToString(attachmentData)
		filename := filepath.Base(attachmentPath)

		msg.WriteString("\r\n--" + boundary + "\r\n")
		msg.WriteString("Content-Type: application/octet-stream\r\n")
		msg.WriteString("Content-Transfer-Encoding: base64\r\n")
		msg.WriteString("Content-Disposition: attachment; filename=\"" + filename + "\"\r\n\r\n")

		// Chia base64 thành các dòng dài 76 ký tự theo chuẩn MIME
		for i := 0; i < len(encodedAttachment); i += 76 {
			end := i + 76
			if end > len(encodedAttachment) {
				end = len(encodedAttachment)
			}
			msg.WriteString(encodedAttachment[i:end] + "\r\n")
		}
	}

	msg.WriteString("\r\n--" + boundary + "--")

	to = append(to, cc...)

	// Gửi email
	auth := smtp.PlainAuth("", ms.From, ms.Password, ms.SMTPHost)
	err := smtp.SendMail(ms.SMTPHost+":"+ms.SMTPPort, auth, ms.From, to, []byte(msg.String()))
	if err != nil {
		log.Printf("Failed to send email: %v", err)
		return err
	}
	log.Printf("Email sent to %s successfully", to)
	return nil
}

func (ms *mailSender) SendEmailRQCCheck(databaseType, timeRange string) error {

	subject := "RQC activity warning"

	emailBody :=
		`
	Dear QC Supervisor,

	This is an automated notification from the DTD-API QC RQC monitoring system.
	No inspection submission records were detected during the following monitoring period:
	Time Window: ` + timeRange + `

	Please verify whether:
	1. Inspection activities were performed normally
	2. Data submission was missed or delayed
	3. Any system or operational issues occurred

	If necessary, please take appropriate action to ensure inspection data is submitted correctly and on time.
	This is an automated email. Please do not reply directly to this message.
	`

	// to, cc := GetTestRecipients()
	to := GetPrivateRecipients(databaseType)
	cc := []string{}
	filepath := ""

	err := sendMailWithAttachment(ms, filepath, subject, emailBody, to, cc)
	if err != nil {
		log.Printf("Failed to send email: %v", err)
		return err
	}
	log.Printf("Email sent to %s successfully", to)
	return nil
}

func (ms *mailSender) SendRepackingExcel(filepath, databaseType, date string) error {

	subject := "QC-DTD Repacking"

	switch databaseType {
	case "A":
		subject = fmt.Sprintf("TyThac %s", subject)
	case "B":
		subject = fmt.Sprintf("TyBach %s", subject)
	case "C":
		subject = fmt.Sprintf("YihQuan %s", subject)
	default:
		return fmt.Errorf("invalid database type: %s", databaseType)
	}

	emailBody := ""

	// to, cc := GetTestRecipients()
	to := GetPrivateRecipients(databaseType)
	cc := []string{}

	err := sendMailWithAttachment(ms, filepath, subject, emailBody, to, cc)
	if err != nil {
		log.Printf("Failed to send email: %v", err)
		return err
	}
	log.Printf("Email sent to %s successfully", to)
	return nil
}

func (ms *mailSender) SendBgradeExcel(filepath, databaseType, date string) error {

	subject := "QC-DTD B-Grade"

	switch databaseType {
	case "A":
		subject = fmt.Sprintf("TyThac %s", subject)
	case "B":
		subject = fmt.Sprintf("TyBach %s", subject)
	case "C":
		subject = fmt.Sprintf("YihQuan %s", subject)
	default:
		return fmt.Errorf("invalid database type: %s", databaseType)
	}

	emailBody := ""

	// to, cc := GetTestRecipients()
	to := GetPrivateRecipients(databaseType)
	cc := []string{}

	err := sendMailWithAttachment(ms, filepath, subject, emailBody, to, cc)
	if err != nil {
		log.Printf("Failed to send email: %v", err)
		return err
	}
	log.Printf("Email sent to %s successfully", to)
	return nil
}

func sendMailWithAttachment(ms *mailSender, attachmentPath, subject, emailBody string, to, cc []string) error {
	// Tạo header MIME
	boundary := "BOUNDARY123456"

	headers := map[string]string{
		"From":         ms.From,
		"To":           strings.Join(to, ","),
		"Cc":           strings.Join(cc, ","),
		"Subject":      subject,
		"MIME-Version": "1.0",
		"Content-Type": "multipart/mixed; boundary=" + boundary,
	}

	var msg strings.Builder
	for k, v := range headers {
		msg.WriteString(fmt.Sprintf("%s: %s\r\n", k, v))
	}
	msg.WriteString("\r\n--" + boundary + "\r\n")
	msg.WriteString("Content-Type: text/plain; charset=\"utf-8\"\r\n")
	msg.WriteString("Content-Transfer-Encoding: 7bit\r\n\r\n")
	msg.WriteString(emailBody + "\r\n")

	// Nếu có tệp đính kèm
	if attachmentPath != "" {
		attachmentData, err := os.ReadFile(attachmentPath)
		if err != nil {
			return fmt.Errorf("cannot read attachment: %w", err)
		}
		encodedAttachment := base64.StdEncoding.EncodeToString(attachmentData)
		filename := filepath.Base(attachmentPath)

		msg.WriteString("\r\n--" + boundary + "\r\n")
		msg.WriteString("Content-Type: application/octet-stream\r\n")
		msg.WriteString("Content-Transfer-Encoding: base64\r\n")
		msg.WriteString("Content-Disposition: attachment; filename=\"" + filename + "\"\r\n\r\n")

		// Chia base64 thành các dòng dài 76 ký tự theo chuẩn MIME
		for i := 0; i < len(encodedAttachment); i += 76 {
			end := i + 76
			if end > len(encodedAttachment) {
				end = len(encodedAttachment)
			}
			msg.WriteString(encodedAttachment[i:end] + "\r\n")
		}
	}

	msg.WriteString("\r\n--" + boundary + "--")

	// Gộp danh sách người nhận chính (To) và người được CC
	allRecipients := append([]string{}, to...)
	allRecipients = append(allRecipients, cc...)

	// Gửi email
	auth := smtp.PlainAuth("", ms.From, ms.Password, ms.SMTPHost)
	err := smtp.SendMail(ms.SMTPHost+":"+ms.SMTPPort, auth, ms.From, allRecipients, []byte(msg.String()))
	if err != nil {
		log.Printf("Failed to send email: %v\n", err)
		return err
	}
	log.Printf("Email sent to %s successfully\n", allRecipients)
	return nil
}
