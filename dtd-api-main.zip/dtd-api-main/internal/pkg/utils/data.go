package utils

import "fmt"

func GetDatabaseTypeByFactory(factory string) (string, error) {
	mapping := map[string]string{
		"YS": "A",
		"TB": "B",
		"YQ": "C",
	}

	if val, ok := mapping[factory]; ok {
		return val, nil
	}
	return "", fmt.Errorf("invalid factory: %s", factory)
}

func GetFactoryByDatabaseType(databaseType string) (string, error) {
	mapping := map[string]string{
		"A": "YS",
		"B": "TB",
		"C": "YQ",
	}

	if val, ok := mapping[databaseType]; ok {
		return val, nil
	}
	return "", fmt.Errorf("invalid databaseType: %s", databaseType)
}
