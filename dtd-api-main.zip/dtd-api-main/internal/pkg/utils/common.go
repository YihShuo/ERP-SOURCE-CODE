package utils

import "math/rand"

const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

// Hàm tạo chuỗi ngẫu nhiên
func GenerateRandomString(length int) string {
	// Khởi tạo seed (Chỉ cần thiết cho Go bản < 1.20)
	// rand.Seed(time.Now().UnixNano())

	b := make([]byte, length)
	for i := range b {
		// Chọn ngẫu nhiên 1 ký tự trong tập charset
		b[i] = charset[rand.Intn(len(charset))]
	}
	return string(b)
}
