package utils

import "math"

func Round4(v float32) float32 {
	return float32(math.Round(float64(v)*10000) / 10000)
}
