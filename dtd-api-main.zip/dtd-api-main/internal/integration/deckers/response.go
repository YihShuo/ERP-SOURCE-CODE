package deckers

import (
	"strings"
	"time"
	"unicode"
)

type EpcPullingDeckersResponse struct {
	Epc              string    `json:"epc"`
	Po               string    `json:"po"`
	StyleNumber      string    `json:"styleNumber"`
	ColorCode        string    `json:"colorCode"`
	ShipId           string    `json:"shipId"`
	FactoryCode      string    `json:"factoryCode"`
	SizeNumber       string    `json:"sizeNumber"`
	Upc              string    `json:"upc"`
	FactoryWorkOrder string    `json:"factoryWorkOrder"`
	BatchNumber      string    `json:"batchNumber"`
	CommandNumber    string    `json:"commandNumber"`
	Updated          time.Time `json:"updated"`
}

type EpcPullingApiResponse struct {
	RFIDNO           string    `json:"RFIDNO" gorm:"primaryKey;column:RFIDNO"`
	PO               string    `json:"PO" gorm:"column:PO"`
	StyleNumber      string    `json:"StyleNumber" gorm:"column:StyleNumber"`
	ColorCode        string    `json:"ColorCode" gorm:"column:ColorCode"`
	ShipId           string    `json:"ShipId" gorm:"column:ShipId"`
	FactoryCode      string    `json:"FactoryCode" gorm:"column:FactoryCode"`
	SizeNumber       string    `json:"SizeNumber" gorm:"column:SizeNumber"`
	UPC              string    `json:"UPC" gorm:"column:UPC"`
	FactoryWorkOrder string    `json:"FactoryWorkOrder" gorm:"column:FactoryWorkOrder"`
	BatchNumber      string    `json:"BatchNumber" gorm:"column:BatchNumber"`
	CommandNumber    string    `json:"CommandNumber" gorm:"column:CommandNumber"`
	Updated          time.Time `json:"UpdatedAt" gorm:"column:UpdatedAt"`
	USERID           string    `json:"-" gorm:"column:USERID"`
	USERDATE         time.Time `json:"-" gorm:"column:USERDATE"`
}

func (res *EpcPullingDeckersResponse) Parse(raw EpcPullingDeckersResponse) EpcPullingApiResponse {

	sizeNumber := getBeforeSlash(raw.SizeNumber)
	sizeNumber = RemoveTrailingLetters(sizeNumber)

	return EpcPullingApiResponse{
		RFIDNO:           " " + formatHexWithSpace(raw.Epc),
		PO:               raw.Po,
		StyleNumber:      raw.StyleNumber,
		ColorCode:        raw.ColorCode,
		ShipId:           raw.ShipId,
		FactoryCode:      raw.FactoryCode,
		SizeNumber:       sizeNumber,
		UPC:              raw.Upc,
		FactoryWorkOrder: raw.FactoryWorkOrder,
		BatchNumber:      raw.BatchNumber,
		CommandNumber:    raw.CommandNumber,
		Updated:          raw.Updated,
	}
}

func formatHexWithSpace(s string) string {
	if len(s)%2 != 0 {
		return s // hoặc return error nếu muốn strict
	}

	var builder strings.Builder
	for i := 0; i < len(s); i += 2 {
		if i > 0 {
			builder.WriteByte(' ')
		}
		builder.WriteString(s[i : i+2])
	}
	return builder.String()
}

// RemoveTrailingLetters loại bỏ tất cả các chữ cái ở cuối chuỗi
func RemoveTrailingLetters(s string) string {
	return strings.TrimRightFunc(s, unicode.IsLetter)
}

// Hàm xử lý chuỗi đầu vào
func getBeforeSlash(input string) string {
	// Bước 1: Split chuỗi bởi dấu "/".
	// Nếu có "/", nó trả về mảng các chuỗi, ta lấy phần tử đầu tiên (index 0).
	// Nếu không có "/", phần tử index 0 chính là toàn bộ chuỗi ban đầu.
	firstPart := strings.Split(input, "/")[0]

	// Bước 2: Loại bỏ khoảng trắng thừa ở đầu và cuối chuỗi
	return strings.TrimSpace(firstPart)
}

type DeckersRepackingResponse struct {
	Status   int    `json:"status"`
	ReportId string `json:"reportId"`
	Message  string `json:"message"`
}

type DeckerResponse struct {
	RetID   string `json:"retId"`
	RetCode int    `json:"retCode"`
	RetMsg  string `json:"retMsg"`
}
