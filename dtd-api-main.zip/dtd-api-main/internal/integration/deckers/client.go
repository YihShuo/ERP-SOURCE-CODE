package deckers

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"unicode"
	"web-api/internal/pkg/models/types"
)

type deckerClient struct{}

var DeckerClient deckerClient

func (dc *deckerClient) GetSizeList(styleNumber, colorCode, oauthToken string, cache map[string]string) error {

	key := styleNumber + "-" + colorCode

	// If exist, Ignore
	if _, exists := cache[key]; exists {
		return nil
	}

	// Prepare to call Decker's API
	client := &http.Client{}
	url := "https://mfg.deckers.com/pdm-api/v1/product/" + styleNumber + "/color/" + colorCode + "/sizes"

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return fmt.Errorf("failed to create request: %v", err)
	}
	req.Header.Set("Authorization", "Bearer "+oauthToken)
	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to send request: %v", err)
	}
	defer resp.Body.Close()

	// Read reponse
	responseBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("failed to read response: %v", err)
	}

	// Parse response to SizeList
	var sizes []types.SizeInfo
	if err := json.Unmarshal(responseBody, &sizes); err != nil {
		return fmt.Errorf("failed to unmarshal response: %v", err)
	}

	lastSizeStr := ""

	// Get last String in Decker's Size number (EX: B, D, EE, DM, ...)
	if len(sizes) > 0 {
		size := sizes[0].SizeNumber
		index := len(size) - 1

		// Similar to while loop with condition: if checkingChar is Digit -> Break loop
		for {
			checkingChar := size[index]

			// If checkingChar is letter -> append to result
			if unicode.IsLetter(rune(checkingChar)) {
				lastSizeStr += string(checkingChar)

				// Continue loop
				index--
			} else {
				break
			}
		}
	}

	if lastSizeStr != "" {
		cache[key] = lastSizeStr
	}

	return nil
}

func trimSizeSuffix(size string) string {
	if len(size) == 0 {
		return size
	}

	last := rune(size[len(size)-1])
	if unicode.IsLetter(last) {
		return size[:len(size)-1]
	}

	return size
}

func (dc *deckerClient) GetEPCPulling(oauthToken string, factoryWorkOrder, po, commandNumber string) ([]EpcPullingDeckersResponse, error) {

	params := map[string]string{
		"factoryWorkOrder": factoryWorkOrder,
		"po":               po,
		"commandNumber":    commandNumber,
	}

	// Prepare to call Decker's API
	client := &http.Client{}
	url := "https://mfg.deckers.com/pdm-api/v1/epcs" + generateParamUrl(params)

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %v", err)
	}
	req.Header.Set("Authorization", "Bearer "+oauthToken)

	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to send request: %v", err)
	}
	defer resp.Body.Close()

	// Read reponse
	responseBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %v", err)
	}

	// Parse response to SizeList
	var response []EpcPullingDeckersResponse
	if err := json.Unmarshal(responseBody, &response); err != nil {
		return nil, fmt.Errorf("failed to unmarshal response: %v", err)
	}

	for i := range response {
		response[i].SizeNumber = trimSizeSuffix(response[i].SizeNumber)
	}

	return response, nil
}

func generateParamUrl(params map[string]string) string {
	if len(params) == 0 {
		return ""
	}

	values := url.Values{}

	for k, v := range params {
		if v == "" {
			continue
		}
		values.Add(k, v)
	}

	return "?" + values.Encode()
}
